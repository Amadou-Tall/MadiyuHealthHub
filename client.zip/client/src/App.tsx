import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider } from "@/hooks/use-auth";

import NotFound from "@/pages/not-found";
import Landing from "@/pages/Landing";
import Auth from "@/pages/Auth";
import Dashboard from "@/pages/Dashboard";
import Programs from "@/pages/Programs";
import ProgramDetails from "@/pages/ProgramDetails";
import Community from "@/pages/Community";
import AIChatPage from "@/pages/AIChatPage";
import Admin from "@/pages/Admin";
import Assessment from "@/pages/Assessment";

// Promoted to Mom
import MomOnboarding from "@/pages/mom/MomOnboarding";
import MomDashboard from "@/pages/mom/MomDashboard";
import BirthPlan from "@/pages/mom/BirthPlan";
import MomAIChat from "@/pages/mom/MomAIChat";

// Marketplace & B2B
import Marketplace from "@/pages/Marketplace";
import ProfessionalDetails from "@/pages/ProfessionalDetails";
import EmployerDashboard from "@/pages/employer/EmployerDashboard";

function Router() {
  return (
    <Switch>
      {/* Public Routes */}
      <Route path="/" component={Landing} />
      <Route path="/login" component={Auth} />
      <Route path="/register" component={Auth} />
      
      {/* Core User Routes */}
      <Route path="/dashboard" component={Dashboard} />
      <Route path="/assessment" component={Assessment} />
      <Route path="/programs" component={Programs} />
      <Route path="/programs/:id" component={ProgramDetails} />
      <Route path="/community" component={Community} />
      <Route path="/ai" component={AIChatPage} />
      
      {/* Marketplace */}
      <Route path="/marketplace" component={Marketplace} />
      <Route path="/marketplace/:id" component={ProfessionalDetails} />
      
      {/* Employer */}
      <Route path="/employer/dashboard" component={EmployerDashboard} />

      {/* Admin */}
      <Route path="/admin" component={Admin} />

      {/* Promoted to Mom Sub-App */}
      <Route path="/mom/onboarding" component={MomOnboarding} />
      <Route path="/mom/dashboard" component={MomDashboard} />
      <Route path="/mom/birth-plan" component={BirthPlan} />
      <Route path="/mom/ai/:type" component={MomAIChat} />
      
      {/* Fallback to 404 */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
