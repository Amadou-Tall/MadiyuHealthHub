import { Link } from "wouter";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Clock, ArrowRight } from "lucide-react";

interface ProgramCardData {
  id: string;
  title: string;
  description: string;
  category: string;
  image: string;
  duration: string;
  level: string;
}

export function ProgramCard({ program }: { program: ProgramCardData }) {
  return (
    <Card className="overflow-hidden hover:shadow-lg transition-shadow duration-300 border-none shadow-md group">
      <div className="relative h-48 overflow-hidden">
        <img 
          src={program.image} 
          alt={program.title}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
        />
        <div className="absolute top-3 left-3">
          <Badge className="bg-white/90 text-primary hover:bg-white backdrop-blur-sm shadow-sm">
            {program.category}
          </Badge>
        </div>
      </div>
      <CardHeader className="pb-2">
        <h3 className="font-serif text-xl font-bold text-foreground leading-tight">
          {program.title}
        </h3>
      </CardHeader>
      <CardContent className="pb-4">
        <p className="text-muted-foreground text-sm line-clamp-2">
          {program.description}
        </p>
        <div className="mt-4 flex items-center gap-4 text-xs text-muted-foreground font-medium">
          <div className="flex items-center gap-1">
            <Clock className="w-3.5 h-3.5" />
            {program.duration}
          </div>
          <div className="w-1 h-1 rounded-full bg-muted-foreground/30" />
          <div>{program.level}</div>
        </div>
      </CardContent>
      <CardFooter className="pt-0">
        <Link href={`/programs/${program.id}`} className="w-full">
          <Button className="w-full bg-secondary text-white hover:bg-secondary/90 group-hover:translate-y-0 translate-y-1 transition-all">
            View Program <ArrowRight className="w-4 h-4 ml-2" />
          </Button>
        </Link>
      </CardFooter>
    </Card>
  );
}
