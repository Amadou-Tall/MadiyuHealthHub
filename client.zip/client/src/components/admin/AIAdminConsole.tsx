import { useState } from "react";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogClose } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Edit, Plus, Trash, Bot, Zap, Loader2, Play, CheckCircle, XCircle, Clock } from "lucide-react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, type AiAgent, type AiTask } from "@/lib/api";
import { useToast } from "@/hooks/use-toast";

const SCOPES = [
  { value: "GENERAL_HEALTH", label: "General Health" },
  { value: "CHRONIC_DISEASE", label: "Chronic Disease" },
  { value: "NUTRITION", label: "Nutrition" },
  { value: "MENTAL_HEALTH", label: "Mental Health" },
  { value: "WOMEN_HEALTH", label: "Women's Health" },
  { value: "MOTHERHOOD", label: "Motherhood" },
  { value: "CUSTOMER_SUPPORT", label: "Customer Support" },
  { value: "OPS", label: "Internal Ops" },
];

const TASK_TYPES = [
  { value: "CONTENT_GENERATION", label: "Generate Health Article" },
  { value: "PROGRAM_SUMMARY", label: "Create Program Summary" },
  { value: "WEEKLY_CAMPAIGN", label: "Weekly Campaign Message" },
];

export default function AIAdminConsole() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isOpen, setIsOpen] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [currentAgent, setCurrentAgent] = useState<Partial<AiAgent>>({});
  const [taskDialogOpen, setTaskDialogOpen] = useState(false);
  const [selectedAgentId, setSelectedAgentId] = useState<number | null>(null);
  const [taskType, setTaskType] = useState("");
  const [taskInput, setTaskInput] = useState({ topic: "", audience: "", length: "medium" });

  const { data: agents, isLoading: agentsLoading } = useQuery({
    queryKey: ['adminAiAgents'],
    queryFn: api.admin.ai.getAgents,
  });

  const { data: tasks, isLoading: tasksLoading } = useQuery({
    queryKey: ['adminAiTasks'],
    queryFn: () => api.admin.ai.getTasks(20),
  });

  const createMutation = useMutation({
    mutationFn: (data: Omit<AiAgent, 'id' | 'createdAt' | 'updatedAt'>) => api.admin.ai.createAgent(data),
    onSuccess: () => {
      toast({ title: "Agent Created", description: "New AI agent has been deployed." });
      queryClient.invalidateQueries({ queryKey: ['adminAiAgents'] });
      setIsOpen(false);
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to create agent.", variant: "destructive" });
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }: { id: number; data: Partial<AiAgent> }) => api.admin.ai.updateAgent(id, data),
    onSuccess: () => {
      toast({ title: "Agent Updated", description: "AI agent configuration saved." });
      queryClient.invalidateQueries({ queryKey: ['adminAiAgents'] });
      setIsOpen(false);
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to update agent.", variant: "destructive" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id: number) => api.admin.ai.deleteAgent(id),
    onSuccess: () => {
      toast({ title: "Agent Deleted", description: "AI agent has been removed." });
      queryClient.invalidateQueries({ queryKey: ['adminAiAgents'] });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to delete agent.", variant: "destructive" });
    },
  });

  const runTaskMutation = useMutation({
    mutationFn: (data: { agentId: number; type: string; inputPayload: Record<string, any> }) => api.admin.ai.runTask(data),
    onSuccess: (task) => {
      toast({ title: "Task Completed", description: "AI task has been executed successfully." });
      queryClient.invalidateQueries({ queryKey: ['adminAiTasks'] });
      setTaskDialogOpen(false);
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to run AI task.", variant: "destructive" });
    },
  });

  const handleSaveAgent = () => {
    const agentData = {
      name: currentAgent.name || "",
      slug: currentAgent.slug || "",
      description: currentAgent.description || "",
      scope: currentAgent.scope || "GENERAL_HEALTH",
      isActive: currentAgent.isActive ?? true,
      targetAudience: currentAgent.targetAudience || "",
      personaPrompt: currentAgent.personaPrompt || "",
      systemInstructions: currentAgent.systemInstructions || "",
      languages: currentAgent.languages || ["en"],
    };

    if (isEditing && currentAgent.id) {
      updateMutation.mutate({ id: currentAgent.id, data: agentData });
    } else {
      createMutation.mutate(agentData as any);
    }
  };

  const handleRunTask = () => {
    if (!selectedAgentId || !taskType) return;
    runTaskMutation.mutate({
      agentId: selectedAgentId,
      type: taskType,
      inputPayload: taskInput,
    });
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'COMPLETED':
        return <Badge className="bg-green-100 text-green-700"><CheckCircle className="w-3 h-3 mr-1" />Completed</Badge>;
      case 'FAILED':
        return <Badge className="bg-red-100 text-red-700"><XCircle className="w-3 h-3 mr-1" />Failed</Badge>;
      case 'RUNNING':
        return <Badge className="bg-blue-100 text-blue-700"><Loader2 className="w-3 h-3 mr-1 animate-spin" />Running</Badge>;
      default:
        return <Badge className="bg-gray-100 text-gray-700"><Clock className="w-3 h-3 mr-1" />Pending</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-serif font-bold flex items-center gap-2">
            <Bot className="w-6 h-6 text-primary" />
            AI Team Management
          </h2>
          <p className="text-muted-foreground">Dior supervises the AI health force. Configure personas, deploy agents, and run tasks.</p>
        </div>
      </div>

      <Tabs defaultValue="agents">
        <TabsList>
          <TabsTrigger value="agents">AI Agents ({agents?.length || 0})</TabsTrigger>
          <TabsTrigger value="tasks">AI Tasks</TabsTrigger>
        </TabsList>

        <TabsContent value="agents" className="space-y-4">
          <div className="flex justify-end">
            <Dialog open={isOpen} onOpenChange={setIsOpen}>
              <DialogTrigger asChild>
                <Button onClick={() => { setIsEditing(false); setCurrentAgent({}); }}>
                  <Plus className="w-4 h-4 mr-2" /> Deploy New Agent
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle>{isEditing ? "Edit Agent" : "Deploy New AI Agent"}</DialogTitle>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Agent Name</Label>
                      <Input 
                        placeholder="e.g. Madiyu Nutritionist" 
                        value={currentAgent.name || ""} 
                        onChange={e => setCurrentAgent(prev => ({ ...prev, name: e.target.value }))}
                        data-testid="input-agent-name"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Slug (ID)</Label>
                      <Input 
                        placeholder="e.g. madiyu-ai-nutritionist" 
                        value={currentAgent.slug || ""}
                        onChange={e => setCurrentAgent(prev => ({ ...prev, slug: e.target.value }))}
                        data-testid="input-agent-slug"
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Scope</Label>
                      <Select value={currentAgent.scope || ""} onValueChange={v => setCurrentAgent(prev => ({ ...prev, scope: v }))}>
                        <SelectTrigger data-testid="select-scope">
                          <SelectValue placeholder="Select scope" />
                        </SelectTrigger>
                        <SelectContent>
                          {SCOPES.map(s => (
                            <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label>Target Audience</Label>
                      <Input 
                        placeholder="e.g. Postpartum Moms" 
                        value={currentAgent.targetAudience || ""}
                        onChange={e => setCurrentAgent(prev => ({ ...prev, targetAudience: e.target.value }))}
                        data-testid="input-target-audience"
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label>Description</Label>
                    <Input 
                      placeholder="Brief description of the agent" 
                      value={currentAgent.description || ""}
                      onChange={e => setCurrentAgent(prev => ({ ...prev, description: e.target.value }))}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Persona Prompt</Label>
                    <Textarea 
                      className="h-24 font-mono text-xs" 
                      placeholder="You are a kind, empathetic nutritionist..." 
                      value={currentAgent.personaPrompt || ""}
                      onChange={e => setCurrentAgent(prev => ({ ...prev, personaPrompt: e.target.value }))}
                      data-testid="input-persona"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>System Instructions</Label>
                    <Textarea 
                      className="h-24 font-mono text-xs" 
                      placeholder="Always verify allergies. Do not diagnose..." 
                      value={currentAgent.systemInstructions || ""}
                      onChange={e => setCurrentAgent(prev => ({ ...prev, systemInstructions: e.target.value }))}
                      data-testid="input-system"
                    />
                  </div>
                  <div className="flex items-center gap-2">
                    <Switch 
                      checked={currentAgent.isActive ?? true}
                      onCheckedChange={v => setCurrentAgent(prev => ({ ...prev, isActive: v }))}
                    />
                    <Label>Active</Label>
                  </div>
                  <Button 
                    className="w-full" 
                    onClick={handleSaveAgent}
                    disabled={createMutation.isPending || updateMutation.isPending}
                    data-testid="button-save-agent"
                  >
                    {(createMutation.isPending || updateMutation.isPending) && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                    Save Configuration
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>

          <Card>
            <CardContent className="p-0">
              {agentsLoading ? (
                <div className="flex justify-center py-8">
                  <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Name</TableHead>
                      <TableHead>Audience</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Scope</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {agents?.map((agent) => (
                      <TableRow key={agent.id} data-testid={`row-agent-${agent.id}`}>
                        <TableCell className="font-medium">{agent.name}</TableCell>
                        <TableCell>{agent.targetAudience || "All users"}</TableCell>
                        <TableCell>
                          {agent.isActive ? (
                            <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">Active</Badge>
                          ) : (
                            <Badge variant="outline" className="bg-gray-50 text-gray-500">Inactive</Badge>
                          )}
                        </TableCell>
                        <TableCell className="font-mono text-xs text-muted-foreground">{agent.scope}</TableCell>
                        <TableCell className="text-right space-x-1">
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            onClick={() => { setIsEditing(true); setCurrentAgent(agent); setIsOpen(true); }}
                            data-testid={`button-edit-${agent.id}`}
                          >
                            <Edit className="w-4 h-4" />
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            onClick={() => {
                              if (confirm('Delete this agent?')) {
                                deleteMutation.mutate(agent.id);
                              }
                            }}
                            data-testid={`button-delete-${agent.id}`}
                          >
                            <Trash className="w-4 h-4 text-red-500" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="tasks" className="space-y-4">
          <div className="flex justify-between items-center">
            <p className="text-sm text-muted-foreground">Trigger AI tasks like content generation, summaries, or campaigns.</p>
            <Dialog open={taskDialogOpen} onOpenChange={setTaskDialogOpen}>
              <DialogTrigger asChild>
                <Button>
                  <Zap className="w-4 h-4 mr-2" /> Run New Task
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Run AI Task</DialogTitle>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  <div className="space-y-2">
                    <Label>Select Agent</Label>
                    <Select value={selectedAgentId?.toString() || ""} onValueChange={v => setSelectedAgentId(parseInt(v))}>
                      <SelectTrigger>
                        <SelectValue placeholder="Choose an agent" />
                      </SelectTrigger>
                      <SelectContent>
                        {agents?.filter(a => a.isActive).map(a => (
                          <SelectItem key={a.id} value={a.id.toString()}>{a.name}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Task Type</Label>
                    <Select value={taskType} onValueChange={setTaskType}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select task type" />
                      </SelectTrigger>
                      <SelectContent>
                        {TASK_TYPES.map(t => (
                          <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Topic</Label>
                    <Input 
                      placeholder="e.g. Diabetes prevention tips" 
                      value={taskInput.topic}
                      onChange={e => setTaskInput(prev => ({ ...prev, topic: e.target.value }))}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Target Audience</Label>
                    <Input 
                      placeholder="e.g. Black women in North America" 
                      value={taskInput.audience}
                      onChange={e => setTaskInput(prev => ({ ...prev, audience: e.target.value }))}
                    />
                  </div>
                  <Button 
                    className="w-full" 
                    onClick={handleRunTask}
                    disabled={!selectedAgentId || !taskType || runTaskMutation.isPending}
                  >
                    {runTaskMutation.isPending ? (
                      <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Running...</>
                    ) : (
                      <><Play className="w-4 h-4 mr-2" /> Execute Task</>
                    )}
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>

          <Card>
            <CardContent className="p-0">
              {tasksLoading ? (
                <div className="flex justify-center py-8">
                  <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
                </div>
              ) : tasks && tasks.length > 0 ? (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Agent</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Created</TableHead>
                      <TableHead>Output Preview</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {tasks.map((task) => (
                      <TableRow key={task.id}>
                        <TableCell className="font-medium">{task.agent?.name || `Agent #${task.agentId}`}</TableCell>
                        <TableCell className="font-mono text-xs">{task.type}</TableCell>
                        <TableCell>{getStatusBadge(task.status)}</TableCell>
                        <TableCell className="text-sm text-muted-foreground">
                          {new Date(task.createdAt).toLocaleString()}
                        </TableCell>
                        <TableCell className="max-w-xs truncate text-xs text-muted-foreground">
                          {task.outputPayload?.content?.substring(0, 100) || "—"}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  <Zap className="w-8 h-8 mx-auto mb-2 text-gray-300" />
                  <p>No tasks yet. Run your first AI task above.</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
