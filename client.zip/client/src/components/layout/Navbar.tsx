import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/use-auth";
import { t, setLang, getLang } from "@/lib/i18n";
import { MessageCircle, BookOpen, LayoutDashboard, Heart, Briefcase, Building, Menu, Users } from "lucide-react";
import { Sheet, SheetContent, SheetTrigger, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { useState } from "react";

export function Navbar() {
  const [location] = useLocation();
  const { user, logout } = useAuth();
  const [language, setLanguage] = useState(getLang());
  const [isOpen, setIsOpen] = useState(false);

  const isPublic = !user;

  const toggleLang = () => {
    const newLang = language === 'en' ? 'fr' : 'en';
    setLang(newLang);
    setLanguage(newLang);
    window.location.reload();
  };

  const navLinkClass = (path: string) => cn(
    "text-sm font-medium transition-colors flex items-center gap-2 px-3 py-2 rounded-md hover:bg-blue-50", 
    (location === path || location.startsWith(path + '/')) ? "text-primary bg-primary/5" : "text-muted-foreground hover:text-primary"
  );
  
  const momLinkClass = cn(
    "text-sm font-medium transition-colors flex items-center gap-2 px-3 py-2 rounded-md hover:bg-pink-50",
    location.startsWith('/mom') ? "text-secondary bg-pink-50" : "text-muted-foreground hover:text-secondary"
  );

  const NavContent = () => (
    <>
      {isPublic ? (
        <div className="flex flex-col md:flex-row gap-2">
          <Link href="/programs" onClick={() => setIsOpen(false)} className="text-sm font-medium hover:text-primary transition-colors px-3 py-2">{t('nav.programs')}</Link>
          <Link href="/marketplace" onClick={() => setIsOpen(false)} className="text-sm font-medium hover:text-primary transition-colors px-3 py-2">{t('nav.marketplace')}</Link>
          <Link href="/community" onClick={() => setIsOpen(false)} className="text-sm font-medium hover:text-primary transition-colors px-3 py-2">{t('nav.community')}</Link>
        </div>
      ) : (
        <div className="flex flex-col md:flex-row gap-1">
          {/* USER ROLE */}
          {user.role === 'USER' && (
            <>
              <Link href="/dashboard" onClick={() => setIsOpen(false)} className={navLinkClass('/dashboard')}>
                <LayoutDashboard className="w-4 h-4" /> {t('nav.dashboard')}
              </Link>
              <Link href="/programs" onClick={() => setIsOpen(false)} className={navLinkClass('/programs')}>
                <BookOpen className="w-4 h-4" /> {t('nav.programs')}
              </Link>
              <Link href="/marketplace" onClick={() => setIsOpen(false)} className={navLinkClass('/marketplace')}>
                <Briefcase className="w-4 h-4" /> {t('nav.marketplace')}
              </Link>
              <Link href="/ai" onClick={() => setIsOpen(false)} className={navLinkClass('/ai')}>
                <MessageCircle className="w-4 h-4" /> {t('nav.ai_nurse')}
              </Link>
              <Link href="/community" onClick={() => setIsOpen(false)} className={navLinkClass('/community')}>
                <Users className="w-4 h-4" /> {t('nav.community')}
              </Link>
              <div className="h-px w-full md:h-6 md:w-px bg-gray-200 mx-1 my-2 md:my-0"></div>
              <Link href="/mom/onboarding" onClick={() => setIsOpen(false)} className={momLinkClass}>
                <Heart className="w-4 h-4 fill-current" /> {t('nav.mom')}
              </Link>
            </>
          )}

          {/* PROFESSIONAL ROLE */}
          {user.role === 'PROFESSIONAL' && (
            <>
              <Link href="/dashboard" onClick={() => setIsOpen(false)} className={navLinkClass('/dashboard')}>
                <LayoutDashboard className="w-4 h-4" /> {t('nav.dashboard')}
              </Link>
              <Link href="/marketplace" onClick={() => setIsOpen(false)} className={navLinkClass('/marketplace')}>
                <Briefcase className="w-4 h-4" /> {t('nav.my_profile')}
              </Link>
            </>
          )}

          {/* EMPLOYER ROLE */}
          {user.role === 'EMPLOYER' && (
            <>
              <Link href="/employer/dashboard" onClick={() => setIsOpen(false)} className={navLinkClass('/employer/dashboard')}>
                <Building className="w-4 h-4" /> {t('nav.corp_dashboard')}
              </Link>
            </>
          )}

          {/* ADMIN ROLE */}
          {user.role === 'ADMIN' && (
            <>
              <Link href="/admin" onClick={() => setIsOpen(false)} className={navLinkClass('/admin')}>
                <LayoutDashboard className="w-4 h-4" /> {t('nav.admin')}
              </Link>
            </>
          )}
        </div>
      )}
    </>
  );

  return (
    <nav className="sticky top-0 z-50 w-full border-b bg-white/95 backdrop-blur-md shadow-sm">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        {/* Logo */}
        <Link href="/" className="flex items-center gap-2 group">
          <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center shadow-sm group-hover:scale-105 transition-transform">
            <span className="text-white font-serif font-bold text-lg">M</span>
          </div>
          <div className="flex flex-col">
            <span className="font-serif text-xl font-bold text-primary tracking-tight leading-none">
              Madiyu<span className="text-foreground">Health</span>
            </span>
            {location.startsWith('/mom') && (
              <span className="text-[10px] text-secondary font-medium tracking-widest uppercase leading-none">{t('mom.promoted_title')}</span>
            )}
          </div>
        </Link>

        {/* Desktop Navigation */}
        <div className="hidden md:flex items-center gap-1 lg:gap-2">
          <NavContent />
        </div>

        {/* Mobile & Actions */}
        <div className="flex items-center gap-3">
          
          {/* Language Switcher */}
          <div className="flex items-center bg-muted rounded-full p-0.5">
            <button
              onClick={() => { setLang('en'); setLanguage('en'); window.location.reload(); }}
              className={cn(
                "px-2.5 py-1 text-xs font-semibold rounded-full transition-all",
                language === 'en' ? "bg-primary text-white shadow-sm" : "text-muted-foreground hover:text-foreground"
              )}
            >
              EN
            </button>
            <button
              onClick={() => { setLang('fr'); setLanguage('fr'); window.location.reload(); }}
              className={cn(
                "px-2.5 py-1 text-xs font-semibold rounded-full transition-all",
                language === 'fr' ? "bg-primary text-white shadow-sm" : "text-muted-foreground hover:text-foreground"
              )}
            >
              FR
            </button>
          </div>

          {isPublic ? (
            <div className="hidden md:flex gap-2">
              <Link href="/login">
                <Button variant="ghost" className="text-sm font-medium">{t('nav.login')}</Button>
              </Link>
              <Link href="/register">
                <Button className="bg-primary text-white hover:bg-primary/90 rounded-full px-6 shadow-md hover:shadow-lg transition-all">
                  {t('nav.register')}
                </Button>
              </Link>
            </div>
          ) : (
            <div className="hidden md:flex items-center gap-4">
              <div className="w-8 h-8 rounded-full bg-secondary/10 text-secondary flex items-center justify-center font-bold text-sm border border-secondary/20">
                {user.name.charAt(0)}
              </div>
              <Button variant="ghost" size="sm" onClick={logout} className="text-muted-foreground hover:text-destructive">
                {t('nav.logout')}
              </Button>
            </div>
          )}

          {/* Mobile Menu Trigger */}
          <div className="md:hidden">
            <Sheet open={isOpen} onOpenChange={setIsOpen}>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon">
                  <Menu className="w-6 h-6" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-[300px] sm:w-[400px]">
                <SheetHeader className="mb-6 text-left">
                  <SheetTitle className="font-serif text-2xl text-primary">Madiyu Health</SheetTitle>
                </SheetHeader>
                <div className="flex flex-col gap-4">
                  <NavContent />
                  <div className="h-px bg-gray-100 my-2"></div>
                  {isPublic ? (
                    <div className="flex flex-col gap-2">
                      <Link href="/login" onClick={() => setIsOpen(false)}>
                        <Button variant="outline" className="w-full justify-start">{t('nav.login')}</Button>
                      </Link>
                      <Link href="/register" onClick={() => setIsOpen(false)}>
                        <Button className="w-full justify-start bg-primary text-white">{t('nav.register')}</Button>
                      </Link>
                    </div>
                  ) : (
                     <Button variant="outline" onClick={logout} className="w-full justify-start text-destructive hover:text-destructive hover:bg-destructive/10 border-destructive/20">
                        {t('nav.logout')}
                     </Button>
                  )}
                </div>
              </SheetContent>
            </Sheet>
          </div>

        </div>
      </div>
    </nav>
  );
}
