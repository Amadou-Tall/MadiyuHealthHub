import { createContext, useContext, useState, ReactNode, useEffect } from 'react';
import { useLocation } from 'wouter';
import { api, setAuthToken, clearAuthToken, getAuthToken, type UserProfile, ApiError } from '@/lib/api';
import { useToast } from '@/hooks/use-toast';

interface User {
  id: string;
  name: string;
  email: string;
  role: 'USER' | 'ADMIN' | 'PROFESSIONAL' | 'EMPLOYER';
}

interface AuthContextType {
  user: User | null;
  login: (username: string, password: string) => Promise<void>;
  register: (username: string, password: string, name?: string, email?: string) => Promise<void>;
  logout: () => void;
  isLoading: boolean;
  isInitializing: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

function mapProfileToUser(profile: UserProfile): User {
  return {
    id: profile.id,
    name: profile.name || profile.username,
    email: profile.email || `${profile.username}@example.com`,
    role: profile.role as 'USER' | 'ADMIN' | 'PROFESSIONAL' | 'EMPLOYER',
  };
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isInitializing, setIsInitializing] = useState(true);
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  useEffect(() => {
    async function initAuth() {
      const token = getAuthToken();
      if (token) {
        try {
          const { user: profile } = await api.auth.me();
          setUser(mapProfileToUser(profile));
        } catch (error) {
          clearAuthToken();
        }
      }
      setIsInitializing(false);
    }
    initAuth();
  }, []);

  const login = async (username: string, password: string) => {
    setIsLoading(true);
    try {
      const { token, user: profile } = await api.auth.login(username, password);
      setAuthToken(token);
      const mappedUser = mapProfileToUser(profile);
      setUser(mappedUser);

      if (mappedUser.role === 'ADMIN') {
        setLocation('/admin');
      } else if (mappedUser.role === 'EMPLOYER') {
        setLocation('/employer/dashboard');
      } else {
        setLocation('/dashboard');
      }

      toast({
        title: 'Welcome back!',
        description: `Logged in as ${mappedUser.name}`,
      });
    } catch (error) {
      if (error instanceof ApiError) {
        toast({
          title: 'Login failed',
          description: error.message,
          variant: 'destructive',
        });
      } else {
        toast({
          title: 'Login failed',
          description: 'An unexpected error occurred',
          variant: 'destructive',
        });
      }
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  const register = async (username: string, password: string, name?: string, email?: string) => {
    setIsLoading(true);
    try {
      const { token, user: profile } = await api.auth.register({ username, password, name, email });
      setAuthToken(token);
      const mappedUser = mapProfileToUser(profile);
      setUser(mappedUser);
      setLocation('/dashboard');

      toast({
        title: 'Account created!',
        description: 'Welcome to Madiyu Health',
      });
    } catch (error) {
      if (error instanceof ApiError) {
        toast({
          title: 'Registration failed',
          description: error.message,
          variant: 'destructive',
        });
      } else {
        toast({
          title: 'Registration failed',
          description: 'An unexpected error occurred',
          variant: 'destructive',
        });
      }
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  const logout = () => {
    setUser(null);
    clearAuthToken();
    setLocation('/');
    toast({
      title: 'Logged out',
      description: 'See you soon!',
    });
  };

  return (
    <AuthContext.Provider value={{ user, login, register, logout, isLoading, isInitializing }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
