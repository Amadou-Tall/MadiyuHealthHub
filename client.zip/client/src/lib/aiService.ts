import { api } from './api';

interface AIRequest {
  agentSlug: string;
  message: string;
  history?: { role: 'user' | 'assistant'; content: string }[];
  conversationId?: string;
}

interface AIResponse {
  content: string;
  conversationId?: string;
  error?: string;
}

// AI Service - Now calls the real backend endpoint /api/v1/ai/chat
export const aiService = {
  generateReply: async ({ agentSlug, message, conversationId }: AIRequest): Promise<AIResponse> => {
    try {
      const token = localStorage.getItem('auth_token');
      
      if (!token) {
        return { content: '', error: 'Not authenticated' };
      }

      const response = await fetch('/api/v1/ai/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify({
          agentSlug,
          message,
          conversationId,
        }),
      });

      if (!response.ok) {
        return { content: '', error: 'Failed to get AI response' };
      }

      const data = await response.json();
      return {
        content: data.content,
        conversationId: data.conversationId,
      };
    } catch (error) {
      return { content: '', error: 'Network error' };
    }
  }
};
