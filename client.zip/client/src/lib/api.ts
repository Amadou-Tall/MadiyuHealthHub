const API_BASE = '/api';

export interface UserProfile {
  id: string;
  username: string;
  name?: string;
  email?: string;
  role: string;
  createdAt: Date;
}

export interface AuthResponse {
  token: string;
  user: UserProfile;
}

export class ApiError extends Error {
  constructor(public status: number, message: string) {
    super(message);
    this.name = 'ApiError';
  }
}

async function fetchAPI<T>(
  endpoint: string,
  options: RequestInit = {}
): Promise<T> {
  const token = localStorage.getItem('auth_token');
  
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
  };

  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  const response = await fetch(`${API_BASE}${endpoint}`, {
    ...options,
    headers,
  });

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({ message: 'Request failed' }));
    throw new ApiError(response.status, errorData.message || 'Request failed');
  }

  return response.json();
}

export interface HealthProfile {
  id?: number;
  userId?: string;
  age?: number;
  bmi?: number;
  bloodPressure?: string;
  bloodPressureSystolic?: number;
  bloodPressureDiastolic?: number;
  familyHistoryDiabetes?: boolean;
  familyHistoryHeartDisease?: boolean;
  familyHistoryHighBloodPressure?: boolean;
  riskScore?: number;
  riskLevel?: 'LOW' | 'MODERATE' | 'HIGH';
}

export interface HealthLog {
  id?: number;
  userId?: string;
  weight?: number;
  bloodPressureSystolic?: number;
  bloodPressureDiastolic?: number;
  symptoms?: string[];
  notes?: string;
  createdAt?: string;
}

export interface Program {
  id: number;
  title: string;
  description: string;
  category: string;
  imageUrl?: string;
  duration?: string;
  level?: string;
  isActive: boolean;
  targetRole?: string;
  createdAt?: string;
}

export interface ProgramModule {
  id: number;
  programId: number;
  title: string;
  contentMarkdown: string;
}

export interface MotherhoodProfile {
  id?: number;
  userId?: string;
  status?: 'PLANNING' | 'PREGNANT' | 'POSTPARTUM' | 'NONE';
  weeksPregnant?: number;
  dueDate?: string;
  babyDateOfBirth?: string;
  numberOfChildren?: number;
  preferredBirthSetting?: string;
  notes?: string;
}

export interface BirthPlan {
  id?: number;
  userId?: string;
  painManagementPreference?: string;
  supportPeople?: string;
  culturalPreferences?: string;
  medicalInterventionPreferences?: string;
  extraNotes?: string;
}

export interface BabyProfile {
  id?: number;
  userId?: string;
  name: string;
  dateOfBirth?: string;
  sex?: string;
  notes?: string;
}

export interface BabyLog {
  id?: number;
  babyId?: number;
  dateTime?: string;
  type: 'SLEEP' | 'FEEDING' | 'DIAPER' | 'MILESTONE' | 'HEALTH_NOTE';
  valueNumber?: number;
  valueText?: string;
  createdAt?: string;
}

export interface CommunityGroup {
  id: number;
  name: string;
  description?: string;
  slug: string;
  audienceType: string;
  createdAt?: string;
}

export interface CommunityPost {
  id: number;
  groupId: number;
  userId: string;
  content: string;
  createdAt: string;
  author: { name: string | null; username: string };
}

export interface CommunityReply {
  id: number;
  postId: number;
  userId: string;
  content: string;
  createdAt: string;
  author: { name: string | null; username: string };
}

export interface ProfessionalProfile {
  id: number;
  userId: string;
  professionType: string;
  bio?: string;
  specialties?: string[];
  hourlyRate?: number;
  isVerified?: boolean;
  location?: string;
  imageUrl?: string;
  yearsExperience?: number;
  createdAt?: string;
  user?: { name: string | null };
}

export interface BookingSlot {
  id: number;
  professionalId: number;
  startDateTime: string;
  endDateTime: string;
  isBooked: boolean;
}

export interface Booking {
  id: number;
  userId: string;
  professionalId: number;
  slotId: number;
  status: string;
  notes?: string;
  createdAt?: string;
  professional?: ProfessionalProfile;
  slot?: BookingSlot;
}

export interface Organization {
  id: number;
  name: string;
  country?: string;
  industry?: string;
  ownerUserId: string;
  createdAt?: string;
}

export interface OrgSummary {
  organization: Organization;
  memberCount: number;
  riskDistribution: { riskLevel: string; count: number }[];
  programEnrollments: { programId: number; title: string; count: number }[];
}

export interface ProgramsResponse {
  programs: Program[];
}

export interface ProgramDetailsResponse {
  program: Program;
  modules: ProgramModule[];
}

export const api = {
  auth: {
    register: async (data: { username: string; password: string; name?: string; email?: string }): Promise<AuthResponse> => {
      return fetchAPI<AuthResponse>('/auth/register', {
        method: 'POST',
        body: JSON.stringify(data),
      });
    },

    login: async (username: string, password: string): Promise<AuthResponse> => {
      return fetchAPI<AuthResponse>('/auth/login', {
        method: 'POST',
        body: JSON.stringify({ username, password }),
      });
    },

    me: async (): Promise<{ user: UserProfile }> => {
      return fetchAPI<{ user: UserProfile }>('/auth/me');
    },
  },

  health: {
    getProfile: async (): Promise<HealthProfile> => {
      return fetchAPI<HealthProfile>('/v1/health/profile');
    },

    updateProfile: async (data: HealthProfile): Promise<HealthProfile> => {
      return fetchAPI<HealthProfile>('/v1/health/profile', {
        method: 'POST',
        body: JSON.stringify(data),
      });
    },

    getLogs: async (limit = 10, offset = 0): Promise<{ logs: HealthLog[] }> => {
      return fetchAPI<{ logs: HealthLog[] }>(`/v1/health/logs?limit=${limit}&offset=${offset}`);
    },

    addLog: async (data: HealthLog): Promise<HealthLog> => {
      return fetchAPI<HealthLog>('/v1/health/logs', {
        method: 'POST',
        body: JSON.stringify(data),
      });
    },
  },

  programs: {
    getAll: async (): Promise<ProgramsResponse> => {
      return fetchAPI<ProgramsResponse>('/v1/programs');
    },

    getRecommended: async (): Promise<{ programs: Program[] }> => {
      return fetchAPI<{ programs: Program[] }>('/v1/programs/recommended');
    },

    getById: async (id: number): Promise<ProgramDetailsResponse> => {
      return fetchAPI<ProgramDetailsResponse>(`/v1/programs/${id}`);
    },
  },

  assessment: {
    getQuestions: async (): Promise<{ questions: any[] }> => {
      return fetchAPI<{ questions: any[] }>('/v1/assessment/questions');
    },

    submit: async (answers: Record<string, any>): Promise<{ riskScore: number; riskLevel: string }> => {
      return fetchAPI<{ riskScore: number; riskLevel: string }>('/v1/assessment/submit', {
        method: 'POST',
        body: JSON.stringify({ answers }),
      });
    },
  },

  mom: {
    getProfile: async (): Promise<MotherhoodProfile> => {
      return fetchAPI<MotherhoodProfile>('/v1/mom/profile');
    },

    updateProfile: async (data: MotherhoodProfile): Promise<MotherhoodProfile> => {
      return fetchAPI<MotherhoodProfile>('/v1/mom/profile', {
        method: 'POST',
        body: JSON.stringify(data),
      });
    },

    getBirthPlan: async (): Promise<BirthPlan> => {
      return fetchAPI<BirthPlan>('/v1/mom/birth-plan');
    },

    updateBirthPlan: async (data: BirthPlan): Promise<BirthPlan> => {
      return fetchAPI<BirthPlan>('/v1/mom/birth-plan', {
        method: 'POST',
        body: JSON.stringify(data),
      });
    },

    getBabies: async (): Promise<{ babies: BabyProfile[] }> => {
      return fetchAPI<{ babies: BabyProfile[] }>('/v1/mom/babies');
    },

    createBaby: async (data: BabyProfile): Promise<BabyProfile> => {
      return fetchAPI<BabyProfile>('/v1/mom/babies', {
        method: 'POST',
        body: JSON.stringify(data),
      });
    },

    getBabyLogs: async (babyId: number, limit = 10, offset = 0): Promise<{ logs: BabyLog[] }> => {
      return fetchAPI<{ logs: BabyLog[] }>(`/v1/mom/babies/${babyId}/logs?limit=${limit}&offset=${offset}`);
    },

    addBabyLog: async (babyId: number, data: BabyLog): Promise<BabyLog> => {
      return fetchAPI<BabyLog>(`/v1/mom/babies/${babyId}/logs`, {
        method: 'POST',
        body: JSON.stringify(data),
      });
    },
  },

  community: {
    getGroups: async (): Promise<CommunityGroup[]> => {
      return fetchAPI<CommunityGroup[]>('/v1/community/groups');
    },

    getGroupPosts: async (slug: string): Promise<{ group: CommunityGroup; posts: CommunityPost[] }> => {
      return fetchAPI<{ group: CommunityGroup; posts: CommunityPost[] }>(`/v1/community/groups/${slug}/posts`);
    },

    createPost: async (slug: string, content: string): Promise<CommunityPost> => {
      return fetchAPI<CommunityPost>(`/v1/community/groups/${slug}/posts`, {
        method: 'POST',
        body: JSON.stringify({ content }),
      });
    },

    getPostReplies: async (postId: number): Promise<{ post: CommunityPost; replies: CommunityReply[] }> => {
      return fetchAPI<{ post: CommunityPost; replies: CommunityReply[] }>(`/v1/community/posts/${postId}/replies`);
    },

    createReply: async (postId: number, content: string): Promise<CommunityReply> => {
      return fetchAPI<CommunityReply>(`/v1/community/posts/${postId}/replies`, {
        method: 'POST',
        body: JSON.stringify({ content }),
      });
    },
  },

  marketplace: {
    getProfessionals: async (filters?: { type?: string; search?: string }): Promise<ProfessionalProfile[]> => {
      const params = new URLSearchParams();
      if (filters?.type) params.append('type', filters.type);
      if (filters?.search) params.append('search', filters.search);
      const query = params.toString();
      return fetchAPI<ProfessionalProfile[]>(`/v1/marketplace/professionals${query ? `?${query}` : ''}`);
    },

    getProfessional: async (id: number): Promise<{ professional: ProfessionalProfile; slots: BookingSlot[] }> => {
      return fetchAPI<{ professional: ProfessionalProfile; slots: BookingSlot[] }>(`/v1/marketplace/professionals/${id}`);
    },

    bookSlot: async (data: { professionalId: number; slotId: number; notes?: string }): Promise<Booking> => {
      return fetchAPI<Booking>('/v1/marketplace/bookings', {
        method: 'POST',
        body: JSON.stringify(data),
      });
    },

    getMyBookings: async (): Promise<Booking[]> => {
      return fetchAPI<Booking[]>('/v1/marketplace/bookings/my');
    },
  },

  employer: {
    getOrg: async (): Promise<Organization> => {
      return fetchAPI<Organization>('/v1/employer/org');
    },

    updateOrg: async (data: { name: string; country?: string; industry?: string }): Promise<Organization> => {
      return fetchAPI<Organization>('/v1/employer/org', {
        method: 'POST',
        body: JSON.stringify(data),
      });
    },

    getSummary: async (): Promise<OrgSummary> => {
      return fetchAPI<OrgSummary>('/v1/employer/org/summary');
    },
  },

  admin: {
    getUsers: async (): Promise<UserProfile[]> => {
      return fetchAPI<UserProfile[]>('/v1/admin/users');
    },

    ai: {
      getAgents: async (): Promise<AiAgent[]> => {
        return fetchAPI<AiAgent[]>('/v1/admin/ai/agents');
      },

      createAgent: async (data: Omit<AiAgent, 'id' | 'createdAt' | 'updatedAt'>): Promise<AiAgent> => {
        return fetchAPI<AiAgent>('/v1/admin/ai/agents', {
          method: 'POST',
          body: JSON.stringify(data),
        });
      },

      updateAgent: async (id: number, data: Partial<AiAgent>): Promise<AiAgent> => {
        return fetchAPI<AiAgent>(`/v1/admin/ai/agents/${id}`, {
          method: 'PATCH',
          body: JSON.stringify(data),
        });
      },

      deleteAgent: async (id: number): Promise<void> => {
        return fetchAPI<void>(`/v1/admin/ai/agents/${id}`, {
          method: 'DELETE',
        });
      },

      getTasks: async (limit: number = 50): Promise<AiTask[]> => {
        return fetchAPI<AiTask[]>(`/v1/admin/ai/tasks?limit=${limit}`);
      },

      runTask: async (data: { agentId: number; type: string; inputPayload?: Record<string, any> }): Promise<AiTask> => {
        return fetchAPI<AiTask>('/v1/admin/ai/tasks', {
          method: 'POST',
          body: JSON.stringify(data),
        });
      },
    },
  },
};

export interface AiAgent {
  id: number;
  name: string;
  slug: string;
  description?: string;
  scope: string;
  isActive: boolean;
  targetAudience?: string;
  personaPrompt: string;
  systemInstructions: string;
  languages: string[];
  createdAt: string;
  updatedAt: string;
}

export interface AiTask {
  id: number;
  agentId: number;
  type: string;
  inputPayload?: Record<string, any>;
  outputPayload?: Record<string, any>;
  status: 'PENDING' | 'RUNNING' | 'COMPLETED' | 'FAILED';
  runByUserId?: string;
  createdAt: string;
  updatedAt: string;
  agent?: AiAgent;
}

export function setAuthToken(token: string) {
  localStorage.setItem('auth_token', token);
}

export function clearAuthToken() {
  localStorage.removeItem('auth_token');
}

export function getAuthToken(): string | null {
  return localStorage.getItem('auth_token');
}
