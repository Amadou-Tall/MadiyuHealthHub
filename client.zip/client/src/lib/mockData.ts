
import programImage1 from '@assets/generated_images/healthy_fresh_food_arrangement.png';
import programImage2 from '@assets/generated_images/pregnant_woman_doing_gentle_yoga.png';
import diabetesImage from '@assets/generated_images/diabetes_prevention_nutrition.png';
import hypertensionImage from '@assets/generated_images/heart_health_and_blood_pressure.png';
import breastCancerImage from '@assets/generated_images/breast_health_awareness.png';
import mentalHealthImage from '@assets/generated_images/women_mental_health.png';
import proNutritionist from '@assets/generated_images/professional_headshot_of_a_female_nutritionist.png';
import proDoula from '@assets/generated_images/professional_headshot_of_a_female_doula.png';

export type RiskLevel = 'LOW' | 'MODERATE' | 'HIGH';
export type MomStatus = 'PLANNING' | 'PREGNANT' | 'POSTPARTUM' | 'NONE';
export type UserRole = 'USER' | 'PROFESSIONAL' | 'ADMIN' | 'EMPLOYER';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  avatar?: string;
  riskScore?: number;
  riskLevel?: RiskLevel;
  momStatus?: MomStatus;
}

export interface HealthProfile {
  userId: string;
  dateOfBirth: string;
  height: number; // cm
  weight: number; // kg
  bmi: number;
  bloodPressure?: string;
  familyHistory: string[];
  lifestyle: string[];
  conditions: string[];
}

export interface ProgramModule {
  id: string;
  title: string;
  content: string; // Markdown
  duration: number; // minutes
}

export interface Program {
  id: string;
  title: string;
  description: string;
  category: 'Prenatal' | 'Postnatal' | 'Fitness' | 'Chronic Disease' | 'Women\'s Health' | 'Mental Health';
  image: string;
  duration: string;
  level: 'Beginner' | 'Intermediate' | 'Advanced' | 'All Levels';
  modules: ProgramModule[];
}

export interface CommunityGroup {
  id: string;
  name: string;
  slug: string;
  description: string;
  memberCount: number;
  image?: string;
}

export interface HealthLog {
  id: string;
  date: string;
  type: 'BP' | 'Glucose' | 'Mood' | 'Weight' | 'Sleep';
  value: string;
  unit?: string;
  notes?: string;
}

// Promoted to Mom Interfaces
export interface MotherhoodProfile {
  userId: string;
  status: MomStatus;
  weeksPregnant?: number;
  dueDate?: string;
  babyDateOfBirth?: string;
  numberOfChildren: number;
  preferredBirthSetting?: 'HOSPITAL' | 'BIRTH_CENTER' | 'HOME';
  notes?: string;
}

export interface BirthPlan {
  id: string;
  userId: string;
  painManagementPreference: string;
  supportPeople: string;
  culturalPreferences: string;
  medicalInterventionPreferences: string;
  extraNotes: string;
}

export interface BabyProfile {
  id: string;
  userId: string;
  name: string;
  dateOfBirth: string;
  sex: 'Male' | 'Female' | 'Other';
  notes?: string;
}

export interface BabyLog {
  id: string;
  babyId: string;
  dateTime: string;
  type: 'SLEEP' | 'FEEDING' | 'DIAPER' | 'MILESTONE' | 'HEALTH_NOTE';
  valueText: string;
  valueNumber?: number;
}

// Professional & Marketplace Interfaces
export interface ProfessionalProfile {
  id: string;
  userId: string;
  name: string;
  profession: 'Nutritionist' | 'Doula' | 'Sleep Coach' | 'Therapist' | 'Lactation Consultant';
  bio: string;
  specialties: string[];
  hourlyRate: number;
  image: string;
  rating: number;
  reviewCount: number;
}

export interface BookingSlot {
  id: string;
  professionalId: string;
  startDateTime: string; // ISO string
  endDateTime: string; // ISO string
  isBooked: boolean;
}

export interface Booking {
  id: string;
  userId: string;
  professionalId: string;
  slotId: string;
  status: 'PENDING' | 'CONFIRMED' | 'CANCELLED' | 'COMPLETED';
  date: string; // ISO string
  professionalName: string; // Denormalized for mock ease
  professionalType: string;
}

// Organization / B2B Interfaces
export interface Organization {
  id: string;
  name: string;
  industry: string;
  employeeCount: number;
  riskDistribution: { low: number; moderate: number; high: number };
  enrollmentStats: { category: string; count: number }[];
}

// AI Agent Management
export interface AIAgentDefinition {
  id: string;
  name: string;
  slug: string;
  description: string;
  scope: string;
  isActive: boolean;
  targetAudience: string;
  personaPrompt: string;
  systemInstructions: string;
  languages: string[];
}


// --- MOCK DATA ---

export const MOCK_USERS: User[] = [
  { id: '1', name: 'Jane Doe', email: 'jane@example.com', role: 'USER', riskScore: 45, riskLevel: 'MODERATE', momStatus: 'PREGNANT' },
  { id: '2', name: 'Dr. Sarah Smith', email: 'sarah@example.com', role: 'PROFESSIONAL' },
  { id: '3', name: 'Admin User', email: 'admin@example.com', role: 'ADMIN' },
  { id: '4', name: 'Acme Corp HR', email: 'hr@acmecorp.com', role: 'EMPLOYER' },
];

export const MOCK_HEALTH_PROFILE: HealthProfile = {
  userId: '1',
  dateOfBirth: '1990-05-15',
  height: 165,
  weight: 68,
  bmi: 24.9,
  bloodPressure: '120/80',
  familyHistory: ['Diabetes'],
  lifestyle: ['Moderate Activity'],
  conditions: []
};

export const MOCK_MOTHERHOOD_PROFILE: MotherhoodProfile = {
  userId: '1',
  status: 'PREGNANT',
  weeksPregnant: 24,
  dueDate: '2026-03-15',
  numberOfChildren: 0,
  preferredBirthSetting: 'HOSPITAL'
};

export const MOCK_LOGS: HealthLog[] = [
  { id: '1', date: '2025-12-02', type: 'BP', value: '118/78', unit: 'mmHg' },
  { id: '2', date: '2025-12-02', type: 'Sleep', value: '6.5', unit: 'hrs' },
  { id: '3', date: '2025-12-01', type: 'Mood', value: 'Anxious', notes: 'Felt stressed about work' },
  { id: '4', date: '2025-11-30', type: 'Weight', value: '68.2', unit: 'kg' },
];

export const MOCK_BABY_LOGS: BabyLog[] = [
  { id: '1', babyId: 'b1', dateTime: '2025-12-03T08:00:00', type: 'SLEEP', valueText: 'Slept through the night', valueNumber: 360 },
  { id: '2', babyId: 'b1', dateTime: '2025-12-03T06:30:00', type: 'FEEDING', valueText: 'Breastfeeding', valueNumber: 20 },
  { id: '3', babyId: 'b1', dateTime: '2025-12-03T04:00:00', type: 'DIAPER', valueText: 'Wet' },
];

const DEFAULT_MODULES: ProgramModule[] = [
  { id: '1', title: 'Introduction & Overview', content: 'Welcome to the program...', duration: 10 },
  { id: '2', title: 'Understanding the Basics', content: 'Let\'s dive deeper...', duration: 20 },
  { id: '3', title: 'Practical Strategies', content: 'How to apply this...', duration: 30 },
];

export const MOCK_PROGRAMS: Program[] = [
  {
    id: '1',
    title: 'Gestational Diabetes Management',
    description: 'A comprehensive guide to managing blood sugar levels during pregnancy with diet and exercise.',
    category: 'Prenatal',
    image: programImage1,
    duration: '4 weeks',
    level: 'Beginner',
    modules: DEFAULT_MODULES
  },
  {
    id: '2',
    title: 'Prenatal Yoga Flow',
    description: 'Gentle stretching and strengthening exercises designed specifically for expecting mothers.',
    category: 'Fitness',
    image: programImage2,
    duration: '8 weeks',
    level: 'All Levels',
    modules: DEFAULT_MODULES
  },
  {
    id: '3',
    title: 'Diabetes Prevention for Women',
    description: 'Evidence-based strategies to prevent type 2 diabetes through lifestyle changes.',
    category: 'Chronic Disease',
    image: diabetesImage,
    duration: '12 weeks',
    level: 'Beginner',
    modules: [
      { id: 'dp1', title: 'Introduction to Diabetes Prevention', content: '# Welcome\nLearn about prediabetes...', duration: 15 },
      { id: 'dp2', title: 'Nutrition Basics', content: '# Nutrition\nFocus on whole foods...', duration: 25 },
      { id: 'dp3', title: 'Physical Activity', content: '# Moving More\nAim for 150 mins/week...', duration: 20 }
    ]
  },
  {
    id: '4',
    title: 'Heart Health & Blood Pressure',
    description: 'Take control of your heart health with monitoring, diet, and stress management.',
    category: 'Chronic Disease',
    image: hypertensionImage,
    duration: '6 weeks',
    level: 'Intermediate',
    modules: DEFAULT_MODULES
  },
  {
    id: '5',
    title: 'Breast Health & Early Detection',
    description: 'Learn how to perform self-exams and understand the importance of regular screenings.',
    category: 'Women\'s Health',
    image: breastCancerImage,
    duration: '2 weeks',
    level: 'All Levels',
    modules: DEFAULT_MODULES
  },
  {
    id: '6',
    title: 'Women\'s Mental Health & Stress',
    description: 'Strategies for managing anxiety, burnout, and finding balance in daily life.',
    category: 'Mental Health',
    image: mentalHealthImage,
    duration: '8 weeks',
    level: 'All Levels',
    modules: DEFAULT_MODULES
  }
];

export const MOCK_COMMUNITIES: CommunityGroup[] = [
  { id: '1', name: 'First Time Moms', slug: 'first-time-moms', description: 'Support for new mothers navigating early parenthood.', memberCount: 1240 },
  { id: '2', name: 'Gestational Diabetes Support', slug: 'gd-support', description: 'Recipes, tips, and emotional support.', memberCount: 850 },
  { id: '3', name: 'Black Maternal Health', slug: 'black-maternal-health', description: 'A safe space for Black mothers to share experiences and resources.', memberCount: 920 },
  { id: '4', name: 'Heart Healthy Women', slug: 'heart-healthy', description: 'Motivation for staying active and eating well.', memberCount: 450 },
];

export const MOCK_PROFESSIONALS: ProfessionalProfile[] = [
  {
    id: 'p1', userId: '2', name: 'Dr. Sarah Smith', profession: 'Nutritionist', 
    bio: 'Certified holistic nutritionist specializing in prenatal and postpartum care.',
    specialties: ['Gestational Diabetes', 'Postpartum Weight Loss', 'Hormonal Balance'],
    hourlyRate: 120, image: proNutritionist, rating: 4.9, reviewCount: 42
  },
  {
    id: 'p2', userId: '99', name: 'Elena Rodriguez', profession: 'Doula',
    bio: 'Experienced birth doula supporting hospital and home births for over 10 years.',
    specialties: ['Natural Birth', 'VBAC Support', 'Lactation Basics'],
    hourlyRate: 80, image: proDoula, rating: 5.0, reviewCount: 28
  }
];

export const MOCK_SLOTS: BookingSlot[] = [
  { id: 's1', professionalId: 'p1', startDateTime: '2025-12-10T10:00:00', endDateTime: '2025-12-10T11:00:00', isBooked: false },
  { id: 's2', professionalId: 'p1', startDateTime: '2025-12-10T14:00:00', endDateTime: '2025-12-10T15:00:00', isBooked: true },
  { id: 's3', professionalId: 'p2', startDateTime: '2025-12-11T09:00:00', endDateTime: '2025-12-11T10:00:00', isBooked: false },
];

export const MOCK_BOOKINGS: Booking[] = [
  { id: 'b1', userId: '1', professionalId: 'p1', slotId: 's2', status: 'CONFIRMED', date: '2025-12-10T14:00:00', professionalName: 'Dr. Sarah Smith', professionalType: 'Nutritionist' }
];

export const MOCK_ORG: Organization = {
  id: 'org1', name: 'Acme Corp', industry: 'Technology', employeeCount: 450,
  riskDistribution: { low: 60, moderate: 30, high: 10 },
  enrollmentStats: [
    { category: 'Mental Health', count: 120 },
    { category: 'Prenatal', count: 15 },
    { category: 'Chronic Disease', count: 45 }
  ]
};

export const MOCK_AI_AGENTS: AIAgentDefinition[] = [
  { id: 'a1', name: 'Madiyu Nurse', slug: 'madiyu-ai-nurse', description: 'General health guidance', scope: 'GLOBAL', isActive: true, targetAudience: 'All Women', personaPrompt: 'You are a compassionate nurse...', systemInstructions: 'Always include disclaimer...', languages: ['en', 'es'] },
  { id: 'a2', name: 'Madiyu Doula', slug: 'promoted-mom-ai-doula', description: 'Pregnancy & birth support', scope: 'MOTHERHOOD', isActive: true, targetAudience: 'Pregnant Women', personaPrompt: 'You are a wise doula...', systemInstructions: 'Focus on comfort measures...', languages: ['en'] },
  { id: 'a3', name: 'Madiyu Sleep Coach', slug: 'promoted-mom-ai-sleep-coach', description: 'Baby sleep support', scope: 'MOTHERHOOD', isActive: true, targetAudience: 'New Parents', personaPrompt: 'You are a calm sleep coach...', systemInstructions: 'Focus on safe sleep...', languages: ['en'] }
];
