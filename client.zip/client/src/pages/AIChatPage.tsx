import { useState, useRef, useEffect } from "react";
import { Navbar } from "@/components/layout/Navbar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Send, Sparkles, User, ShieldCheck } from "lucide-react";
import aiAvatar from "@assets/generated_images/friendly_ai_nurse_avatar.png";
import { aiService } from "@/lib/aiService";
import { t, getLang } from "@/lib/i18n";
import { useToast } from "@/hooks/use-toast";

interface Message {
  id: string;
  sender: 'user' | 'ai';
  content: string;
  timestamp: Date;
}

export default function AIChatPage() {
  const { toast } = useToast();
  const lang = getLang();
  
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      sender: 'ai',
      content: t('ai.initial_greeting'),
      timestamp: new Date()
    }
  ]);
  const [input, setInput] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isTyping]);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;

    const userMsg: Message = {
      id: Date.now().toString(),
      sender: 'user',
      content: input,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMsg]);
    setInput("");
    setIsTyping(true);

    try {
      const response = await aiService.generateReply({
        agentSlug: 'madiyu-ai-nurse',
        message: userMsg.content,
        history: messages.map(m => ({ role: m.sender === 'user' ? 'user' : 'assistant', content: m.content }))
      });

      if (response.error) throw new Error(response.error);

      const aiMsg: Message = {
        id: (Date.now() + 1).toString(),
        sender: 'ai',
        content: response.content,
        timestamp: new Date()
      };
      setMessages(prev => [...prev, aiMsg]);
    } catch (error) {
      toast({
        title: t('common.error'),
        description: t('ai.connection_error'),
        variant: "destructive"
      });
    } finally {
      setIsTyping(false);
    }
  };

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Navbar />
      
      <div className="flex-1 container mx-auto max-w-4xl p-4 md:p-6 flex flex-col h-[calc(100vh-64px)]">
        <div className="bg-white rounded-2xl shadow-sm border flex-1 flex flex-col overflow-hidden">
          
          {/* Chat Header */}
          <div className="p-4 border-b flex items-center gap-4 bg-primary/5">
            <Avatar className="h-10 w-10 border-2 border-white shadow-sm">
              <AvatarImage src={aiAvatar} />
              <AvatarFallback>AI</AvatarFallback>
            </Avatar>
            <div>
              <h1 className="font-serif font-bold text-lg text-foreground">{t('nav.ai_nurse')}</h1>
              <p className="text-xs text-muted-foreground flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span>
                {t('ai.online_status')} • {t('ai.disclaimer_applies')}
              </p>
            </div>
          </div>

          {/* Disclaimer Banner */}
          <div className="bg-orange-50 px-4 py-2 text-xs text-orange-800 flex items-start gap-2 border-b border-orange-100">
             <ShieldCheck className="w-4 h-4 flex-shrink-0 mt-0.5" />
             <p>{t('ai.disclaimer')}</p>
          </div>

          {/* Chat Area */}
          <ScrollArea className="flex-1 p-4" ref={scrollRef}>
            <div className="space-y-6 pb-4">
              {messages.map((msg) => (
                <div 
                  key={msg.id} 
                  className={`flex gap-3 ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  {msg.sender === 'ai' && (
                    <Avatar className="h-8 w-8 mt-1 border border-border flex-shrink-0">
                      <AvatarImage src={aiAvatar} />
                      <AvatarFallback>AI</AvatarFallback>
                    </Avatar>
                  )}
                  
                  <div 
                    className={`max-w-[85%] md:max-w-[75%] rounded-2xl px-5 py-3 text-sm leading-relaxed shadow-sm whitespace-pre-wrap ${
                      msg.sender === 'user' 
                        ? 'bg-primary text-white rounded-tr-none' 
                        : 'bg-gray-50 text-foreground border border-gray-100 rounded-tl-none'
                    }`}
                  >
                    {msg.content}
                  </div>

                  {msg.sender === 'user' && (
                    <div className="h-8 w-8 rounded-full bg-gray-200 flex items-center justify-center mt-1 flex-shrink-0">
                      <User className="w-4 h-4 text-gray-500" />
                    </div>
                  )}
                </div>
              ))}
              
              {isTyping && (
                <div className="flex gap-3 justify-start">
                   <Avatar className="h-8 w-8 mt-1 border border-border">
                      <AvatarImage src={aiAvatar} />
                      <AvatarFallback>AI</AvatarFallback>
                    </Avatar>
                    <div className="bg-gray-50 rounded-2xl rounded-tl-none px-4 py-3 border border-gray-100">
                      <div className="flex gap-1">
                        <span className="w-2 h-2 bg-gray-300 rounded-full animate-bounce"></span>
                        <span className="w-2 h-2 bg-gray-300 rounded-full animate-bounce delay-150"></span>
                        <span className="w-2 h-2 bg-gray-300 rounded-full animate-bounce delay-300"></span>
                      </div>
                    </div>
                </div>
              )}
            </div>
          </ScrollArea>

          {/* Input Area */}
          <div className="p-4 border-t bg-white">
            <form onSubmit={handleSend} className="flex gap-2">
              <Input 
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder={t('ai.placeholder')}
                className="flex-1 bg-gray-50 border-gray-200 focus-visible:ring-primary"
                data-testid="input-ai-message"
              />
              <Button type="submit" disabled={!input.trim() || isTyping} className="bg-primary hover:bg-primary/90 text-white" data-testid="button-ai-send">
                {isTyping ? t('ai.typing') : <Send className="w-4 h-4" />}
              </Button>
            </form>
            <div className="mt-2 text-center">
               <p className="text-[10px] text-muted-foreground">
                 <Sparkles className="w-3 h-3 inline mr-1 text-secondary" />
                 {t('ai.mistakes_warning')}
               </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
