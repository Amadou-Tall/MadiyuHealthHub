import { Navbar } from "@/components/layout/Navbar";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Plus, Loader2, Shield, Users, BookOpen, Bot, User } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { api, type UserProfile, type Program } from "@/lib/api";
import AIAdminConsole from "@/components/admin/AIAdminConsole";
import { t, getLang } from "@/lib/i18n";

export default function Admin() {
  const lang = getLang();

  const { data: programsData, isLoading: programsLoading } = useQuery({
    queryKey: ['programs'],
    queryFn: () => api.programs.getAll(),
  });

  const { data: usersData, isLoading: usersLoading, error: usersError } = useQuery({
    queryKey: ['adminUsers'],
    queryFn: () => api.admin.getUsers(),
  });

  const programs = programsData?.programs || [];
  const users = usersData || [];

  const getRoleBadgeStyle = (role: string) => {
    switch (role) {
      case 'ADMIN':
        return 'bg-red-50 text-red-700 border-red-200';
      case 'PROFESSIONAL':
        return 'bg-purple-50 text-purple-700 border-purple-200';
      case 'EMPLOYER':
        return 'bg-orange-50 text-orange-700 border-orange-200';
      default:
        return 'bg-blue-50 text-blue-700 border-blue-200';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50/50 pb-20">
      <Navbar />
      
      <div className="bg-white border-b py-8">
        <div className="container mx-auto px-4">
          <div className="flex items-center gap-3">
            <div className="bg-primary/10 p-2 rounded-full">
              <Shield className="w-6 h-6 text-primary" />
            </div>
            <div>
              <h1 className="font-serif text-3xl font-bold text-foreground">{t('admin.title')}</h1>
              <p className="text-muted-foreground">{t('admin.subtitle')}</p>
            </div>
          </div>
        </div>
      </div>

      <main className="container mx-auto px-4 py-8">
        <Tabs defaultValue="ai" className="space-y-6">
          <TabsList className="bg-white shadow-sm border">
            <TabsTrigger value="ai" className="data-[state=active]:bg-primary data-[state=active]:text-white">
              <Bot className="w-4 h-4 mr-2" /> {t('admin.ai_agents')}
            </TabsTrigger>
            <TabsTrigger value="programs" className="data-[state=active]:bg-primary data-[state=active]:text-white">
              <BookOpen className="w-4 h-4 mr-2" /> {t('admin.programs')}
            </TabsTrigger>
            <TabsTrigger value="users" className="data-[state=active]:bg-primary data-[state=active]:text-white">
              <Users className="w-4 h-4 mr-2" /> {t('admin.users')}
            </TabsTrigger>
          </TabsList>

          <TabsContent value="ai">
            <Card className="mb-6">
              <CardHeader className="pb-3">
                <CardDescription className="text-sm">
                  {t('admin.ai_team_subtitle')}
                </CardDescription>
              </CardHeader>
            </Card>
            <AIAdminConsole />
          </TabsContent>

          <TabsContent value="programs">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <BookOpen className="w-5 h-5 text-primary" />
                  {t('admin.manage_programs')}
                </CardTitle>
                <Button size="sm" data-testid="button-add-program">
                  <Plus className="w-4 h-4 mr-2" /> {t('admin.add_program')}
                </Button>
              </CardHeader>
              <CardContent>
                {programsLoading ? (
                  <div className="flex justify-center py-8">
                    <Loader2 className="w-6 h-6 animate-spin text-primary" />
                  </div>
                ) : programs.length > 0 ? (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>{lang === 'fr' ? 'Titre' : 'Title'}</TableHead>
                        <TableHead>{lang === 'fr' ? 'Catégorie' : 'Category'}</TableHead>
                        <TableHead>{lang === 'fr' ? 'Niveau' : 'Level'}</TableHead>
                        <TableHead>{lang === 'fr' ? 'Cible' : 'Target'}</TableHead>
                        <TableHead className="text-right">{t('common.actions')}</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {programs.map((program: Program) => (
                        <TableRow key={program.id} data-testid={`row-program-${program.id}`}>
                          <TableCell className="font-medium">{program.title}</TableCell>
                          <TableCell>
                            <Badge variant="outline" className="bg-primary/5 border-primary/20">
                              {program.category}
                            </Badge>
                          </TableCell>
                          <TableCell>{program.level || (lang === 'fr' ? 'Tous niveaux' : 'All Levels')}</TableCell>
                          <TableCell className="text-sm text-muted-foreground">
                            {program.targetRole || (lang === 'fr' ? 'Tous' : 'All Users')}
                          </TableCell>
                          <TableCell className="text-right">
                            <Button variant="ghost" size="sm">{t('common.edit')}</Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                ) : (
                  <div className="text-center py-12 text-muted-foreground">
                    <BookOpen className="w-10 h-10 mx-auto mb-3 text-gray-300" />
                    <p>{t('admin.no_programs')}</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="users">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <Users className="w-5 h-5 text-primary" />
                  {t('admin.all_users')}
                </CardTitle>
                <Button size="sm" data-testid="button-add-user">
                  <Plus className="w-4 h-4 mr-2" /> {t('admin.add_user')}
                </Button>
              </CardHeader>
              <CardContent>
                {usersLoading ? (
                  <div className="flex justify-center py-8">
                    <Loader2 className="w-6 h-6 animate-spin text-primary" />
                  </div>
                ) : usersError ? (
                  <div className="text-center py-12 text-muted-foreground">
                    <User className="w-10 h-10 mx-auto mb-3 text-gray-300" />
                    <p>{lang === 'fr' ? "Impossible de charger les utilisateurs. Vous n'avez peut-être pas accès admin." : "Unable to load users. You may not have admin access."}</p>
                  </div>
                ) : users.length > 0 ? (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>{t('common.name')}</TableHead>
                        <TableHead>{t('auth.username.label')}</TableHead>
                        <TableHead>{t('common.email')}</TableHead>
                        <TableHead>{t('common.role')}</TableHead>
                        <TableHead className="text-right">{t('common.actions')}</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {users.map((user: UserProfile) => (
                        <TableRow key={user.id} data-testid={`row-user-${user.id}`}>
                          <TableCell className="font-medium">{user.name || '--'}</TableCell>
                          <TableCell>{user.username}</TableCell>
                          <TableCell className="text-muted-foreground">{user.email || '--'}</TableCell>
                          <TableCell>
                            <Badge variant="outline" className={getRoleBadgeStyle(user.role)}>
                              {user.role}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-right">
                            <Button variant="ghost" size="sm">{t('common.edit')}</Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                ) : (
                  <div className="text-center py-12 text-muted-foreground">
                    <User className="w-10 h-10 mx-auto mb-3 text-gray-300" />
                    <p>{t('admin.no_users')}</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
