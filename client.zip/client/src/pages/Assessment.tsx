import { useState } from "react";
import { useLocation } from "wouter";
import { Navbar } from "@/components/layout/Navbar";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Checkbox } from "@/components/ui/checkbox";
import { Progress } from "@/components/ui/progress";
import { ArrowRight, ArrowLeft, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { api } from "@/lib/api";

// Note: Assessment UI uses static steps for optimal wizard experience
// Submission goes to real API which calculates risk score and updates health profile
const STEPS = [
  { id: 1, title: "Basics", description: "Let's start with some basic information." },
  { id: 2, title: "History", description: "Tell us about your family health history." },
  { id: 3, title: "Lifestyle", description: "How about your daily habits?" },
  { id: 4, title: "Symptoms", description: "Are you experiencing any of these?" },
];

export default function Assessment() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [currentStep, setCurrentStep] = useState(1);

  const [formData, setFormData] = useState({
    age: "",
    height: "",
    weight: "",
    systolic: "",
    diastolic: "",
    familyHistory: [] as string[],
    activityLevel: "moderate",
    smoking: "no",
    symptoms: [] as string[],
  });

  const submitMutation = useMutation({
    mutationFn: async () => {
      const heightM = parseFloat(formData.height) / 100;
      const weightKg = parseFloat(formData.weight);
      const bmi = heightM > 0 ? weightKg / (heightM * heightM) : 22;

      const answers = {
        age: formData.age,
        bmi: bmi.toFixed(1),
        familyHistoryDiabetes: formData.familyHistory.includes('Type 2 Diabetes'),
        familyHistoryHeartDisease: formData.familyHistory.includes('Heart Disease'),
        familyHistoryHighBloodPressure: formData.familyHistory.includes('High Blood Pressure'),
        familyHistoryCancer: formData.familyHistory.includes('Breast Cancer'),
        smoking: formData.smoking,
        exercise: formData.activityLevel === 'sedentary' ? 'none' : formData.activityLevel === 'moderate' ? 'low' : 'moderate',
        diet: 'average',
        alcohol: 'none',
      };

      return api.assessment.submit(answers);
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['healthProfile'] });
      toast({
        title: "Assessment Completed",
        description: `Your health risk score is ${data.riskScore} (${data.riskLevel} risk).`,
      });
      setLocation("/dashboard?assessment=completed");
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to submit assessment. Please try again.",
        variant: "destructive",
      });
    },
  });

  const updateField = (field: string, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const toggleArrayField = (field: 'familyHistory' | 'symptoms', value: string) => {
    setFormData(prev => {
      const current = prev[field];
      if (current.includes(value)) {
        return { ...prev, [field]: current.filter(i => i !== value) };
      } else {
        return { ...prev, [field]: [...current, value] };
      }
    });
  };

  const nextStep = () => {
    if (currentStep < STEPS.length) {
      setCurrentStep(c => c + 1);
    } else {
      submitMutation.mutate();
    }
  };

  const prevStep = () => {
    if (currentStep > 1) {
      setCurrentStep(c => c - 1);
    }
  };

  const progress = (currentStep / STEPS.length) * 100;

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col pb-20">
      <Navbar />

      <div className="container mx-auto px-4 py-10 max-w-2xl">
        <div className="mb-8">
          <div className="flex justify-between items-end mb-2">
            <h1 className="font-serif text-3xl font-bold text-foreground">Health Assessment</h1>
            <span className="text-sm font-medium text-muted-foreground">Step {currentStep} of {STEPS.length}</span>
          </div>
          <Progress value={progress} className="h-2" />
        </div>

        <Card className="border-none shadow-lg">
          <CardHeader>
            <CardTitle>{STEPS[currentStep - 1].title}</CardTitle>
            <CardDescription>{STEPS[currentStep - 1].description}</CardDescription>
          </CardHeader>
          <CardContent className="min-h-[300px]">
            
            {/* Step 1: Basics */}
            {currentStep === 1 && (
              <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-300">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="age">Age</Label>
                    <Input 
                      id="age" type="number" placeholder="30" 
                      value={formData.age} onChange={e => updateField('age', e.target.value)} 
                      data-testid="input-age"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="weight">Weight (kg)</Label>
                    <Input 
                      id="weight" type="number" placeholder="65" 
                      value={formData.weight} onChange={e => updateField('weight', e.target.value)}
                      data-testid="input-weight"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                   <Label htmlFor="height">Height (cm)</Label>
                   <Input 
                    id="height" type="number" placeholder="165" 
                    value={formData.height} onChange={e => updateField('height', e.target.value)}
                    data-testid="input-height"
                   />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="systolic">BP Systolic (mmHg)</Label>
                    <Input 
                      id="systolic" type="number" placeholder="120" 
                      value={formData.systolic} onChange={e => updateField('systolic', e.target.value)}
                      data-testid="input-systolic"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="diastolic">BP Diastolic (mmHg)</Label>
                    <Input 
                      id="diastolic" type="number" placeholder="80" 
                      value={formData.diastolic} onChange={e => updateField('diastolic', e.target.value)}
                      data-testid="input-diastolic"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* Step 2: Family History */}
            {currentStep === 2 && (
              <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-300">
                <Label className="text-base">Does anyone in your immediate family have:</Label>
                <div className="space-y-4">
                  {['Type 2 Diabetes', 'High Blood Pressure', 'Breast Cancer', 'Heart Disease'].map((item) => (
                    <div key={item} className="flex items-center space-x-2 p-3 rounded-lg border hover:bg-gray-50 transition-colors">
                      <Checkbox 
                        id={item} 
                        checked={formData.familyHistory.includes(item)}
                        onCheckedChange={() => toggleArrayField('familyHistory', item)}
                        data-testid={`checkbox-${item.toLowerCase().replace(/ /g, '-')}`}
                      />
                      <Label htmlFor={item} className="flex-1 cursor-pointer font-normal">{item}</Label>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Step 3: Lifestyle */}
            {currentStep === 3 && (
              <div className="space-y-8 animate-in fade-in slide-in-from-right-4 duration-300">
                <div className="space-y-3">
                  <Label className="text-base">Physical Activity Level</Label>
                  <RadioGroup value={formData.activityLevel} onValueChange={(val) => updateField('activityLevel', val)}>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="sedentary" id="sedentary" data-testid="radio-sedentary" />
                      <Label htmlFor="sedentary">Sedentary (Little to no exercise)</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="moderate" id="moderate" data-testid="radio-moderate" />
                      <Label htmlFor="moderate">Moderate (1-3 times/week)</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="active" id="active" data-testid="radio-active" />
                      <Label htmlFor="active">Active (3-5 times/week)</Label>
                    </div>
                  </RadioGroup>
                </div>
                
                <div className="space-y-3">
                  <Label className="text-base">Do you smoke?</Label>
                  <RadioGroup value={formData.smoking} onValueChange={(val) => updateField('smoking', val)}>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="yes" id="smoke-yes" data-testid="radio-smoke-yes" />
                      <Label htmlFor="smoke-yes">Yes</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="no" id="smoke-no" data-testid="radio-smoke-no" />
                      <Label htmlFor="smoke-no">No</Label>
                    </div>
                  </RadioGroup>
                </div>
              </div>
            )}

            {/* Step 4: Symptoms */}
            {currentStep === 4 && (
              <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-300">
                <Label className="text-base">Are you currently experiencing:</Label>
                <div className="grid grid-cols-1 gap-3">
                  {['Frequent thirst or urination', 'Unexplained weight loss', 'Lump or thickening in breast', 'Shortness of breath', 'Chronic fatigue'].map((item) => (
                    <div key={item} className="flex items-center space-x-2 p-3 rounded-lg border hover:bg-gray-50 transition-colors">
                      <Checkbox 
                        id={item} 
                        checked={formData.symptoms.includes(item)}
                        onCheckedChange={() => toggleArrayField('symptoms', item)}
                        data-testid={`checkbox-symptom-${item.toLowerCase().replace(/ /g, '-').substring(0, 20)}`}
                      />
                      <Label htmlFor={item} className="flex-1 cursor-pointer font-normal">{item}</Label>
                    </div>
                  ))}
                </div>
              </div>
            )}

          </CardContent>
          <CardFooter className="flex justify-between border-t bg-gray-50/50 p-6">
            <Button 
              variant="outline" 
              onClick={prevStep} 
              disabled={currentStep === 1 || submitMutation.isPending}
              data-testid="button-previous"
            >
              <ArrowLeft className="w-4 h-4 mr-2" /> Previous
            </Button>
            
            <Button 
              onClick={nextStep} 
              disabled={submitMutation.isPending}
              className="bg-primary hover:bg-primary/90 text-white"
              data-testid="button-next"
            >
              {currentStep === STEPS.length ? (
                 submitMutation.isPending ? (
                   <>
                     <Loader2 className="w-4 h-4 mr-2 animate-spin" /> Analyzing...
                   </>
                 ) : "Submit Assessment"
              ) : (
                <>Next <ArrowRight className="w-4 h-4 ml-2" /></>
              )}
            </Button>
          </CardFooter>
        </Card>
      </div>
    </div>
  );
}
