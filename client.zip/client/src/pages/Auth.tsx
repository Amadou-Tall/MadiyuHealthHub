import { useState } from "react";
import { Navbar } from "@/components/layout/Navbar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useAuth } from "@/hooks/use-auth";
import { Loader2 } from "lucide-react";
import { t, getLang } from "@/lib/i18n";

export default function Auth() {
  const { login, register, isLoading } = useAuth();
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const lang = getLang();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await login(username, password);
    } catch (error) {
      console.error('Login error:', error);
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await register(username, password, name, email);
    } catch (error) {
      console.error('Registration error:', error);
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navbar />
      <div className="flex-1 flex items-center justify-center p-4">
        <Card className="w-full max-w-md shadow-xl border-primary/10">
          <CardHeader className="text-center space-y-2">
            <CardTitle className="font-serif text-2xl text-primary">
              {t('auth.login.title')}
            </CardTitle>
            <CardDescription>
              {t('auth.login.subtitle')}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="login" className="w-full">
              <TabsList className="grid w-full grid-cols-2 mb-6">
                <TabsTrigger value="login">{t('nav.login')}</TabsTrigger>
                <TabsTrigger value="register">{lang === 'fr' ? 'Inscription' : 'Register'}</TabsTrigger>
              </TabsList>
              
              <TabsContent value="login">
                <form onSubmit={handleLogin} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="username">{t('auth.username.label')}</Label>
                    <Input 
                      id="username" 
                      type="text" 
                      placeholder={lang === 'fr' ? 'votre_nom' : 'johndoe'}
                      required 
                      value={username}
                      onChange={(e) => setUsername(e.target.value)}
                      data-testid="input-login-username"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="password">{t('auth.password.label')}</Label>
                    <Input 
                      id="password" 
                      type="password" 
                      required 
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      data-testid="input-login-password"
                    />
                  </div>
                  <Button type="submit" className="w-full bg-primary hover:bg-primary/90" disabled={isLoading} data-testid="button-login-submit">
                    {isLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : t('auth.submit_login')}
                  </Button>
                </form>
              </TabsContent>
              
              <TabsContent value="register">
                <form onSubmit={handleRegister} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="reg-username">{t('auth.username.label')}</Label>
                    <Input 
                      id="reg-username" 
                      type="text"
                      placeholder={lang === 'fr' ? 'votre_nom' : 'johndoe'}
                      required 
                      value={username}
                      onChange={(e) => setUsername(e.target.value)}
                      data-testid="input-register-username"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="name">{t('auth.name.label')} ({lang === 'fr' ? 'Optionnel' : 'Optional'})</Label>
                    <Input 
                      id="name" 
                      placeholder={lang === 'fr' ? 'Marie Dupont' : 'Jane Doe'} 
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      data-testid="input-register-name"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="reg-email">{t('auth.email.label')} ({lang === 'fr' ? 'Optionnel' : 'Optional'})</Label>
                    <Input 
                      id="reg-email" 
                      type="email" 
                      placeholder={lang === 'fr' ? 'marie@exemple.com' : 'jane@example.com'} 
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      data-testid="input-register-email"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="reg-password">{t('auth.password.label')}</Label>
                    <Input 
                      id="reg-password" 
                      type="password" 
                      required 
                      minLength={6}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      data-testid="input-register-password"
                    />
                    <p className="text-xs text-muted-foreground">
                      {lang === 'fr' ? 'Au moins 6 caractères' : 'At least 6 characters'}
                    </p>
                  </div>
                  <Button type="submit" className="w-full bg-secondary hover:bg-secondary/90 text-white" disabled={isLoading} data-testid="button-register-submit">
                     {isLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : t('auth.submit_register')}
                  </Button>
                </form>
              </TabsContent>
            </Tabs>
          </CardContent>
          <CardFooter className="flex justify-center">
            <p className="text-xs text-muted-foreground text-center">
              {lang === 'fr' 
                ? "En continuant, vous acceptez nos Conditions d'utilisation et notre Politique de confidentialité."
                : "By continuing, you agree to our Terms of Service and Privacy Policy."}
            </p>
          </CardFooter>
        </Card>
      </div>
    </div>
  );
}
