import { useState } from "react";
import { Navbar } from "@/components/layout/Navbar";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Users, MessageSquare, Loader2, ChevronLeft, Send } from "lucide-react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, type CommunityGroup, type CommunityPost, type CommunityReply } from "@/lib/api";
import { formatDistanceToNow } from "date-fns";
import { fr, enUS } from "date-fns/locale";
import { t, getLang } from "@/lib/i18n";

export default function Community() {
  const [selectedGroup, setSelectedGroup] = useState<CommunityGroup | null>(null);
  const [selectedPost, setSelectedPost] = useState<CommunityPost | null>(null);
  const [newPostContent, setNewPostContent] = useState("");
  const [newReplyContent, setNewReplyContent] = useState("");
  const [showNewPost, setShowNewPost] = useState(false);
  const queryClient = useQueryClient();
  const lang = getLang();
  const dateLocale = lang === 'fr' ? fr : enUS;

  const { data: groups, isLoading: groupsLoading } = useQuery({
    queryKey: ['communityGroups'],
    queryFn: () => api.community.getGroups(),
  });

  const { data: groupData, isLoading: postsLoading } = useQuery({
    queryKey: ['communityPosts', selectedGroup?.slug],
    queryFn: () => api.community.getGroupPosts(selectedGroup!.slug),
    enabled: !!selectedGroup,
  });

  const { data: repliesData, isLoading: repliesLoading } = useQuery({
    queryKey: ['communityReplies', selectedPost?.id],
    queryFn: () => api.community.getPostReplies(selectedPost!.id),
    enabled: !!selectedPost,
  });

  const createPostMutation = useMutation({
    mutationFn: (content: string) => api.community.createPost(selectedGroup!.slug, content),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['communityPosts', selectedGroup?.slug] });
      setNewPostContent("");
      setShowNewPost(false);
    },
  });

  const createReplyMutation = useMutation({
    mutationFn: (content: string) => api.community.createReply(selectedPost!.id, content),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['communityReplies', selectedPost?.id] });
      setNewReplyContent("");
    },
  });

  if (groupsLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="flex items-center justify-center py-32">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      </div>
    );
  }

  if (selectedPost) {
    return (
      <div className="min-h-screen bg-background pb-20">
        <Navbar />
        
        <div className="bg-secondary/10 py-6">
          <div className="container mx-auto px-4">
            <Button 
              variant="ghost" 
              onClick={() => setSelectedPost(null)}
              className="mb-4"
              data-testid="button-back-to-group"
            >
              <ChevronLeft className="w-4 h-4 mr-2" /> {t('common.back')} {selectedGroup?.name}
            </Button>
          </div>
        </div>

        <main className="container mx-auto px-4 py-6 max-w-3xl">
          <Card className="mb-6">
            <CardContent className="pt-6">
              <div className="flex items-start gap-3 mb-4">
                <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center text-primary font-bold">
                  {selectedPost.author.name?.[0] || selectedPost.author.username[0]}
                </div>
                <div className="flex-1">
                  <p className="font-medium">{selectedPost.author.name || selectedPost.author.username}</p>
                  <p className="text-xs text-muted-foreground">
                    {formatDistanceToNow(new Date(selectedPost.createdAt), { addSuffix: true, locale: dateLocale })}
                  </p>
                </div>
              </div>
              <p className="text-foreground whitespace-pre-wrap">{selectedPost.content}</p>
            </CardContent>
          </Card>

          <h3 className="font-serif text-lg font-bold mb-4">{t('community.replies')}</h3>

          {repliesLoading ? (
            <div className="flex justify-center py-8">
              <Loader2 className="w-6 h-6 animate-spin text-primary" />
            </div>
          ) : (
            <div className="space-y-4 mb-6">
              {repliesData?.replies && repliesData.replies.length > 0 ? (
                repliesData.replies.map((reply: CommunityReply) => (
                  <Card key={reply.id} className="bg-muted/30">
                    <CardContent className="pt-4">
                      <div className="flex items-start gap-3">
                        <div className="w-8 h-8 rounded-full bg-secondary/50 flex items-center justify-center text-sm font-bold">
                          {reply.author.name?.[0] || reply.author.username[0]}
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <p className="font-medium text-sm">{reply.author.name || reply.author.username}</p>
                            <span className="text-xs text-muted-foreground">
                              {formatDistanceToNow(new Date(reply.createdAt), { addSuffix: true, locale: dateLocale })}
                            </span>
                          </div>
                          <p className="text-sm">{reply.content}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))
              ) : (
                <p className="text-center text-muted-foreground py-8">{t('community.no_replies')}</p>
              )}
            </div>
          )}

          <div className="flex gap-2">
            <Textarea
              placeholder={t('community.write_reply')}
              value={newReplyContent}
              onChange={(e) => setNewReplyContent(e.target.value)}
              className="flex-1"
              data-testid="input-reply"
            />
            <Button 
              onClick={() => createReplyMutation.mutate(newReplyContent)}
              disabled={!newReplyContent.trim() || createReplyMutation.isPending}
              data-testid="button-submit-reply"
            >
              {createReplyMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
            </Button>
          </div>
        </main>
      </div>
    );
  }

  if (selectedGroup) {
    return (
      <div className="min-h-screen bg-background pb-20">
        <Navbar />
        
        <div className="bg-secondary/10 py-6">
          <div className="container mx-auto px-4">
            <Button 
              variant="ghost" 
              onClick={() => setSelectedGroup(null)}
              className="mb-4"
              data-testid="button-back-to-groups"
            >
              <ChevronLeft className="w-4 h-4 mr-2" /> {t('community.back_to_groups')}
            </Button>
            <h1 className="font-serif text-3xl font-bold text-foreground">{selectedGroup.name}</h1>
            <p className="text-muted-foreground mt-2">{selectedGroup.description}</p>
          </div>
        </div>

        <main className="container mx-auto px-4 py-6 max-w-3xl">
          <div className="flex justify-between items-center mb-6">
            <h2 className="font-serif text-xl font-bold">{t('community.discussion')}</h2>
            <Dialog open={showNewPost} onOpenChange={setShowNewPost}>
              <DialogTrigger asChild>
                <Button data-testid="button-new-post">{t('community.new_post')}</Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>{t('community.create_post')}</DialogTitle>
                </DialogHeader>
                <Textarea
                  placeholder={t('community.share_something')}
                  value={newPostContent}
                  onChange={(e) => setNewPostContent(e.target.value)}
                  rows={5}
                  data-testid="input-new-post"
                />
                <Button 
                  onClick={() => createPostMutation.mutate(newPostContent)}
                  disabled={!newPostContent.trim() || createPostMutation.isPending}
                  className="w-full"
                  data-testid="button-submit-post"
                >
                  {createPostMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
                  {t('community.post')}
                </Button>
              </DialogContent>
            </Dialog>
          </div>

          {postsLoading ? (
            <div className="flex justify-center py-8">
              <Loader2 className="w-6 h-6 animate-spin text-primary" />
            </div>
          ) : (
            <div className="space-y-4">
              {groupData?.posts && groupData.posts.length > 0 ? (
                groupData.posts.map((post: CommunityPost) => (
                  <Card 
                    key={post.id} 
                    className="cursor-pointer hover:shadow-md transition-shadow"
                    onClick={() => setSelectedPost(post)}
                    data-testid={`card-post-${post.id}`}
                  >
                    <CardContent className="pt-4">
                      <div className="flex items-start gap-3">
                        <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center text-primary font-bold">
                          {post.author.name?.[0] || post.author.username[0]}
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <p className="font-medium">{post.author.name || post.author.username}</p>
                            <span className="text-xs text-muted-foreground">
                              {formatDistanceToNow(new Date(post.createdAt), { addSuffix: true, locale: dateLocale })}
                            </span>
                          </div>
                          <p className="text-sm line-clamp-3">{post.content}</p>
                        </div>
                        <MessageSquare className="w-4 h-4 text-muted-foreground" />
                      </div>
                    </CardContent>
                  </Card>
                ))
              ) : (
                <Card className="text-center py-12">
                  <CardContent>
                    <MessageSquare className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
                    <p className="text-muted-foreground">{t('community.no_posts')}</p>
                  </CardContent>
                </Card>
              )}
            </div>
          )}
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background pb-20">
      <Navbar />
      
      <div className="bg-secondary/10 py-12">
        <div className="container mx-auto px-4 text-center">
          <h1 className="font-serif text-4xl font-bold text-foreground mb-4">{t('community.title')}</h1>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            {t('community.subtitle')}
          </p>
        </div>
      </div>

      <main className="container mx-auto px-4 py-10">
        {groups && groups.length > 0 ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {groups.map((group: CommunityGroup) => (
              <Card 
                key={group.id} 
                className="hover:shadow-lg transition-all duration-300 border-none shadow-sm group cursor-pointer"
                onClick={() => setSelectedGroup(group)}
                data-testid={`card-group-${group.slug}`}
              >
                <CardHeader className="pb-2">
                  <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center text-primary mb-4 group-hover:scale-110 transition-transform">
                    <Users className="w-6 h-6" />
                  </div>
                  <h3 className="font-serif text-xl font-bold">{group.name}</h3>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground text-sm mb-6 min-h-[40px]">
                    {group.description}
                  </p>
                  
                  <div className="flex items-center justify-between pt-4 border-t">
                    <span className="text-xs font-medium text-muted-foreground flex items-center gap-1">
                      <Users className="w-3 h-3" /> {group.audienceType}
                    </span>
                    <Button size="sm" variant="outline" className="rounded-full">
                      {t('community.view_group')}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <Card className="text-center py-12 max-w-md mx-auto">
            <CardContent>
              <Users className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
              <p className="text-muted-foreground">{t('community.no_groups')}</p>
            </CardContent>
          </Card>
        )}
      </main>
    </div>
  );
}
