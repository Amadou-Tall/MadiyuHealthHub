import { Navbar } from "@/components/layout/Navbar";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { Activity, ArrowRight, Droplet, Moon, HeartPulse, AlertTriangle, ClipboardCheck, Loader2 } from "lucide-react";
import { Link, useSearch } from "wouter";
import { Badge } from "@/components/ui/badge";
import { t, getLang } from "@/lib/i18n";
import { useQuery } from "@tanstack/react-query";
import { api, type HealthProfile, type Program } from "@/lib/api";

export default function Dashboard() {
  const { user } = useAuth();
  const search = useSearch();
  const lang = getLang();

  const { data: healthProfile, isLoading: profileLoading } = useQuery({
    queryKey: ['healthProfile'],
    queryFn: () => api.health.getProfile(),
  });

  const { data: logsData, isLoading: logsLoading } = useQuery({
    queryKey: ['healthLogs'],
    queryFn: () => api.health.getLogs(5, 0),
  });

  const { data: recommendedData, isLoading: programsLoading } = useQuery({
    queryKey: ['recommendedPrograms'],
    queryFn: () => api.programs.getRecommended(),
  });

  const { data: allProgramsData } = useQuery({
    queryKey: ['programs'],
    queryFn: () => api.programs.getAll(),
  });

  const isAssessmentCompleted = search.includes("assessment=completed") || 
    (healthProfile?.riskScore !== undefined && healthProfile?.riskScore > 0);

  const recommendedPrograms = recommendedData?.programs || [];
  const logs = logsData?.logs || [];
  const firstProgram = allProgramsData?.programs?.[0];

  const formatLogType = (type: string) => {
    const typeMap: Record<string, string> = {
      'BP': t('dash.log_bp'),
      'Glucose': t('dash.log_glucose'),
      'Mood': t('dash.log_mood'),
      'Weight': t('dash.log_weight'),
      'Sleep': t('dash.log_sleep'),
    };
    return typeMap[type] || type;
  };

  const formatLogValue = (log: any) => {
    if (log.valueNumber !== null && log.valueNumber !== undefined) {
      return `${log.valueNumber} ${log.unit || ''}`;
    }
    return log.valueText || '-';
  };

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString(lang === 'fr' ? 'fr-FR' : 'en-US', { month: 'short', day: 'numeric' });
  };

  return (
    <div className="min-h-screen bg-background pb-20">
      <Navbar />
      
      <main className="container mx-auto px-4 pt-8">
        <div className="mb-8 flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <h1 className="font-serif text-3xl font-bold text-foreground">
              {t('dash.welcome')} {user?.name}
            </h1>
            <p className="text-muted-foreground mt-1">{t('dash.health_overview')}</p>
          </div>
          
          {!isAssessmentCompleted && (
             <Link href="/assessment">
               <Button className="bg-secondary hover:bg-secondary/90 text-white animate-pulse shadow-lg shadow-secondary/20">
                 <ClipboardCheck className="w-4 h-4 mr-2" /> {t('dash.complete_assessment')}
               </Button>
             </Link>
          )}
        </div>

        {/* Empowerment Message for Black Women */}
        <div className="mb-8 p-4 bg-gradient-to-r from-primary/10 via-secondary/10 to-primary/5 rounded-xl border border-primary/10">
          <p className="text-sm font-medium text-foreground/80 italic">
            "{t('dash.empowerment_message')}"
          </p>
        </div>

        {/* Health Overview Section */}
        {isAssessmentCompleted && (
          <section className="mb-10 animate-in slide-in-from-top-5 duration-500">
            <div className="grid md:grid-cols-3 gap-6">
              {/* Risk Score Card */}
              <Card className="bg-white border-none shadow-sm overflow-hidden relative">
                <div className={`absolute top-0 left-0 w-2 h-full ${healthProfile?.riskLevel === 'HIGH' ? 'bg-red-500' : healthProfile?.riskLevel === 'MODERATE' ? 'bg-yellow-500' : 'bg-green-500'}`}></div>
                <CardContent className="p-6 pl-8">
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="font-serif font-bold text-lg">{t('dash.risk_profile')}</h3>
                    <Badge className={
                      healthProfile?.riskLevel === 'HIGH' ? 'bg-red-100 text-red-700 hover:bg-red-100' : 
                      healthProfile?.riskLevel === 'MODERATE' ? 'bg-yellow-100 text-yellow-700 hover:bg-yellow-100' : 
                      'bg-green-100 text-green-700 hover:bg-green-100'
                    }>
                      {healthProfile?.riskLevel === 'HIGH' ? t('dash.risk_high') : 
                       healthProfile?.riskLevel === 'MODERATE' ? t('dash.risk_moderate') : 
                       t('dash.risk_low')}
                    </Badge>
                  </div>
                  <div className="mt-4 flex items-end gap-2">
                    <span className="text-4xl font-bold">{healthProfile?.riskScore || 0}</span>
                    <span className="text-sm text-muted-foreground mb-1">{t('dash.score_of')}</span>
                  </div>
                  <p className="text-xs text-muted-foreground mt-2">
                    {t('dash.risk_recommendation')}
                  </p>
                </CardContent>
              </Card>

              {/* Stats */}
              <Card className="bg-white border-none shadow-sm">
                <CardContent className="p-6">
                  <h3 className="font-serif font-bold text-lg mb-4">{t('dash.vitals')}</h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-xs text-muted-foreground">{t('dash.bmi')}</p>
                      <p className="text-xl font-bold">{healthProfile?.bmi?.toFixed(1) || '--'}</p>
                      <span className={`text-[10px] px-1.5 py-0.5 rounded ${
                        healthProfile?.bmi && healthProfile.bmi < 25 
                          ? 'text-green-600 bg-green-50' 
                          : healthProfile?.bmi && healthProfile.bmi < 30 
                            ? 'text-yellow-600 bg-yellow-50'
                            : 'text-red-600 bg-red-50'
                      }`}>
                        {healthProfile?.bmi ? (healthProfile.bmi < 25 ? t('dash.bmi_normal') : healthProfile.bmi < 30 ? t('dash.bmi_overweight') : t('dash.bmi_obese')) : t('dash.na')}
                      </span>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">{t('dash.blood_pressure')}</p>
                      <p className="text-xl font-bold">{healthProfile?.bloodPressure || '--'}</p>
                      <span className="text-[10px] text-green-600 bg-green-50 px-1.5 py-0.5 rounded">
                        {healthProfile?.bloodPressure ? t('dash.bp_recorded') : t('dash.na')}
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Quick Actions */}
              <Card className="bg-primary text-white border-none shadow-md">
                <CardContent className="p-6 flex flex-col justify-between h-full">
                  <div>
                    <h3 className="font-serif font-bold text-lg mb-2">{t('dash.daily_log')}</h3>
                    <p className="text-primary-foreground/80 text-sm">
                      {t('dash.log_vitals_desc')}
                    </p>
                  </div>
                  <Button variant="secondary" size="sm" className="w-full mt-4 bg-white text-primary hover:bg-white/90">
                    {t('dash.log_vitals')}
                  </Button>
                </CardContent>
              </Card>
            </div>
          </section>
        )}

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content Column */}
          <div className="lg:col-span-2 space-y-8">
            
            {/* My Programs */}
            <section>
              <div className="flex items-center justify-between mb-4">
                <h2 className="font-serif text-2xl font-bold">{t('dash.my_programs')}</h2>
                <Link href="/programs">
                  <Button variant="ghost" size="sm" className="text-primary">{t('common.view_all')}</Button>
                </Link>
              </div>

              {/* Enrolled Program Card */}
              {firstProgram ? (
                <Card className="overflow-hidden border-none shadow-md mb-4">
                  <div className="flex flex-col sm:flex-row">
                    <div className="sm:w-40 h-40 sm:h-auto relative bg-gradient-to-br from-primary/20 to-primary/5">
                      {firstProgram.imageUrl ? (
                        <img 
                          src={firstProgram.imageUrl} 
                          alt={firstProgram.title}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center text-primary">
                          <ClipboardCheck className="w-12 h-12" />
                        </div>
                      )}
                    </div>
                    <div className="p-5 flex-1 flex flex-col justify-center">
                      <div className="flex justify-between items-start mb-2">
                        <Badge className="mb-2 bg-primary/10 text-primary hover:bg-primary/20 border-none">{t('programs.active')}</Badge>
                        <span className="text-xs text-muted-foreground">{t('dash.week_x_of_y').replace('{0}', '2').replace('{1}', '4')}</span>
                      </div>
                      <h3 className="font-serif text-lg font-bold mb-1">{firstProgram.title}</h3>
                      <div className="space-y-2 mt-3">
                        <div className="flex justify-between text-xs font-medium">
                          <span>{t('programs.progress')}</span>
                          <span>45%</span>
                        </div>
                        <Progress value={45} className="h-1.5" />
                      </div>
                      <div className="mt-4">
                        <Link href={`/programs/${firstProgram.id}`}>
                          <Button size="sm" className="bg-primary text-white hover:bg-primary/90">
                            {t('programs.continue')} <ArrowRight className="ml-2 w-3 h-3" />
                          </Button>
                        </Link>
                      </div>
                    </div>
                  </div>
                </Card>
              ) : (
                <Card className="border-none shadow-md p-8 text-center">
                  <p className="text-muted-foreground">{t('dash.no_programs')}</p>
                  <Link href="/programs">
                    <Button className="mt-4">{t('dash.browse_programs')}</Button>
                  </Link>
                </Card>
              )}
            </section>

            {/* Recommended Programs */}
            <section>
              <h2 className="font-serif text-2xl font-bold mb-4">{t('dash.recommended')}</h2>
              {programsLoading ? (
                <div className="flex items-center justify-center py-8">
                  <Loader2 className="w-6 h-6 animate-spin text-primary" />
                </div>
              ) : (
                <div className="grid sm:grid-cols-2 gap-4">
                  {recommendedPrograms.slice(0, 4).map((program: Program) => (
                    <Card key={program.id} className="border-none shadow-sm hover:shadow-md transition-shadow group cursor-pointer">
                      <CardContent className="p-0">
                        <div className="relative h-32 overflow-hidden rounded-t-lg bg-gradient-to-br from-primary/20 to-secondary/20">
                          {program.imageUrl ? (
                            <img src={program.imageUrl} alt={program.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center">
                              <ClipboardCheck className="w-8 h-8 text-primary/50" />
                            </div>
                          )}
                          <div className="absolute top-2 left-2">
                            <Badge className="bg-white/90 text-xs text-foreground backdrop-blur-sm hover:bg-white">{program.category}</Badge>
                          </div>
                        </div>
                        <div className="p-4">
                          <h3 className="font-bold font-serif text-base line-clamp-1 mb-1">{program.title}</h3>
                          <p className="text-xs text-muted-foreground line-clamp-2 mb-3">{program.description}</p>
                          <Link href={`/programs/${program.id}`}>
                            <Button variant="outline" size="sm" className="w-full h-8 text-xs">{t('programs.view_details')}</Button>
                          </Link>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </section>
          </div>

          {/* Sidebar Area */}
          <div className="space-y-6">
            {/* Recent Activity / Logs */}
            <Card className="border-none shadow-sm">
              <CardHeader className="pb-3">
                <CardTitle className="font-serif text-lg">{t('dash.recent_activity')}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-0">
                {logsLoading ? (
                  <div className="flex items-center justify-center py-4">
                    <Loader2 className="w-5 h-5 animate-spin text-primary" />
                  </div>
                ) : logs.length > 0 ? (
                  logs.slice(0, 4).map((log: any, i: number) => (
                    <div key={log.id} className={`flex gap-3 items-start p-3 ${i !== logs.length - 1 ? 'border-b border-gray-50' : ''}`}>
                      <div className={`p-2 rounded-full flex-shrink-0 ${
                        log.type === 'BP' ? 'bg-red-50 text-red-600' : 
                        log.type === 'Sleep' ? 'bg-purple-50 text-purple-600' : 
                        log.type === 'Mood' ? 'bg-yellow-50 text-yellow-600' : 
                        'bg-blue-50 text-blue-600'
                      }`}>
                        {log.type === 'BP' ? <HeartPulse className="w-4 h-4" /> : 
                         log.type === 'Sleep' ? <Moon className="w-4 h-4" /> : 
                         log.type === 'Mood' ? <Activity className="w-4 h-4" /> : 
                         <ClipboardCheck className="w-4 h-4" />}
                      </div>
                      <div>
                        <p className="text-sm font-medium">{formatLogType(log.type)}</p>
                        <p className="text-xs font-bold text-foreground">{formatLogValue(log)}</p>
                        <p className="text-[10px] text-muted-foreground mt-0.5">{formatDate(log.createdAt)}</p>
                      </div>
                    </div>
                  ))
                ) : (
                  <p className="text-sm text-muted-foreground text-center py-4">{t('dash.no_activity')}</p>
                )}
              </CardContent>
            </Card>

            {/* AI Promo */}
            <Card className="bg-gradient-to-br from-secondary/20 to-secondary/5 border-secondary/20">
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 rounded-full bg-white shadow-sm mx-auto mb-4 flex items-center justify-center text-secondary">
                  <AlertTriangle className="w-6 h-6" />
                </div>
                <h3 className="font-serif font-bold mb-2">{t('dash.not_feeling_well')}</h3>
                <p className="text-sm text-muted-foreground mb-4">{t('dash.check_symptoms')}</p>
                <Link href="/ai">
                  <Button variant="outline" className="w-full border-secondary text-secondary hover:bg-secondary hover:text-white">
                    {t('nav.ai_nurse')}
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}
