import { useState } from "react";
import { Navbar } from "@/components/layout/Navbar";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Search, Star, Filter, Loader2, User } from "lucide-react";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { api, type ProfessionalProfile } from "@/lib/api";
import { t, getLang } from "@/lib/i18n";

const PROFESSION_TYPES_EN = [
  { value: "", label: "All Types" },
  { value: "NUTRITIONIST", label: "Nutritionists" },
  { value: "DOULA", label: "Doulas" },
  { value: "COACH", label: "Sleep Coaches" },
  { value: "THERAPIST", label: "Therapists" },
  { value: "LACTATION_CONSULTANT", label: "Lactation Consultants" },
];

const PROFESSION_TYPES_FR = [
  { value: "", label: "Tous les types" },
  { value: "NUTRITIONIST", label: "Nutritionnistes" },
  { value: "DOULA", label: "Doulas" },
  { value: "COACH", label: "Coaches Sommeil" },
  { value: "THERAPIST", label: "Thérapeutes" },
  { value: "LACTATION_CONSULTANT", label: "Consultantes Lactation" },
];

export default function Marketplace() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedType, setSelectedType] = useState("");
  const lang = getLang();
  const PROFESSION_TYPES = lang === 'fr' ? PROFESSION_TYPES_FR : PROFESSION_TYPES_EN;

  const { data: professionals, isLoading } = useQuery({
    queryKey: ['professionals', selectedType, searchTerm],
    queryFn: () => api.marketplace.getProfessionals({ 
      type: selectedType || undefined, 
      search: searchTerm || undefined 
    }),
  });

  const getProfessionLabel = (type: string) => {
    const found = PROFESSION_TYPES.find(p => p.value === type);
    return found ? found.label.replace(/s$/, '') : type;
  };

  return (
    <div className="min-h-screen bg-background pb-20">
      <Navbar />
      
      <div className="bg-white border-b py-12">
        <div className="container mx-auto px-4">
          <h1 className="font-serif text-4xl font-bold text-foreground mb-4">{t('marketplace.title')}</h1>
          <p className="text-muted-foreground text-lg max-w-2xl">
            {t('marketplace.subtitle')}
          </p>
        </div>
      </div>

      <main className="container mx-auto px-4 py-10">
        <div className="flex flex-col md:flex-row gap-4 mb-10 items-center justify-between">
          <div className="relative w-full md:max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground w-4 h-4" />
            <Input 
              placeholder={t('marketplace.search')}
              className="pl-10 bg-white"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              data-testid="input-search"
            />
          </div>
          <div className="flex gap-2 w-full md:w-auto overflow-x-auto pb-2 md:pb-0">
            {PROFESSION_TYPES.map(type => (
              <Button 
                key={type.value}
                variant={selectedType === type.value ? "outline" : "ghost"} 
                size="sm" 
                className={`rounded-full whitespace-nowrap ${selectedType === type.value ? 'bg-white' : ''}`}
                onClick={() => setSelectedType(type.value)}
                data-testid={`filter-${type.value || 'all'}`}
              >
                {type.value === "" && <Filter className="w-3.5 h-3.5 mr-2" />}
                {type.label}
              </Button>
            ))}
          </div>
        </div>

        {isLoading ? (
          <div className="flex items-center justify-center py-20">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
          </div>
        ) : professionals && professionals.length > 0 ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {professionals.map((pro: ProfessionalProfile) => (
              <Card key={pro.id} className="overflow-hidden hover:shadow-lg transition-all duration-300 border-none shadow-md group" data-testid={`card-professional-${pro.id}`}>
                <div className="relative h-64 overflow-hidden bg-gradient-to-br from-primary/20 to-secondary/20">
                  {pro.imageUrl ? (
                    <img 
                      src={pro.imageUrl} 
                      alt={pro.user?.name || "Professional"}
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center">
                      <User className="w-20 h-20 text-primary/40" />
                    </div>
                  )}
                  <div className="absolute top-3 left-3">
                    <Badge className="bg-white/90 text-foreground hover:bg-white backdrop-blur-sm shadow-sm">
                      {getProfessionLabel(pro.professionType)}
                    </Badge>
                  </div>
                  {pro.isVerified && (
                    <div className="absolute top-3 right-3">
                      <Badge className="bg-green-500/90 text-white hover:bg-green-500 backdrop-blur-sm shadow-sm">
                        {t('marketplace.verified')}
                      </Badge>
                    </div>
                  )}
                </div>
                <CardHeader className="pb-2">
                  <div className="flex justify-between items-start">
                     <h3 className="font-serif text-xl font-bold text-foreground leading-tight">
                       {pro.user?.name || "Professional"}
                     </h3>
                     {pro.yearsExperience && (
                       <div className="flex items-center gap-1 bg-blue-50 px-2 py-1 rounded-md">
                         <span className="text-xs font-medium text-blue-700">{pro.yearsExperience}+ {t('marketplace.years_exp')}</span>
                       </div>
                     )}
                  </div>
                </CardHeader>
                <CardContent className="pb-4">
                  <p className="text-muted-foreground text-sm line-clamp-2 mb-3">
                    {pro.bio || (lang === 'fr' ? "Professionnel(le) de santé expérimenté(e) prêt(e) à vous accompagner." : "Experienced healthcare professional ready to support your wellness journey.")}
                  </p>
                  {pro.specialties && pro.specialties.length > 0 && (
                    <div className="flex flex-wrap gap-1">
                      {pro.specialties.slice(0, 3).map((spec: string) => (
                        <span key={spec} className="text-[10px] bg-secondary/10 text-secondary-foreground px-2 py-1 rounded-full">
                          {spec}
                        </span>
                      ))}
                    </div>
                  )}
                  {pro.location && (
                    <p className="text-xs text-muted-foreground mt-2">{pro.location}</p>
                  )}
                </CardContent>
                <CardFooter className="pt-0 border-t p-4 bg-gray-50/50 flex items-center justify-between">
                  <div className="text-sm font-medium">
                    {pro.hourlyRate ? (
                      <>${pro.hourlyRate}<span className="text-muted-foreground font-normal">/hr</span></>
                    ) : (
                      <span className="text-muted-foreground">{t('marketplace.contact_rates')}</span>
                    )}
                  </div>
                  <Link href={`/marketplace/${pro.id}`}>
                    <Button size="sm" className="bg-primary text-white hover:bg-primary/90" data-testid={`button-view-${pro.id}`}>
                      {t('marketplace.view_profile')}
                    </Button>
                  </Link>
                </CardFooter>
              </Card>
            ))}
          </div>
        ) : (
          <Card className="text-center py-12 max-w-md mx-auto">
            <CardContent>
              <User className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
              <p className="text-muted-foreground">{t('marketplace.no_professionals')}</p>
            </CardContent>
          </Card>
        )}
      </main>
    </div>
  );
}
