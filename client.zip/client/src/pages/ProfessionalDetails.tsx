import { useParams } from "wouter";
import { Navbar } from "@/components/layout/Navbar";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Calendar as CalendarIcon, Clock, CheckCircle, Loader2, User, ChevronLeft } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, type BookingSlot } from "@/lib/api";
import { Link } from "wouter";
import NotFound from "@/pages/not-found";

const PROFESSION_LABELS: Record<string, string> = {
  NUTRITIONIST: "Nutritionist",
  DOULA: "Doula",
  COACH: "Sleep Coach",
  THERAPIST: "Therapist",
  LACTATION_CONSULTANT: "Lactation Consultant",
};

export default function ProfessionalDetails() {
  const { id } = useParams();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedSlot, setSelectedSlot] = useState<number | null>(null);

  const { data, isLoading, error } = useQuery({
    queryKey: ['professional', id],
    queryFn: () => api.marketplace.getProfessional(parseInt(id!)),
    enabled: !!id && !isNaN(parseInt(id!)),
  });

  const bookMutation = useMutation({
    mutationFn: () => api.marketplace.bookSlot({
      professionalId: data!.professional.id,
      slotId: selectedSlot!,
    }),
    onSuccess: () => {
      toast({
        title: "Booking Confirmed!",
        description: `You are booked with ${data?.professional.user?.name || 'the professional'}. Check your email for details.`,
      });
      setSelectedSlot(null);
      queryClient.invalidateQueries({ queryKey: ['professional', id] });
    },
    onError: () => {
      toast({
        title: "Booking Failed",
        description: "Unable to complete the booking. Please try again.",
        variant: "destructive",
      });
    },
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="flex items-center justify-center py-32">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      </div>
    );
  }

  if (error || !data) return <NotFound />;

  const { professional: pro, slots } = data;
  const availableSlots = slots.filter(s => !s.isBooked);

  return (
    <div className="min-h-screen bg-background pb-20">
      <Navbar />
      
      <div className="container mx-auto px-4 py-4">
        <Link href="/marketplace">
          <Button variant="ghost" className="mb-4" data-testid="button-back">
            <ChevronLeft className="w-4 h-4 mr-2" /> Back to Marketplace
          </Button>
        </Link>
      </div>

      <main className="container mx-auto px-4 pb-10">
        <div className="grid md:grid-cols-3 gap-8">
          <div className="md:col-span-2 space-y-8">
            <div className="flex flex-col md:flex-row gap-6 items-start">
               <div className="w-32 h-32 md:w-48 md:h-48 rounded-full overflow-hidden border-4 border-white shadow-lg flex-shrink-0 bg-gradient-to-br from-primary/20 to-secondary/20">
                 {pro.imageUrl ? (
                   <img src={pro.imageUrl} alt={pro.user?.name || "Professional"} className="w-full h-full object-cover" />
                 ) : (
                   <div className="w-full h-full flex items-center justify-center">
                     <User className="w-16 h-16 text-primary/40" />
                   </div>
                 )}
               </div>
               <div>
                 <div className="flex items-center gap-3 mb-2">
                   <h1 className="font-serif text-3xl font-bold">{pro.user?.name || "Professional"}</h1>
                   <Badge variant="outline" className="border-primary text-primary">
                     {PROFESSION_LABELS[pro.professionType] || pro.professionType}
                   </Badge>
                   {pro.isVerified && (
                     <Badge className="bg-green-500 text-white">Verified</Badge>
                   )}
                 </div>
                 {pro.yearsExperience && (
                   <p className="text-sm text-muted-foreground mb-2">{pro.yearsExperience}+ years of experience</p>
                 )}
                 {pro.location && (
                   <p className="text-sm text-muted-foreground mb-4">{pro.location}</p>
                 )}
                 <p className="text-lg text-muted-foreground leading-relaxed">
                   {pro.bio || "Experienced healthcare professional dedicated to supporting your wellness journey."}
                 </p>
               </div>
            </div>

            <div className="grid sm:grid-cols-2 gap-4">
              {pro.specialties && pro.specialties.length > 0 && (
                <Card>
                  <CardHeader><CardTitle className="text-base">Specialties</CardTitle></CardHeader>
                  <CardContent>
                    <ul className="space-y-2">
                      {pro.specialties.map((s: string) => (
                        <li key={s} className="flex items-center gap-2 text-sm">
                          <CheckCircle className="w-4 h-4 text-green-500" /> {s}
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              )}
              <Card>
                 <CardHeader><CardTitle className="text-base">Credentials</CardTitle></CardHeader>
                 <CardContent>
                   <div className="space-y-2 text-sm text-muted-foreground">
                     <p>• Certified {PROFESSION_LABELS[pro.professionType] || pro.professionType}</p>
                     {pro.yearsExperience && <p>• {pro.yearsExperience}+ Years Experience</p>}
                     {pro.isVerified && <p>• Verified Background Check</p>}
                   </div>
                 </CardContent>
              </Card>
            </div>
          </div>

          <div>
             <Card className="sticky top-24 border-none shadow-xl">
               <CardHeader className="bg-primary/5 border-b border-primary/10">
                 <CardTitle className="font-serif">Book a Session</CardTitle>
                 <div className="text-2xl font-bold text-primary mt-1">
                   {pro.hourlyRate ? (
                     <>${pro.hourlyRate} <span className="text-sm font-normal text-muted-foreground">/ hour</span></>
                   ) : (
                     <span className="text-lg font-normal text-muted-foreground">Contact for rates</span>
                   )}
                 </div>
               </CardHeader>
               <CardContent className="p-6 space-y-6">
                 <div>
                   <h3 className="font-medium mb-3 text-sm uppercase tracking-wide text-muted-foreground">Available Slots</h3>
                   <div className="grid grid-cols-1 gap-2 max-h-64 overflow-y-auto">
                     {availableSlots.length > 0 ? availableSlots.map((slot: BookingSlot) => {
                       const start = new Date(slot.startDateTime);
                       return (
                         <button
                           key={slot.id}
                           onClick={() => setSelectedSlot(slot.id)}
                           className={`flex items-center justify-between p-3 rounded-lg border transition-all text-sm ${
                             selectedSlot === slot.id 
                               ? "border-primary bg-primary/5 ring-1 ring-primary" 
                               : "hover:border-primary/50 hover:bg-gray-50"
                           }`}
                           data-testid={`slot-${slot.id}`}
                         >
                           <div className="flex items-center gap-2">
                             <CalendarIcon className="w-4 h-4 text-muted-foreground" />
                             <span>{start.toLocaleDateString()}</span>
                           </div>
                           <div className="flex items-center gap-2 font-medium">
                             <Clock className="w-4 h-4 text-muted-foreground" />
                             <span>{start.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</span>
                           </div>
                         </button>
                       );
                     }) : (
                       <p className="text-sm text-muted-foreground italic py-4 text-center">No slots available. Check back later.</p>
                     )}
                   </div>
                 </div>
                 
                 <Button 
                   className="w-full bg-primary hover:bg-primary/90 text-white h-12 text-base"
                   disabled={!selectedSlot || bookMutation.isPending}
                   onClick={() => bookMutation.mutate()}
                   data-testid="button-confirm-booking"
                 >
                   {bookMutation.isPending ? (
                     <><Loader2 className="w-4 h-4 animate-spin mr-2" /> Processing...</>
                   ) : (
                     "Confirm Booking"
                   )}
                 </Button>
                 <p className="text-xs text-center text-muted-foreground">
                   Free cancellation up to 24 hours before.
                 </p>
               </CardContent>
             </Card>
          </div>
        </div>
      </main>
    </div>
  );
}
