import { useParams, Link } from "wouter";
import { Navbar } from "@/components/layout/Navbar";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { CheckCircle, Clock, PlayCircle, Loader2, ArrowLeft } from "lucide-react";
import NotFound from "@/pages/not-found";
import { useQuery } from "@tanstack/react-query";
import { api, type ProgramModule } from "@/lib/api";

export default function ProgramDetails() {
  const { id } = useParams();
  const programId = parseInt(id || '0');

  const { data, isLoading, error } = useQuery({
    queryKey: ['program', programId],
    queryFn: () => api.programs.getById(programId),
    enabled: !isNaN(programId) && programId > 0,
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="flex items-center justify-center py-32">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      </div>
    );
  }

  if (error || !data?.program) {
    return <NotFound />;
  }

  const { program, modules } = data;

  return (
    <div className="min-h-screen bg-background pb-20">
      <Navbar />
      
      {/* Hero Header */}
      <div className="relative h-[400px] bg-gradient-to-br from-primary/30 to-secondary/30">
        {program.imageUrl ? (
          <img 
            src={program.imageUrl} 
            alt={program.title} 
            className="w-full h-full object-cover"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-primary/20 to-secondary/20">
            <span className="text-6xl font-serif text-primary/30">{program.title.charAt(0)}</span>
          </div>
        )}
        <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
          <div className="container mx-auto px-4 text-center text-white">
            <Badge className="mb-4 bg-white/20 hover:bg-white/30 text-white border-none backdrop-blur-md">
              {program.category}
            </Badge>
            <h1 className="font-serif text-4xl md:text-5xl font-bold mb-4">{program.title}</h1>
            <div className="flex items-center justify-center gap-6 text-sm font-medium">
              <span className="flex items-center gap-2"><Clock className="w-4 h-4" /> {program.duration || '4 weeks'}</span>
              <span className="flex items-center gap-2"><PlayCircle className="w-4 h-4" /> {program.level || 'All Levels'}</span>
            </div>
          </div>
        </div>
      </div>

      <main className="container mx-auto px-4 py-10">
        <Link href="/programs">
          <Button variant="ghost" size="sm" className="mb-6" data-testid="button-back-programs">
            <ArrowLeft className="w-4 h-4 mr-2" /> Back to Programs
          </Button>
        </Link>

        <div className="grid md:grid-cols-3 gap-10">
          <div className="md:col-span-2 space-y-8">
            <div>
              <h2 className="font-serif text-2xl font-bold mb-4">About this Program</h2>
              <p className="text-muted-foreground leading-relaxed text-lg">
                {program.description}
                <br /><br />
                This program is designed to provide comprehensive support and guidance. 
                Our expert-led modules will walk you through everything you need to know, 
                empowering you to make informed decisions for your health and your family.
              </p>
            </div>
            
            <Separator />

            <div>
              <h2 className="font-serif text-2xl font-bold mb-6">What You'll Learn</h2>
              <div className="space-y-4">
                {modules && modules.length > 0 ? (
                  modules.map((module: ProgramModule, index: number) => (
                    <div key={module.id} className="flex gap-4 p-4 rounded-xl border bg-white hover:shadow-md transition-shadow" data-testid={`module-${module.id}`}>
                      <div className="flex-shrink-0 w-8 h-8 rounded-full bg-secondary/10 text-secondary flex items-center justify-center font-bold">
                        {index + 1}
                      </div>
                      <div>
                        <h3 className="font-bold mb-1">{module.title}</h3>
                        <p className="text-sm text-muted-foreground line-clamp-2">
                          {module.contentMarkdown.substring(0, 150)}...
                        </p>
                      </div>
                    </div>
                  ))
                ) : (
                  [1, 2, 3, 4].map((module) => (
                    <div key={module} className="flex gap-4 p-4 rounded-xl border bg-white hover:shadow-md transition-shadow">
                      <div className="flex-shrink-0 w-8 h-8 rounded-full bg-secondary/10 text-secondary flex items-center justify-center font-bold">
                        {module}
                      </div>
                      <div>
                        <h3 className="font-bold mb-1">Module {module}: Foundation & Basics</h3>
                        <p className="text-sm text-muted-foreground">Understanding the core principles and getting started on the right path.</p>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>

          <div>
            <div className="sticky top-24 p-6 rounded-2xl border bg-white shadow-lg">
              <h3 className="font-serif text-xl font-bold mb-2">Ready to start?</h3>
              <p className="text-muted-foreground text-sm mb-6">
                Join over 1,200 women currently enrolled in this program.
              </p>
              <Button size="lg" className="w-full bg-primary hover:bg-primary/90 text-white mb-3" data-testid="button-enroll">
                Enroll Now
              </Button>
              <p className="text-xs text-center text-muted-foreground flex items-center justify-center gap-1">
                <CheckCircle className="w-3 h-3 text-green-500" /> 
                Includes certificate of completion
              </p>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
