import { useState } from "react";
import { Navbar } from "@/components/layout/Navbar";
import { ProgramCard } from "@/components/ProgramCard";
import { Input } from "@/components/ui/input";
import { Search, Filter, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { api, type Program } from "@/lib/api";
import { t, getLang } from "@/lib/i18n";

export default function Programs() {
  const [searchTerm, setSearchTerm] = useState("");
  const lang = getLang();

  const { data: programsData, isLoading } = useQuery({
    queryKey: ['programs'],
    queryFn: () => api.programs.getAll(),
  });

  const programs = programsData?.programs || [];

  const filteredPrograms = programs.filter((p: Program) => 
    p.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
    p.category.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-background pb-20">
      <Navbar />
      
      <div className="bg-white border-b py-12">
        <div className="container mx-auto px-4">
          <h1 className="font-serif text-4xl font-bold text-foreground mb-4">{t('programs.title')}</h1>
          <p className="text-muted-foreground text-lg max-w-2xl">
            {t('programs.subtitle')}
          </p>
        </div>
      </div>

      <main className="container mx-auto px-4 py-10">
        {/* Filters */}
        <div className="flex flex-col md:flex-row gap-4 mb-10 items-center justify-between">
          <div className="relative w-full md:max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground w-4 h-4" />
            <Input 
              placeholder={t('programs.search')}
              className="pl-10 bg-white"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              data-testid="input-search-programs"
            />
          </div>
          <div className="flex gap-2 w-full md:w-auto overflow-x-auto pb-2 md:pb-0">
            <Button variant="outline" size="sm" className="rounded-full bg-white whitespace-nowrap" data-testid="button-filter-all">
              <Filter className="w-3.5 h-3.5 mr-2" /> {t('programs.all_categories')}
            </Button>
            <Button variant="ghost" size="sm" className="rounded-full whitespace-nowrap">
              {t('programs.cat_prenatal')}
            </Button>
            <Button variant="ghost" size="sm" className="rounded-full whitespace-nowrap">
              {t('programs.cat_postpartum')}
            </Button>
            <Button variant="ghost" size="sm" className="rounded-full whitespace-nowrap">
              {t('programs.cat_nutrition')}
            </Button>
            <Button variant="ghost" size="sm" className="rounded-full whitespace-nowrap">
              {t('programs.cat_mental_health')}
            </Button>
          </div>
        </div>

        {/* Loading State */}
        {isLoading && (
          <div className="flex items-center justify-center py-20">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
          </div>
        )}

        {/* Grid */}
        {!isLoading && (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredPrograms.map((program: Program) => (
              <ProgramCard key={program.id} program={{
                id: String(program.id),
                title: program.title,
                description: program.description,
                category: program.category as any,
                image: program.imageUrl || '/placeholder-program.jpg',
                duration: program.duration || '4 weeks',
                level: (program.level || 'All Levels') as any,
              }} />
            ))}
          </div>
        )}

        {!isLoading && filteredPrograms.length === 0 && (
          <div className="text-center py-20">
            <p className="text-muted-foreground">{t('programs.no_results')}</p>
            <Button variant="link" onClick={() => setSearchTerm("")} data-testid="button-clear-filters">
              {t('programs.clear_filters')}
            </Button>
          </div>
        )}
      </main>
    </div>
  );
}
