import { Navbar } from "@/components/layout/Navbar";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Download, Users, Activity, TrendingUp, Loader2, Building2, AlertCircle } from "lucide-react";
import { Progress } from "@/components/ui/progress";
import { useQuery } from "@tanstack/react-query";
import { api } from "@/lib/api";
import { t, getLang } from "@/lib/i18n";

export default function EmployerDashboard() {
  const lang = getLang();
  const { data: summary, isLoading, error } = useQuery({
    queryKey: ['employerSummary'],
    queryFn: () => api.employer.getSummary(),
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        <div className="flex items-center justify-center py-32">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      </div>
    );
  }

  if (error || !summary) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        <div className="container mx-auto px-4 py-20 text-center">
          <AlertCircle className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
          <h2 className="font-serif text-2xl font-bold mb-2">{t('employer.no_org_title')}</h2>
          <p className="text-muted-foreground mb-6">
            {t('employer.no_org_desc')}
          </p>
          <Button onClick={() => window.location.href = '/dashboard'}>
            {t('mom.go_dashboard')}
          </Button>
        </div>
      </div>
    );
  }

  const { organization: org, memberCount, riskDistribution, programEnrollments } = summary;

  const totalRiskCount = riskDistribution.reduce((acc, r) => acc + r.count, 0);
  const getRiskPercentage = (level: string) => {
    const found = riskDistribution.find(r => r.riskLevel === level);
    if (!found || totalRiskCount === 0) return 0;
    return Math.round((found.count / totalRiskCount) * 100);
  };

  const lowRisk = getRiskPercentage('LOW');
  const moderateRisk = getRiskPercentage('MODERATE');
  const highRisk = getRiskPercentage('HIGH');

  const avgHealthScore = Math.max(0, 100 - (moderateRisk * 0.3 + highRisk * 0.7));

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      <Navbar />
      
      <div className="bg-white border-b py-8">
        <div className="container mx-auto px-4 flex justify-between items-center">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
              <Building2 className="w-6 h-6 text-primary" />
            </div>
            <div>
              <h1 className="font-serif text-3xl font-bold text-foreground">{org.name} {t('employer.title')}</h1>
              <p className="text-muted-foreground">
                {org.industry && `${org.industry} • `}
                {org.country && org.country}
                {!org.industry && !org.country && t('employer.subtitle')}
              </p>
            </div>
          </div>
          <Button variant="outline" data-testid="button-export">
            <Download className="w-4 h-4 mr-2" /> {t('employer.export_report')}
          </Button>
        </div>
      </div>

      <main className="container mx-auto px-4 py-10">
        
        <div className="grid md:grid-cols-3 gap-6 mb-10">
          <Card data-testid="card-employees">
            <CardContent className="p-6 flex items-center gap-4">
              <div className="p-3 rounded-full bg-blue-50 text-blue-600">
                <Users className="w-6 h-6" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">{t('employer.total_members')}</p>
                <h3 className="text-2xl font-bold" data-testid="text-member-count">{memberCount}</h3>
              </div>
            </CardContent>
          </Card>
          <Card data-testid="card-engagement">
            <CardContent className="p-6 flex items-center gap-4">
              <div className="p-3 rounded-full bg-green-50 text-green-600">
                <Activity className="w-6 h-6" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">{t('employer.program_enrollments')}</p>
                <h3 className="text-2xl font-bold">{programEnrollments.reduce((acc, p) => acc + p.count, 0)}</h3>
              </div>
            </CardContent>
          </Card>
          <Card data-testid="card-health-score">
            <CardContent className="p-6 flex items-center gap-4">
              <div className="p-3 rounded-full bg-purple-50 text-purple-600">
                <TrendingUp className="w-6 h-6" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">{t('employer.health_score')}</p>
                <h3 className="text-2xl font-bold">{Math.round(avgHealthScore)}/100</h3>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          <Card data-testid="card-risk-distribution">
            <CardHeader>
              <CardTitle>{t('employer.risk_distribution')}</CardTitle>
              <CardDescription>{t('employer.risk_subtitle')}</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {totalRiskCount === 0 ? (
                <p className="text-muted-foreground text-center py-4">{t('employer.no_risk_data')}</p>
              ) : (
                <>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="font-medium">{t('employer.low_risk')}</span>
                      <span>{lowRisk}%</span>
                    </div>
                    <Progress value={lowRisk} className="h-3 bg-gray-100" />
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="font-medium">{t('employer.moderate_risk')}</span>
                      <span>{moderateRisk}%</span>
                    </div>
                    <Progress value={moderateRisk} className="h-3 bg-gray-100" />
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="font-medium">{t('employer.high_risk')}</span>
                      <span>{highRisk}%</span>
                    </div>
                    <Progress value={highRisk} className="h-3 bg-gray-100" />
                  </div>
                </>
              )}
            </CardContent>
          </Card>

          <Card data-testid="card-enrollments">
            <CardHeader>
              <CardTitle>{t('employer.enrollments_title')}</CardTitle>
              <CardDescription>{t('employer.enrollments_subtitle')}</CardDescription>
            </CardHeader>
            <CardContent>
               {programEnrollments.length > 0 ? (
                 <div className="space-y-4">
                   {programEnrollments.map((stat, i) => (
                     <div key={i} className="flex items-center justify-between p-3 rounded-lg border bg-gray-50/50">
                       <span className="font-medium">{stat.title}</span>
                       <Badge variant="secondary" className="bg-white shadow-sm">{stat.count} {t('employer.employees')}</Badge>
                     </div>
                   ))}
                 </div>
               ) : (
                 <p className="text-muted-foreground text-center py-4">{t('employer.no_enrollments')}</p>
               )}
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
