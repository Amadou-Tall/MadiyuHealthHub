import { useState, useEffect } from "react";
import { Navbar } from "@/components/layout/Navbar";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Save, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Link } from "wouter";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api } from "@/lib/api";

export default function BirthPlan() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [plan, setPlan] = useState({
    painManagementPreference: "",
    supportPeople: "",
    culturalPreferences: "",
    medicalInterventionPreferences: "",
    extraNotes: ""
  });

  const { data: existingPlan, isLoading } = useQuery({
    queryKey: ['birthPlan'],
    queryFn: () => api.mom.getBirthPlan(),
    retry: false,
  });

  useEffect(() => {
    if (existingPlan) {
      setPlan({
        painManagementPreference: existingPlan.painManagementPreference || "",
        supportPeople: existingPlan.supportPeople || "",
        culturalPreferences: existingPlan.culturalPreferences || "",
        medicalInterventionPreferences: existingPlan.medicalInterventionPreferences || "",
        extraNotes: existingPlan.extraNotes || "",
      });
    }
  }, [existingPlan]);

  const mutation = useMutation({
    mutationFn: () => api.mom.updateBirthPlan(plan),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['birthPlan'] });
      toast({
        title: "Birth Plan Saved",
        description: "Your preferences have been updated safely.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to save birth plan. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleChange = (field: string, value: string) => {
    setPlan(prev => ({ ...prev, [field]: value }));
  };

  const handleSave = () => {
    mutation.mutate();
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-pink-50/20">
        <Navbar />
        <div className="flex items-center justify-center py-32">
          <Loader2 className="w-8 h-8 animate-spin text-pink-600" />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-pink-50/20 pb-20">
      <Navbar />
      
      <div className="bg-white border-b py-8">
        <div className="container mx-auto px-4">
          <div className="flex items-center gap-2 text-sm text-muted-foreground mb-2">
            <Link href="/mom/dashboard" className="hover:text-foreground">Mom Dashboard</Link> / Birth Plan
          </div>
          <h1 className="font-serif text-3xl font-bold text-pink-900">My Birth Plan</h1>
          <p className="text-muted-foreground max-w-2xl">
            Communicate your wishes clearly to your care team. This is a flexible guide, not a rigid script.
          </p>
        </div>
      </div>

      <main className="container mx-auto px-4 py-8 max-w-3xl">
        <Card className="border-none shadow-md">
          <CardHeader>
            <CardTitle>Preferences & Wishes</CardTitle>
            <CardDescription>Fill out as much or as little as you like.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            
            <div className="space-y-3">
              <Label className="text-base font-medium">Pain Management Preferences</Label>
              <Select 
                value={plan.painManagementPreference.split(':')[0] || ""} 
                onValueChange={(v) => handleChange('painManagementPreference', v)}
              >
                <SelectTrigger data-testid="select-pain-management">
                  <SelectValue placeholder="Select your preference" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="natural">Unmedicated / Natural (Breathing, Movement)</SelectItem>
                  <SelectItem value="epidural">Epidural / Medical Pain Relief</SelectItem>
                  <SelectItem value="open">Open to suggestions as labor progresses</SelectItem>
                </SelectContent>
              </Select>
              <Textarea 
                placeholder="Add specific details (e.g., 'I want to try nitrous oxide first', 'Please don't offer meds unless I ask')" 
                className="h-20 resize-none"
                value={plan.painManagementPreference}
                onChange={(e) => handleChange('painManagementPreference', e.target.value)}
                data-testid="textarea-pain-details"
              />
            </div>

            <div className="space-y-3">
              <Label className="text-base font-medium">Who will be supporting you?</Label>
              <Textarea 
                placeholder="Names of partner, doula, or family members present..." 
                className="h-20"
                value={plan.supportPeople}
                onChange={(e) => handleChange('supportPeople', e.target.value)}
                data-testid="textarea-support"
              />
            </div>

            <div className="space-y-3">
              <Label className="text-base font-medium">Medical Interventions</Label>
              <Textarea 
                placeholder="Thoughts on induction, monitoring, episiotomy, C-section..." 
                className="h-24"
                value={plan.medicalInterventionPreferences}
                onChange={(e) => handleChange('medicalInterventionPreferences', e.target.value)}
                data-testid="textarea-medical"
              />
            </div>

            <div className="space-y-3">
              <Label className="text-base font-medium">Cultural or Religious Requests</Label>
              <Textarea 
                placeholder="Any traditions or rituals important to you and your family..." 
                className="h-20"
                value={plan.culturalPreferences}
                onChange={(e) => handleChange('culturalPreferences', e.target.value)}
                data-testid="textarea-cultural"
              />
            </div>

            <div className="space-y-3">
              <Label className="text-base font-medium">Additional Notes</Label>
              <Textarea 
                placeholder="Any other wishes or concerns..." 
                className="h-20"
                value={plan.extraNotes}
                onChange={(e) => handleChange('extraNotes', e.target.value)}
                data-testid="textarea-notes"
              />
            </div>

          </CardContent>
          <CardFooter className="bg-gray-50 p-6 flex justify-end">
            <Button 
              onClick={handleSave} 
              disabled={mutation.isPending} 
              className="bg-pink-600 hover:bg-pink-700 text-white min-w-[150px]"
              data-testid="button-save"
            >
              {mutation.isPending ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" /> Saving...
                </>
              ) : (
                <>
                  <Save className="w-4 h-4 mr-2" /> Save Plan
                </>
              )}
            </Button>
          </CardFooter>
        </Card>
      </main>
    </div>
  );
}
