import { useState, useRef, useEffect } from "react";
import { Navbar } from "@/components/layout/Navbar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Send, Sparkles, ShieldCheck } from "lucide-react";
import { useRoute } from "wouter";
import { aiService } from "@/lib/aiService";
import { t } from "@/lib/i18n";
import { useToast } from "@/hooks/use-toast";

import doulaAvatar from "@assets/generated_images/warm_and_wise_ai_doula_avatar.png";
import sleepCoachAvatar from "@assets/generated_images/friendly_ai_sleep_coach_avatar.png";

interface Message {
  id: string;
  sender: 'user' | 'ai';
  content: string;
  timestamp: Date;
}

const AGENTS = {
  doula: {
    name: "Madiyu AI Doula",
    slug: "promoted-mom-ai-doula",
    avatar: doulaAvatar,
    role: "Pregnancy & Birth Companion",
    color: "bg-orange-100 text-orange-800",
    intro: "Hello, mama! I'm here to support you through your pregnancy and birth journey. I can help explain labor signs, comfort measures, and birth options. How are you feeling today?"
  },
  sleep: {
    name: "Madiyu Sleep Coach",
    slug: "promoted-mom-ai-sleep-coach",
    avatar: sleepCoachAvatar,
    role: "Baby Sleep Specialist",
    color: "bg-blue-100 text-blue-800",
    intro: "Hi there! Sleep can be tricky with a little one. I'm here to help you understand sleep windows, routines, and safe sleep practices. What's on your mind?"
  }
};

export default function MomAIChat() {
  const { toast } = useToast();
  const [match, params] = useRoute("/mom/ai/:type");
  const type = (params?.type === 'sleep-coach' ? 'sleep' : 'doula') as 'sleep' | 'doula';
  const agent = AGENTS[type];

  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      sender: 'ai',
      content: agent.intro,
      timestamp: new Date()
    }
  ]);
  const [input, setInput] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isTyping]);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;

    const userMsg: Message = {
      id: Date.now().toString(),
      sender: 'user',
      content: input,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMsg]);
    setInput("");
    setIsTyping(true);

    try {
      const response = await aiService.generateReply({
        agentSlug: agent.slug,
        message: userMsg.content,
        history: messages.map(m => ({ role: m.sender === 'user' ? 'user' : 'assistant', content: m.content }))
      });

      if (response.error) throw new Error(response.error);

      const aiMsg: Message = {
        id: (Date.now() + 1).toString(),
        sender: 'ai',
        content: response.content,
        timestamp: new Date()
      };
      setMessages(prev => [...prev, aiMsg]);
    } catch (error) {
      toast({
        title: t('common.error'),
        description: "AI service currently unavailable.",
        variant: "destructive"
      });
    } finally {
      setIsTyping(false);
    }
  };

  return (
    <div className="min-h-screen bg-pink-50/20 flex flex-col">
      <Navbar />
      
      <div className="flex-1 container mx-auto max-w-4xl p-4 md:p-6 flex flex-col h-[calc(100vh-64px)]">
        <div className="bg-white rounded-2xl shadow-sm border flex-1 flex flex-col overflow-hidden">
          
          {/* Chat Header */}
          <div className="p-4 border-b flex items-center gap-4 bg-gradient-to-r from-white to-gray-50">
            <Avatar className="h-12 w-12 border-2 border-white shadow-sm">
              <AvatarImage src={agent.avatar} />
              <AvatarFallback>AI</AvatarFallback>
            </Avatar>
            <div>
              <h1 className="font-serif font-bold text-lg text-foreground">{agent.name}</h1>
              <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${agent.color}`}>
                {agent.role}
              </span>
            </div>
          </div>

          {/* Disclaimer Banner */}
          <div className="bg-orange-50 px-4 py-2 text-xs text-orange-800 flex items-start gap-2 border-b border-orange-100">
             <ShieldCheck className="w-4 h-4 flex-shrink-0 mt-0.5" />
             <p>{t('ai.disclaimer')}</p>
          </div>

          {/* Chat Area */}
          <ScrollArea className="flex-1 p-4 bg-slate-50/30" ref={scrollRef}>
            <div className="space-y-6 pb-4">
              {messages.map((msg) => (
                <div 
                  key={msg.id} 
                  className={`flex gap-3 ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  {msg.sender === 'ai' && (
                    <Avatar className="h-8 w-8 mt-1 border border-border flex-shrink-0">
                      <AvatarImage src={agent.avatar} />
                      <AvatarFallback>AI</AvatarFallback>
                    </Avatar>
                  )}
                  
                  <div 
                    className={`max-w-[85%] md:max-w-[75%] rounded-2xl px-5 py-3 text-sm leading-relaxed shadow-sm whitespace-pre-wrap ${
                      msg.sender === 'user' 
                        ? 'bg-pink-600 text-white rounded-tr-none' 
                        : 'bg-white text-foreground border border-gray-100 rounded-tl-none'
                    }`}
                  >
                    {msg.content}
                  </div>
                </div>
              ))}
              
              {isTyping && (
                <div className="flex gap-3 justify-start">
                   <Avatar className="h-8 w-8 mt-1 border border-border">
                      <AvatarImage src={agent.avatar} />
                      <AvatarFallback>AI</AvatarFallback>
                    </Avatar>
                    <div className="bg-white rounded-2xl rounded-tl-none px-4 py-3 border border-gray-100 shadow-sm">
                      <div className="flex gap-1">
                        <span className="w-2 h-2 bg-pink-300 rounded-full animate-bounce"></span>
                        <span className="w-2 h-2 bg-pink-300 rounded-full animate-bounce delay-150"></span>
                        <span className="w-2 h-2 bg-pink-300 rounded-full animate-bounce delay-300"></span>
                      </div>
                    </div>
                </div>
              )}
            </div>
          </ScrollArea>

          {/* Input Area */}
          <div className="p-4 border-t bg-white">
            <form onSubmit={handleSend} className="flex gap-2">
              <Input 
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder={t('ai.placeholder')}
                className="flex-1 bg-gray-50 border-gray-200 focus-visible:ring-pink-500"
              />
              <Button type="submit" disabled={!input.trim() || isTyping} className="bg-pink-600 hover:bg-pink-700 text-white">
                <Send className="w-4 h-4" />
              </Button>
            </form>
            <div className="mt-2 text-center">
               <p className="text-[10px] text-muted-foreground">
                 <Sparkles className="w-3 h-3 inline mr-1 text-pink-400" />
                 AI responses are for informational purposes only. Not medical advice.
               </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
