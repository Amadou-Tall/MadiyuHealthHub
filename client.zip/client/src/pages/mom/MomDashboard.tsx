import { useState } from "react";
import { Navbar } from "@/components/layout/Navbar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Link } from "wouter";
import { ArrowRight, Baby, Heart, Loader2, Moon, Plus, Utensils, AlertCircle } from "lucide-react";
import { t, getLang } from "@/lib/i18n";
import { useQuery } from "@tanstack/react-query";
import { api, type BabyProfile, type BabyLog } from "@/lib/api";

import heroPregnant from "@assets/generated_images/serene_pregnant_woman_looking_at_baby_bump.png";
import heroBaby from "@assets/generated_images/peaceful_sleeping_newborn_baby.png";

export default function MomDashboard() {
  const [activeTab, setActiveTab] = useState<'overview' | 'baby'>('overview');
  const lang = getLang();

  const { data: profile, isLoading: profileLoading, error: profileError } = useQuery({
    queryKey: ['motherhoodProfile'],
    queryFn: () => api.mom.getProfile(),
    retry: false,
  });

  const { data: babiesData, isLoading: babiesLoading } = useQuery({
    queryKey: ['babies'],
    queryFn: () => api.mom.getBabies(),
    enabled: profile?.status === 'POSTPARTUM',
  });

  const babies = babiesData?.babies || [];
  const firstBaby = babies.length > 0 ? babies[0] : null;
  const firstBabyId = firstBaby?.id;

  const { data: babyLogsData, isLoading: logsLoading } = useQuery({
    queryKey: ['babyLogs', firstBabyId],
    queryFn: () => {
      if (!firstBabyId) throw new Error("No baby ID");
      return api.mom.getBabyLogs(firstBabyId, 10, 0);
    },
    enabled: !!firstBabyId && firstBabyId > 0,
  });

  const babyLogs = babyLogsData?.logs || [];

  if (profileLoading) {
    return (
      <div className="min-h-screen bg-pink-50/20">
        <Navbar />
        <div className="flex items-center justify-center py-32">
          <Loader2 className="w-8 h-8 animate-spin text-secondary" />
        </div>
      </div>
    );
  }

  if (profileError || !profile) {
    return (
      <div className="min-h-screen bg-pink-50/20">
        <Navbar />
        <div className="container mx-auto px-4 py-20 text-center">
          <AlertCircle className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
          <h2 className="font-serif text-2xl font-bold mb-2">{t('mom.no_profile_title')}</h2>
          <p className="text-muted-foreground mb-6">{t('mom.no_profile_desc')}</p>
          <Link href="/mom">
            <Button className="bg-secondary hover:bg-secondary/90 text-white">
              {t('mom.get_started')}
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  const progressToDelivery = profile.weeksPregnant ? Math.min((profile.weeksPregnant / 40) * 100, 100) : 0;
  const trimester = profile.weeksPregnant 
    ? (profile.weeksPregnant <= 12 ? 1 : profile.weeksPregnant <= 26 ? 2 : 3) 
    : 1;

  const getBabySizeComparison = (weeks: number) => {
    if (weeks <= 12) return t('mom.baby_size_lime');
    if (weeks <= 16) return t('mom.baby_size_avocado');
    if (weeks <= 20) return t('mom.baby_size_banana');
    if (weeks <= 24) return t('mom.baby_size_corn');
    if (weeks <= 28) return t('mom.baby_size_coconut');
    if (weeks <= 32) return t('mom.baby_size_squash');
    if (weeks <= 36) return t('mom.baby_size_melon');
    return t('mom.baby_size_watermelon');
  };

  return (
    <div className="min-h-screen bg-pink-50/20 pb-20">
      <Navbar />
      
      <div className="bg-white border-b py-6">
        <div className="container mx-auto px-4 flex items-center gap-3">
           <div className="bg-secondary/10 p-2 rounded-full text-secondary">
             <Heart className="w-5 h-5" />
           </div>
           <div>
             <h1 className="font-serif text-xl font-bold text-secondary">{t('mom.promoted_title')} <span className="text-muted-foreground font-sans text-sm font-normal ml-2">{t('mom.byline')}</span></h1>
           </div>
        </div>
      </div>

      {/* Personalized branding message for Black moms */}
      <div className="bg-gradient-to-r from-secondary/10 via-primary/5 to-secondary/10 py-4">
        <div className="container mx-auto px-4">
          <p className="text-sm font-medium text-foreground/80 italic text-center">
            "{t('mom.journey_matters')}"
          </p>
        </div>
      </div>

      <main className="container mx-auto px-4 py-8">
        
        {profile.status === 'PREGNANT' && (
          <div className="space-y-8 animate-in fade-in duration-500">
             <Card className="overflow-hidden border-none shadow-lg bg-white">
               <div className="grid md:grid-cols-2">
                 <div className="p-8 flex flex-col justify-center order-2 md:order-1">
                   <Badge className="w-fit mb-4 bg-secondary/10 text-secondary hover:bg-secondary/10 border-none">{t('mom.trimester')} {trimester}</Badge>
                   <h2 className="font-serif text-4xl font-bold text-foreground mb-2">{t('mom.week')} {profile.weeksPregnant || 1}</h2>
                   <p className="text-lg text-muted-foreground mb-6">{t('mom.baby_size')} {getBabySizeComparison(profile.weeksPregnant || 1)}</p>
                   
                   <div className="space-y-2 mb-8">
                     <div className="flex justify-between text-sm font-medium">
                       <span>{t('mom.progress_due')} {profile.dueDate ? `(${profile.dueDate})` : ''}</span>
                       <span>{Math.round(progressToDelivery)}%</span>
                     </div>
                     <Progress value={progressToDelivery} className="h-3 bg-secondary/20" />
                   </div>

                   <div className="flex flex-wrap gap-3">
                     <Link href="/mom/birth-plan">
                       <Button className="bg-secondary hover:bg-secondary/90 text-white rounded-full" data-testid="button-birth-plan">
                         {t('mom.birth_plan')}
                       </Button>
                     </Link>
                     <Link href="/ai?agent=doula">
                       <Button variant="outline" className="border-secondary/30 text-secondary hover:bg-secondary/10 rounded-full">
                         {t('mom.ai_doula')}
                       </Button>
                     </Link>
                   </div>
                 </div>
                 <div className="relative h-64 md:h-auto order-1 md:order-2">
                   <img src={heroPregnant} alt={t('mom.pregnant_img_alt')} className="absolute inset-0 w-full h-full object-cover" />
                 </div>
               </div>
             </Card>

             <div className="grid md:grid-cols-3 gap-6">
               {[
                 { titleKey: "mom.tip_nutrition_title", descKey: "mom.tip_nutrition_desc" },
                 { titleKey: "mom.tip_pelvic_title", descKey: "mom.tip_pelvic_desc" },
                 { titleKey: "mom.tip_sleep_title", descKey: "mom.tip_sleep_desc" }
               ].map((item, i) => (
                 <Card key={i} className="hover:shadow-md transition-shadow cursor-pointer border-secondary/20">
                   <CardHeader>
                     <CardTitle className="text-lg font-serif text-secondary">{t(item.titleKey)}</CardTitle>
                   </CardHeader>
                   <CardContent>
                     <p className="text-sm text-muted-foreground">{t(item.descKey)}</p>
                     <Button variant="link" className="px-0 text-secondary mt-2">
                       {t('mom.read_more')} <ArrowRight className="w-3 h-3 ml-1" />
                     </Button>
                   </CardContent>
                 </Card>
               ))}
             </div>
          </div>
        )}

        {profile.status === 'POSTPARTUM' && (
          <div className="space-y-8 animate-in fade-in duration-500">
             <Card className="border-none shadow-lg bg-white overflow-hidden">
               <div className="grid md:grid-cols-2">
                 <div className="p-8 flex flex-col justify-center">
                    <h2 className="font-serif text-3xl font-bold text-foreground mb-2">{t('mom.welcome_baby')}</h2>
                    {firstBaby ? (
                      <p className="text-muted-foreground mb-6">{firstBaby.name} • {firstBaby.dateOfBirth}</p>
                    ) : (
                      <p className="text-muted-foreground mb-6">{t('mom.add_baby')}</p>
                    )}
                    
                    <div className="grid grid-cols-3 gap-4 mb-6">
                       <div className="text-center p-3 bg-blue-50 rounded-xl">
                         <Moon className="w-5 h-5 mx-auto text-blue-500 mb-1" />
                         <p className="text-xs text-muted-foreground">{t('mom.sleep_label')}</p>
                         <p className="font-bold text-sm">--</p>
                       </div>
                       <div className="text-center p-3 bg-orange-50 rounded-xl">
                         <Utensils className="w-5 h-5 mx-auto text-orange-500 mb-1" />
                         <p className="text-xs text-muted-foreground">{t('mom.feeding_label')}</p>
                         <p className="font-bold text-sm">--</p>
                       </div>
                       <div className="text-center p-3 bg-green-50 rounded-xl">
                         <Baby className="w-5 h-5 mx-auto text-green-500 mb-1" />
                         <p className="text-xs text-muted-foreground">{t('mom.diaper_label')}</p>
                         <p className="font-bold text-sm">--</p>
                       </div>
                    </div>

                    <div className="flex gap-3">
                       <Button className="bg-primary hover:bg-primary/90 text-white flex-1" data-testid="button-log-activity">
                         <Plus className="w-4 h-4 mr-2" /> {t('mom.log_activity')}
                       </Button>
                       <Link href="/ai?agent=sleep">
                         <Button variant="outline" className="border-primary/30 text-primary hover:bg-primary/10 flex-1">
                           {t('mom.ai_sleep')}
                         </Button>
                       </Link>
                    </div>
                 </div>
                 <div className="relative h-64 md:h-auto">
                    <img src={heroBaby} alt={t('mom.baby_img_alt')} className="absolute inset-0 w-full h-full object-cover" />
                 </div>
               </div>
             </Card>

             <Card>
               <CardHeader>
                 <CardTitle className="font-serif">{t('mom.recent_logs')}</CardTitle>
               </CardHeader>
               <CardContent className="space-y-0">
                  {babiesLoading || logsLoading ? (
                    <div className="flex items-center justify-center py-8">
                      <Loader2 className="w-6 h-6 animate-spin text-primary" />
                    </div>
                  ) : !firstBaby ? (
                    <p className="text-center text-muted-foreground py-8">{t('mom.add_baby')}</p>
                  ) : babyLogs.length > 0 ? (
                    babyLogs.map((log: BabyLog, i: number) => (
                      <div key={log.id} className={`flex items-center justify-between p-4 ${i !== babyLogs.length - 1 ? 'border-b' : ''}`}>
                         <div className="flex items-center gap-4">
                            <div className={`p-2 rounded-full ${
                              log.type === 'SLEEP' ? 'bg-blue-100 text-blue-600' : 
                              log.type === 'FEEDING' ? 'bg-orange-100 text-orange-600' : 'bg-green-100 text-green-600'
                            }`}>
                              {log.type === 'SLEEP' ? <Moon className="w-4 h-4" /> : 
                               log.type === 'FEEDING' ? <Utensils className="w-4 h-4" /> : <Baby className="w-4 h-4" />}
                            </div>
                            <div>
                              <p className="font-medium text-sm">{log.valueText || log.type}</p>
                              <p className="text-xs text-muted-foreground">
                                {log.dateTime ? new Date(log.dateTime).toLocaleString(lang === 'fr' ? 'fr-FR' : 'en-US') : t('mom.just_now')}
                              </p>
                            </div>
                         </div>
                         {log.valueNumber && (
                           <Badge variant="secondary" className="bg-gray-100 text-gray-600">{log.valueNumber} {t('mom.minutes_abbrev')}</Badge>
                         )}
                      </div>
                    ))
                  ) : (
                    <p className="text-center text-muted-foreground py-8">{t('mom.no_logs')}</p>
                  )}
               </CardContent>
             </Card>
          </div>
        )}

        {profile.status === 'PLANNING' && (
          <div className="space-y-8 animate-in fade-in duration-500">
            <Card className="border-none shadow-lg bg-white p-8 text-center">
              <Heart className="w-12 h-12 mx-auto text-secondary mb-4" />
              <h2 className="font-serif text-2xl font-bold mb-2">{t('mom.planning_title')}</h2>
              <p className="text-muted-foreground mb-6 max-w-md mx-auto">
                {t('mom.planning_desc')}
              </p>
              <Link href="/programs">
                <Button className="bg-secondary hover:bg-secondary/90 text-white">
                  {t('dash.browse_programs')}
                </Button>
              </Link>
            </Card>
          </div>
        )}

        {profile.status === 'NONE' && (
          <div className="space-y-8 animate-in fade-in duration-500">
            <Card className="border-none shadow-lg bg-white p-8 text-center">
              <Heart className="w-12 h-12 mx-auto text-primary mb-4" />
              <h2 className="font-serif text-2xl font-bold mb-2">{t('mom.focus_health_title')}</h2>
              <p className="text-muted-foreground mb-6 max-w-md mx-auto">
                {t('mom.focus_health_desc')}
              </p>
              <Link href="/dashboard">
                <Button className="bg-primary hover:bg-primary/90 text-white">
                  {t('mom.go_dashboard')}
                </Button>
              </Link>
            </Card>
          </div>
        )}
      </main>
    </div>
  );
}
