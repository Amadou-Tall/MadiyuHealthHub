import { useState } from "react";
import { Navbar } from "@/components/layout/Navbar";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Input } from "@/components/ui/input";
import { useLocation } from "wouter";
import { Baby, Calendar, Loader2 } from "lucide-react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { api } from "@/lib/api";
import { useToast } from "@/hooks/use-toast";

type MomStatus = 'PLANNING' | 'PREGNANT' | 'POSTPARTUM' | 'NONE';

export default function MomOnboarding() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [status, setStatus] = useState<MomStatus>('NONE');
  const [date, setDate] = useState("");

  const mutation = useMutation({
    mutationFn: async () => {
      const profileData: any = {
        status,
      };

      if (status === 'PREGNANT' && date) {
        profileData.dueDate = date;
        const dueDate = new Date(date);
        const today = new Date();
        const diffTime = dueDate.getTime() - today.getTime();
        const diffWeeks = Math.ceil(diffTime / (1000 * 60 * 60 * 24 * 7));
        profileData.weeksPregnant = Math.max(1, 40 - diffWeeks);
      }

      if (status === 'POSTPARTUM' && date) {
        profileData.babyDateOfBirth = date;
        profileData.numberOfChildren = 1;
      }

      return api.mom.updateProfile(profileData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['motherhoodProfile'] });
      toast({
        title: "Profile Saved",
        description: "Your motherhood profile has been updated.",
      });
      setLocation("/mom/dashboard");
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to save profile. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = () => {
    mutation.mutate();
  };

  return (
    <div className="min-h-screen bg-pink-50/30 flex flex-col pb-20">
      <Navbar />
      
      <div className="container mx-auto px-4 py-12 max-w-2xl">
        <div className="text-center mb-10">
           <h1 className="font-serif text-3xl md:text-4xl font-bold text-primary mb-2">Promoted to Mom</h1>
           <p className="text-muted-foreground">Let's personalize your journey through motherhood.</p>
        </div>

        <Card className="border-none shadow-lg">
          <CardHeader>
            <CardTitle>Where are you in your journey?</CardTitle>
            <CardDescription>We'll tailor your dashboard based on your current stage.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-8">
            
            <RadioGroup value={status} onValueChange={(v: MomStatus) => setStatus(v)} className="grid grid-cols-1 gap-4">
              {[
                { value: 'PLANNING', label: 'Planning a Pregnancy', desc: 'I am thinking about trying to conceive.' },
                { value: 'PREGNANT', label: 'Currently Pregnant', desc: 'I have a baby on the way!' },
                { value: 'POSTPARTUM', label: 'New Mom / Postpartum', desc: 'I recently gave birth.' },
                { value: 'NONE', label: 'Not right now', desc: 'I am focusing on general health.' }
              ].map((option) => (
                <div 
                  key={option.value} 
                  className={`flex items-start space-x-3 space-y-0 rounded-xl border p-4 cursor-pointer transition-all ${status === option.value ? 'border-primary bg-primary/5 shadow-sm' : 'hover:bg-gray-50'}`}
                  data-testid={`option-${option.value.toLowerCase()}`}
                >
                  <RadioGroupItem value={option.value} id={option.value} className="mt-1" />
                  <div className="grid gap-1.5 leading-none">
                    <Label htmlFor={option.value} className="font-bold text-base cursor-pointer">
                      {option.label}
                    </Label>
                    <p className="text-sm text-muted-foreground">
                      {option.desc}
                    </p>
                  </div>
                </div>
              ))}
            </RadioGroup>

            {status === 'PREGNANT' && (
              <div className="space-y-3 animate-in fade-in slide-in-from-top-2">
                <Label htmlFor="dueDate">When is your due date?</Label>
                <div className="relative">
                   <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground w-4 h-4" />
                   <Input 
                    id="dueDate" 
                    type="date" 
                    className="pl-10"
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    data-testid="input-due-date"
                   />
                </div>
              </div>
            )}

            {status === 'POSTPARTUM' && (
              <div className="space-y-3 animate-in fade-in slide-in-from-top-2">
                <Label htmlFor="birthDate">When was your baby born?</Label>
                <div className="relative">
                   <Baby className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground w-4 h-4" />
                   <Input 
                    id="birthDate" 
                    type="date" 
                    className="pl-10"
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    data-testid="input-birth-date"
                   />
                </div>
              </div>
            )}

            <Button 
              className="w-full bg-primary hover:bg-primary/90 text-white h-12 text-base"
              onClick={handleSubmit}
              disabled={mutation.isPending || (status !== 'PLANNING' && status !== 'NONE' && !date)}
              data-testid="button-continue"
            >
              {mutation.isPending ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" /> Saving...
                </>
              ) : (
                "Continue to Mom Dashboard"
              )}
            </Button>

          </CardContent>
        </Card>
      </div>
    </div>
  );
}
