import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertUserSchema, selectUserSchema,
  insertHealthProfileSchema,
  insertHealthLogSchema,
  insertMotherhoodProfileSchema,
  insertBirthPlanSchema,
  insertBabyProfileSchema,
  insertBabyLogSchema,
  insertCommunityPostSchema,
  insertCommunityReplySchema,
  insertProfessionalProfileSchema,
  insertBookingSlotSchema,
  insertBookingSchema,
  insertOrganizationSchema,
  insertAiAgentSchema,
  insertAiTaskSchema,
} from "@shared/schema";
import { hashPassword, comparePassword, generateToken, authMiddleware, type AuthRequest } from "./auth";
import { z } from "zod";

const requireRole = (...roles: string[]) => {
  return async (req: AuthRequest, res: Response, next: NextFunction) => {
    if (!req.userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    const user = await storage.getUser(req.userId);
    if (!user || !roles.includes(user.role)) {
      return res.status(403).json({ message: "Forbidden: insufficient permissions" });
    }
    (req as any).userRole = user.role;
    next();
  };
};

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  // ============================================================================
  // AUTH ROUTES
  // ============================================================================

  // POST /api/auth/register - Register a new user
  app.post("/api/auth/register", async (req, res) => {
    try {
      const validatedData = insertUserSchema.parse(req.body);
      
      const existingUser = await storage.getUserByUsername(validatedData.username);
      if (existingUser) {
        return res.status(400).json({ message: "Username already exists" });
      }

      const hashedPassword = await hashPassword(validatedData.password);
      
      const user = await storage.createUser({
        ...validatedData,
        password: hashedPassword,
        role: validatedData.role || "USER",
      });

      const token = generateToken(user.id, user.username);
      const profile = selectUserSchema.parse(user);

      res.status(201).json({
        token,
        user: profile,
      });
    } catch (error: any) {
      if (error.name === "ZodError") {
        return res.status(400).json({ message: "Invalid input", errors: error.errors });
      }
      res.status(500).json({ message: "Registration failed" });
    }
  });

  // POST /api/auth/login - Login with username and password
  app.post("/api/auth/login", async (req, res) => {
    try {
      const { username, password } = req.body;

      if (!username || !password) {
        return res.status(400).json({ message: "Username and password required" });
      }

      const user = await storage.getUserByUsername(username);
      if (!user) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      const isValidPassword = await comparePassword(password, user.password);
      if (!isValidPassword) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      const token = generateToken(user.id, user.username);
      const profile = selectUserSchema.parse(user);

      res.json({
        token,
        user: profile,
      });
    } catch (error) {
      res.status(500).json({ message: "Login failed" });
    }
  });

  // GET /api/auth/me - Get current authenticated user
  app.get("/api/auth/me", authMiddleware, async (req: AuthRequest, res) => {
    try {
      if (!req.userId) {
        return res.status(401).json({ message: "Not authenticated" });
      }

      const user = await storage.getUser(req.userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      const profile = selectUserSchema.parse(user);
      res.json({ user: profile });
    } catch (error) {
      res.status(500).json({ message: "Failed to get user" });
    }
  });

  // ============================================================================
  // HEALTH PROFILE & LOGS ROUTES (authenticated)
  // ============================================================================

  // GET /api/v1/health/profile - Get current user's health profile
  app.get("/api/v1/health/profile", authMiddleware, async (req: AuthRequest, res) => {
    try {
      const profile = await storage.getHealthProfile(req.userId!);
      if (!profile) {
        return res.status(404).json({ message: "Health profile not found" });
      }
      res.json(profile);
    } catch (error) {
      res.status(500).json({ message: "Failed to get health profile" });
    }
  });

  // POST /api/v1/health/profile - Create or update health profile
  app.post("/api/v1/health/profile", authMiddleware, async (req: AuthRequest, res) => {
    try {
      const validatedData = insertHealthProfileSchema.parse({
        ...req.body,
        userId: req.userId,
      });
      
      const profile = await storage.upsertHealthProfile(validatedData);
      res.json(profile);
    } catch (error: any) {
      if (error.name === "ZodError") {
        return res.status(400).json({ message: "Invalid input", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to save health profile" });
    }
  });

  // GET /api/v1/health/logs - Get health logs for user (with pagination)
  app.get("/api/v1/health/logs", authMiddleware, async (req: AuthRequest, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 50;
      const offset = parseInt(req.query.offset as string) || 0;
      
      const logs = await storage.getHealthLogs(req.userId!, limit, offset);
      res.json(logs);
    } catch (error) {
      res.status(500).json({ message: "Failed to get health logs" });
    }
  });

  // POST /api/v1/health/logs - Create a new health log entry
  app.post("/api/v1/health/logs", authMiddleware, async (req: AuthRequest, res) => {
    try {
      const validatedData = insertHealthLogSchema.parse({
        ...req.body,
        userId: req.userId,
      });
      
      const log = await storage.createHealthLog(validatedData);
      res.status(201).json(log);
    } catch (error: any) {
      if (error.name === "ZodError") {
        return res.status(400).json({ message: "Invalid input", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create health log" });
    }
  });

  // ============================================================================
  // PROGRAMS ROUTES
  // ============================================================================

  // GET /api/v1/programs - List all active programs
  app.get("/api/v1/programs", async (req, res) => {
    try {
      const programs = await storage.getPrograms(true);
      res.json(programs);
    } catch (error) {
      res.status(500).json({ message: "Failed to get programs" });
    }
  });

  // GET /api/v1/programs/recommended - Get recommended programs based on user's risk score
  app.get("/api/v1/programs/recommended", authMiddleware, async (req: AuthRequest, res) => {
    try {
      const profile = await storage.getHealthProfile(req.userId!);
      const riskScore = profile?.riskScore || 0;
      
      const programs = await storage.getRecommendedPrograms(riskScore);
      res.json(programs);
    } catch (error) {
      res.status(500).json({ message: "Failed to get recommended programs" });
    }
  });

  // GET /api/v1/programs/:id - Get program details with modules
  app.get("/api/v1/programs/:id", async (req, res) => {
    try {
      const programId = parseInt(req.params.id);
      if (isNaN(programId)) {
        return res.status(400).json({ message: "Invalid program ID" });
      }
      
      const result = await storage.getProgramWithModules(programId);
      if (!result) {
        return res.status(404).json({ message: "Program not found" });
      }
      
      res.json(result);
    } catch (error) {
      res.status(500).json({ message: "Failed to get program" });
    }
  });

  // ============================================================================
  // ASSESSMENT ROUTES
  // ============================================================================

  // GET /api/v1/assessment/questions - Get assessment questions
  app.get("/api/v1/assessment/questions", async (req, res) => {
    try {
      const questions = await storage.getAssessmentQuestions();
      res.json(questions);
    } catch (error) {
      res.status(500).json({ message: "Failed to get assessment questions" });
    }
  });

  // POST /api/v1/assessment/submit - Submit assessment and calculate risk score
  app.post("/api/v1/assessment/submit", authMiddleware, async (req: AuthRequest, res) => {
    try {
      const { answers } = req.body;
      
      if (!answers || typeof answers !== 'object') {
        return res.status(400).json({ message: "Invalid answers format" });
      }

      // Calculate risk score based on answers
      let riskScore = 0;
      
      // Age factor (higher age = higher risk)
      const age = parseInt(answers.age) || 30;
      if (age >= 55) riskScore += 20;
      else if (age >= 45) riskScore += 15;
      else if (age >= 35) riskScore += 10;
      else riskScore += 5;

      // BMI factor
      const bmi = parseFloat(answers.bmi) || 22;
      if (bmi >= 35) riskScore += 25;
      else if (bmi >= 30) riskScore += 20;
      else if (bmi >= 25) riskScore += 10;
      else riskScore += 5;

      // Family history factors
      if (answers.familyHistoryDiabetes) riskScore += 15;
      if (answers.familyHistoryHeartDisease) riskScore += 15;
      if (answers.familyHistoryHighBloodPressure) riskScore += 10;
      if (answers.familyHistoryCancer) riskScore += 10;

      // Lifestyle factors
      if (answers.smoking === 'yes') riskScore += 15;
      if (answers.alcohol === 'heavy') riskScore += 10;
      else if (answers.alcohol === 'moderate') riskScore += 5;
      if (answers.exercise === 'none') riskScore += 10;
      else if (answers.exercise === 'low') riskScore += 5;
      if (answers.diet === 'poor') riskScore += 10;
      else if (answers.diet === 'average') riskScore += 5;

      // Cap at 100
      riskScore = Math.min(riskScore, 100);

      // Determine risk level
      let riskLevel: 'LOW' | 'MODERATE' | 'HIGH';
      if (riskScore >= 60) riskLevel = 'HIGH';
      else if (riskScore >= 35) riskLevel = 'MODERATE';
      else riskLevel = 'LOW';

      // Update health profile with risk assessment
      await storage.upsertHealthProfile({
        userId: req.userId!,
        riskScore,
        riskLevel,
        bmi: bmi,
        familyHistory: [
          answers.familyHistoryDiabetes ? 'diabetes' : null,
          answers.familyHistoryHeartDisease ? 'heart_disease' : null,
          answers.familyHistoryHighBloodPressure ? 'high_blood_pressure' : null,
          answers.familyHistoryCancer ? 'cancer' : null,
        ].filter(Boolean) as string[],
        lifestyle: [
          answers.smoking === 'yes' ? 'smoker' : null,
          answers.exercise === 'none' ? 'sedentary' : null,
          answers.diet === 'poor' ? 'poor_diet' : null,
        ].filter(Boolean) as string[],
      });

      res.json({ riskScore, riskLevel });
    } catch (error) {
      res.status(500).json({ message: "Failed to process assessment" });
    }
  });

  // ============================================================================
  // MOTHERHOOD ROUTES (authenticated)
  // ============================================================================

  // GET /api/v1/mom/profile - Get motherhood profile
  app.get("/api/v1/mom/profile", authMiddleware, async (req: AuthRequest, res) => {
    try {
      const profile = await storage.getMotherhoodProfile(req.userId!);
      if (!profile) {
        return res.status(404).json({ message: "Motherhood profile not found" });
      }
      res.json(profile);
    } catch (error) {
      res.status(500).json({ message: "Failed to get motherhood profile" });
    }
  });

  // POST /api/v1/mom/profile - Create or update motherhood profile
  app.post("/api/v1/mom/profile", authMiddleware, async (req: AuthRequest, res) => {
    try {
      const validatedData = insertMotherhoodProfileSchema.parse({
        ...req.body,
        userId: req.userId,
      });
      
      const profile = await storage.upsertMotherhoodProfile(validatedData);
      res.json(profile);
    } catch (error: any) {
      if (error.name === "ZodError") {
        return res.status(400).json({ message: "Invalid input", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to save motherhood profile" });
    }
  });

  // GET /api/v1/mom/birth-plan - Get birth plan
  app.get("/api/v1/mom/birth-plan", authMiddleware, async (req: AuthRequest, res) => {
    try {
      const plan = await storage.getBirthPlan(req.userId!);
      if (!plan) {
        return res.status(404).json({ message: "Birth plan not found" });
      }
      res.json(plan);
    } catch (error) {
      res.status(500).json({ message: "Failed to get birth plan" });
    }
  });

  // POST /api/v1/mom/birth-plan - Create or update birth plan
  app.post("/api/v1/mom/birth-plan", authMiddleware, async (req: AuthRequest, res) => {
    try {
      const validatedData = insertBirthPlanSchema.parse({
        ...req.body,
        userId: req.userId,
      });
      
      const plan = await storage.upsertBirthPlan(validatedData);
      res.json(plan);
    } catch (error: any) {
      if (error.name === "ZodError") {
        return res.status(400).json({ message: "Invalid input", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to save birth plan" });
    }
  });

  // GET /api/v1/mom/babies - Get all baby profiles for user
  app.get("/api/v1/mom/babies", authMiddleware, async (req: AuthRequest, res) => {
    try {
      const babies = await storage.getBabyProfiles(req.userId!);
      res.json(babies);
    } catch (error) {
      res.status(500).json({ message: "Failed to get baby profiles" });
    }
  });

  // POST /api/v1/mom/babies - Create a new baby profile
  app.post("/api/v1/mom/babies", authMiddleware, async (req: AuthRequest, res) => {
    try {
      const validatedData = insertBabyProfileSchema.parse({
        ...req.body,
        userId: req.userId,
      });
      
      const baby = await storage.createBabyProfile(validatedData);
      res.status(201).json(baby);
    } catch (error: any) {
      if (error.name === "ZodError") {
        return res.status(400).json({ message: "Invalid input", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create baby profile" });
    }
  });

  // GET /api/v1/mom/babies/:babyId/logs - Get logs for a specific baby
  app.get("/api/v1/mom/babies/:babyId/logs", authMiddleware, async (req: AuthRequest, res) => {
    try {
      const babyId = parseInt(req.params.babyId);
      if (isNaN(babyId)) {
        return res.status(400).json({ message: "Invalid baby ID" });
      }
      
      // Verify baby belongs to user
      const baby = await storage.getBabyProfile(babyId);
      if (!baby || baby.userId !== req.userId) {
        return res.status(404).json({ message: "Baby not found" });
      }
      
      const limit = parseInt(req.query.limit as string) || 50;
      const offset = parseInt(req.query.offset as string) || 0;
      
      const logs = await storage.getBabyLogs(babyId, limit, offset);
      res.json(logs);
    } catch (error) {
      res.status(500).json({ message: "Failed to get baby logs" });
    }
  });

  // POST /api/v1/mom/babies/:babyId/logs - Create a log entry for a baby
  app.post("/api/v1/mom/babies/:babyId/logs", authMiddleware, async (req: AuthRequest, res) => {
    try {
      const babyId = parseInt(req.params.babyId);
      if (isNaN(babyId)) {
        return res.status(400).json({ message: "Invalid baby ID" });
      }
      
      // Verify baby belongs to user
      const baby = await storage.getBabyProfile(babyId);
      if (!baby || baby.userId !== req.userId) {
        return res.status(404).json({ message: "Baby not found" });
      }
      
      const validatedData = insertBabyLogSchema.parse({
        ...req.body,
        babyId,
      });
      
      const log = await storage.createBabyLog(validatedData);
      res.status(201).json(log);
    } catch (error: any) {
      if (error.name === "ZodError") {
        return res.status(400).json({ message: "Invalid input", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create baby log" });
    }
  });

  // AI ENDPOINTS

  // POST /api/v1/ai/chat - AI chat endpoint
  app.post("/api/v1/ai/chat", authMiddleware, async (req: AuthRequest, res) => {
    try {
      const { agentSlug, message } = req.body;

      if (!agentSlug || !message) {
        return res.status(400).json({ message: "Missing agentSlug or message" });
      }

      // Centralized mock AI logic (can be replaced with real provider later)
      let responseContent = "";

      if (agentSlug.includes("nurse")) {
        responseContent = `Based on your symptoms ("${message}"), I recommend monitoring them closely. Maintaining hydration and rest is crucial. However, please consult a doctor for a proper diagnosis.`;
      } else if (agentSlug.includes("doula")) {
        responseContent = `That's a wonderful question about your journey. "${message}" is something many mothers experience. Remember to listen to your body and breathe through the changes. You are doing great!`;
      } else if (agentSlug.includes("sleep")) {
        responseContent = `Sleep routines can be tough! Regarding "${message}", consistency is key. Try to establish a calming wind-down routine about 30 minutes before bed.`;
      } else {
        responseContent = `I understand you're asking about "${message}". Here is some general information based on my training...`;
      }

      // Add Safety Disclaimer
      const disclaimer =
        "\n\n---\n**Note:** I am an AI assistant, not a doctor. I cannot diagnose or treat. For urgent or serious concerns, contact a qualified healthcare professional or emergency services.";

      const conversationId = req.body.conversationId || `conv-${Date.now()}`;

      res.json({
        content: responseContent + disclaimer,
        conversationId,
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to process AI chat request" });
    }
  });

  // ============================================================================
  // COMMUNITY ROUTES (authenticated)
  // ============================================================================

  // GET /api/v1/community/groups - List all community groups
  app.get("/api/v1/community/groups", authMiddleware, async (req: AuthRequest, res) => {
    try {
      const groups = await storage.getCommunityGroups();
      res.json(groups);
    } catch (error) {
      res.status(500).json({ message: "Failed to get community groups" });
    }
  });

  // GET /api/v1/community/groups/:slug/posts - Get posts for a group
  app.get("/api/v1/community/groups/:slug/posts", authMiddleware, async (req: AuthRequest, res) => {
    try {
      const group = await storage.getCommunityGroupBySlug(req.params.slug);
      if (!group) {
        return res.status(404).json({ message: "Group not found" });
      }
      const posts = await storage.getCommunityPosts(group.id);
      res.json({ group, posts });
    } catch (error) {
      res.status(500).json({ message: "Failed to get community posts" });
    }
  });

  // POST /api/v1/community/groups/:slug/posts - Create a post in a group
  app.post("/api/v1/community/groups/:slug/posts", authMiddleware, async (req: AuthRequest, res) => {
    try {
      const group = await storage.getCommunityGroupBySlug(req.params.slug);
      if (!group) {
        return res.status(404).json({ message: "Group not found" });
      }
      
      const validatedData = insertCommunityPostSchema.parse({
        groupId: group.id,
        userId: req.userId,
        content: req.body.content,
      });
      
      const post = await storage.createCommunityPost(validatedData);
      res.status(201).json(post);
    } catch (error: any) {
      if (error.name === "ZodError") {
        return res.status(400).json({ message: "Invalid input", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create post" });
    }
  });

  // GET /api/v1/community/posts/:id/replies - Get replies for a post
  app.get("/api/v1/community/posts/:id/replies", authMiddleware, async (req: AuthRequest, res) => {
    try {
      const postId = parseInt(req.params.id);
      if (isNaN(postId)) {
        return res.status(400).json({ message: "Invalid post ID" });
      }
      
      const post = await storage.getCommunityPost(postId);
      if (!post) {
        return res.status(404).json({ message: "Post not found" });
      }
      
      const replies = await storage.getCommunityReplies(postId);
      res.json({ post, replies });
    } catch (error) {
      res.status(500).json({ message: "Failed to get replies" });
    }
  });

  // POST /api/v1/community/posts/:id/replies - Create a reply to a post
  app.post("/api/v1/community/posts/:id/replies", authMiddleware, async (req: AuthRequest, res) => {
    try {
      const postId = parseInt(req.params.id);
      if (isNaN(postId)) {
        return res.status(400).json({ message: "Invalid post ID" });
      }
      
      const post = await storage.getCommunityPost(postId);
      if (!post) {
        return res.status(404).json({ message: "Post not found" });
      }
      
      const validatedData = insertCommunityReplySchema.parse({
        postId,
        userId: req.userId,
        content: req.body.content,
      });
      
      const reply = await storage.createCommunityReply(validatedData);
      res.status(201).json(reply);
    } catch (error: any) {
      if (error.name === "ZodError") {
        return res.status(400).json({ message: "Invalid input", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create reply" });
    }
  });

  // ============================================================================
  // MARKETPLACE ROUTES - Professional Side (role = PROFESSIONAL)
  // ============================================================================

  // GET /api/v1/marketplace/professional/me - Get current professional's profile
  app.get("/api/v1/marketplace/professional/me", authMiddleware, requireRole("PROFESSIONAL"), async (req: AuthRequest, res) => {
    try {
      const profile = await storage.getProfessionalProfileByUserId(req.userId!);
      if (!profile) {
        return res.status(404).json({ message: "Professional profile not found" });
      }
      res.json(profile);
    } catch (error) {
      res.status(500).json({ message: "Failed to get professional profile" });
    }
  });

  // POST /api/v1/marketplace/professional/me - Create or update professional profile
  app.post("/api/v1/marketplace/professional/me", authMiddleware, requireRole("PROFESSIONAL"), async (req: AuthRequest, res) => {
    try {
      const validatedData = insertProfessionalProfileSchema.parse({
        ...req.body,
        userId: req.userId,
      });
      
      const profile = await storage.upsertProfessionalProfile(validatedData);
      res.json(profile);
    } catch (error: any) {
      if (error.name === "ZodError") {
        return res.status(400).json({ message: "Invalid input", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to save professional profile" });
    }
  });

  // POST /api/v1/marketplace/professional/slots - Create booking slots
  app.post("/api/v1/marketplace/professional/slots", authMiddleware, requireRole("PROFESSIONAL"), async (req: AuthRequest, res) => {
    try {
      const profile = await storage.getProfessionalProfileByUserId(req.userId!);
      if (!profile) {
        return res.status(404).json({ message: "Professional profile not found. Create one first." });
      }
      
      const validatedData = insertBookingSlotSchema.parse({
        ...req.body,
        professionalId: profile.id,
      });
      
      const slot = await storage.createBookingSlot(validatedData);
      res.status(201).json(slot);
    } catch (error: any) {
      if (error.name === "ZodError") {
        return res.status(400).json({ message: "Invalid input", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create booking slot" });
    }
  });

  // GET /api/v1/marketplace/professional/bookings - Get bookings for professional
  app.get("/api/v1/marketplace/professional/bookings", authMiddleware, requireRole("PROFESSIONAL"), async (req: AuthRequest, res) => {
    try {
      const profile = await storage.getProfessionalProfileByUserId(req.userId!);
      if (!profile) {
        return res.status(404).json({ message: "Professional profile not found" });
      }
      
      const bookings = await storage.getBookingsForProfessional(profile.id);
      res.json(bookings);
    } catch (error) {
      res.status(500).json({ message: "Failed to get bookings" });
    }
  });

  // PATCH /api/v1/marketplace/bookings/:id - Update booking status (confirm/cancel)
  app.patch("/api/v1/marketplace/bookings/:id", authMiddleware, requireRole("PROFESSIONAL"), async (req: AuthRequest, res) => {
    try {
      const bookingId = parseInt(req.params.id);
      if (isNaN(bookingId)) {
        return res.status(400).json({ message: "Invalid booking ID" });
      }
      
      const { status } = req.body;
      if (!['CONFIRMED', 'CANCELLED', 'COMPLETED'].includes(status)) {
        return res.status(400).json({ message: "Invalid status. Use CONFIRMED, CANCELLED, or COMPLETED" });
      }
      
      const booking = await storage.updateBookingStatus(bookingId, status);
      if (!booking) {
        return res.status(404).json({ message: "Booking not found" });
      }
      
      res.json(booking);
    } catch (error) {
      res.status(500).json({ message: "Failed to update booking" });
    }
  });

  // ============================================================================
  // MARKETPLACE ROUTES - User Side
  // ============================================================================

  // GET /api/v1/marketplace/professionals - Search/filter professionals
  app.get("/api/v1/marketplace/professionals", async (req, res) => {
    try {
      const professionType = req.query.type as string | undefined;
      const search = req.query.search as string | undefined;
      
      const professionals = await storage.getProfessionalProfiles({ professionType, search });
      res.json(professionals);
    } catch (error) {
      res.status(500).json({ message: "Failed to get professionals" });
    }
  });

  // GET /api/v1/marketplace/professionals/:id - Get professional detail with slots
  app.get("/api/v1/marketplace/professionals/:id", async (req, res) => {
    try {
      const professionalId = parseInt(req.params.id);
      if (isNaN(professionalId)) {
        return res.status(400).json({ message: "Invalid professional ID" });
      }
      
      const professional = await storage.getProfessionalProfile(professionalId);
      if (!professional) {
        return res.status(404).json({ message: "Professional not found" });
      }
      
      const slots = await storage.getBookingSlots(professionalId, true);
      res.json({ professional, slots });
    } catch (error) {
      res.status(500).json({ message: "Failed to get professional details" });
    }
  });

  // POST /api/v1/marketplace/bookings - Book a slot
  app.post("/api/v1/marketplace/bookings", authMiddleware, async (req: AuthRequest, res) => {
    try {
      const validatedData = insertBookingSchema.parse({
        ...req.body,
        userId: req.userId,
      });
      
      const booking = await storage.createBooking(validatedData);
      res.status(201).json(booking);
    } catch (error: any) {
      if (error.name === "ZodError") {
        return res.status(400).json({ message: "Invalid input", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create booking" });
    }
  });

  // GET /api/v1/marketplace/bookings/my - Get user's bookings
  app.get("/api/v1/marketplace/bookings/my", authMiddleware, async (req: AuthRequest, res) => {
    try {
      const bookings = await storage.getBookingsForUser(req.userId!);
      res.json(bookings);
    } catch (error) {
      res.status(500).json({ message: "Failed to get bookings" });
    }
  });

  // ============================================================================
  // EMPLOYER ROUTES (role = EMPLOYER)
  // ============================================================================

  // GET /api/v1/employer/org - Get organization details
  app.get("/api/v1/employer/org", authMiddleware, requireRole("EMPLOYER"), async (req: AuthRequest, res) => {
    try {
      const org = await storage.getOrganizationByOwner(req.userId!);
      if (!org) {
        return res.status(404).json({ message: "Organization not found" });
      }
      res.json(org);
    } catch (error) {
      res.status(500).json({ message: "Failed to get organization" });
    }
  });

  // POST /api/v1/employer/org - Create or update organization
  app.post("/api/v1/employer/org", authMiddleware, requireRole("EMPLOYER"), async (req: AuthRequest, res) => {
    try {
      const validatedData = insertOrganizationSchema.parse({
        ...req.body,
        ownerUserId: req.userId,
      });
      
      const org = await storage.upsertOrganization(validatedData);
      res.json(org);
    } catch (error: any) {
      if (error.name === "ZodError") {
        return res.status(400).json({ message: "Invalid input", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to save organization" });
    }
  });

  // GET /api/v1/employer/org/summary - Get organization analytics summary
  app.get("/api/v1/employer/org/summary", authMiddleware, requireRole("EMPLOYER"), async (req: AuthRequest, res) => {
    try {
      const org = await storage.getOrganizationByOwner(req.userId!);
      if (!org) {
        return res.status(404).json({ message: "Organization not found" });
      }
      
      const memberCount = await storage.getOrgMemberCount(org.id);
      const riskDistribution = await storage.getOrgRiskDistribution(org.id);
      const programEnrollments = await storage.getOrgProgramEnrollments(org.id);
      
      res.json({
        organization: org,
        memberCount,
        riskDistribution,
        programEnrollments,
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to get organization summary" });
    }
  });

  // ============================================================================
  // AI CHAT ROUTES
  // ============================================================================

  const AI_HEALTH_DISCLAIMER = "\n\n---\n*I am an AI assistant, not a medical professional. This information is for educational purposes only. Please consult a healthcare provider for personalized medical advice, diagnosis, or treatment. If you are experiencing a medical emergency, please call emergency services immediately.*";

  const AI_SAFETY_RULES = `
IMPORTANT SAFETY RULES:
- Never provide specific medical diagnoses
- Always recommend consulting a healthcare professional for serious concerns
- If someone mentions suicidal thoughts or self-harm, provide crisis resources immediately
- Never prescribe medications or specific dosages
- Respect privacy and confidentiality
- Be culturally sensitive and inclusive
- Acknowledge limitations of AI health advice
`;

  // POST /api/v1/ai/chat - Chat with an AI agent
  app.post("/api/v1/ai/chat", authMiddleware, async (req: AuthRequest, res) => {
    try {
      const chatSchema = z.object({
        agentSlug: z.string(),
        message: z.string().min(1).max(5000),
        conversationId: z.string().optional(),
      });

      const { agentSlug, message, conversationId } = chatSchema.parse(req.body);

      const agent = await storage.getAiAgentBySlug(agentSlug);
      if (!agent) {
        return res.status(404).json({ message: "AI agent not found" });
      }

      if (!agent.isActive) {
        return res.status(400).json({ message: "AI agent is currently unavailable" });
      }

      const convId = conversationId || `conv_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

      await storage.createAiMessage({
        userId: req.userId!,
        agentId: agent.id,
        conversationId: convId,
        role: "user",
        content: message,
      });

      const history = await storage.getAiMessages(req.userId!, agent.id, convId);

      const aiApiKey = process.env.AI_API_KEY || process.env.OPENAI_API_KEY;
      let responseContent: string;

      if (aiApiKey) {
        try {
          const messages = [
            { role: "system", content: agent.systemInstructions + "\n\n" + AI_SAFETY_RULES },
            { role: "system", content: `Persona: ${agent.personaPrompt}` },
            ...history.slice(-10).map(m => ({ role: m.role as "user" | "assistant", content: m.content })),
          ];

          const openaiResponse = await fetch("https://api.openai.com/v1/chat/completions", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              "Authorization": `Bearer ${aiApiKey}`,
            },
            body: JSON.stringify({
              model: "gpt-4o-mini",
              messages,
              max_tokens: 1000,
              temperature: 0.7,
            }),
          });

          if (openaiResponse.ok) {
            const data = await openaiResponse.json();
            responseContent = data.choices[0]?.message?.content || "I apologize, but I couldn't generate a response. Please try again.";
          } else {
            responseContent = generateMockResponse(agent.name, message);
          }
        } catch (apiError) {
          responseContent = generateMockResponse(agent.name, message);
        }
      } else {
        responseContent = generateMockResponse(agent.name, message);
      }

      responseContent += AI_HEALTH_DISCLAIMER;

      await storage.createAiMessage({
        userId: req.userId!,
        agentId: agent.id,
        conversationId: convId,
        role: "assistant",
        content: responseContent,
      });

      res.json({
        content: responseContent,
        conversationId: convId,
      });
    } catch (error: any) {
      if (error.name === "ZodError") {
        return res.status(400).json({ message: "Invalid input", errors: error.errors });
      }
      console.error("AI chat error:", error);
      res.status(500).json({ message: "Failed to process AI chat" });
    }
  });

  // GET /api/v1/ai/agents - Get available AI agents for users
  app.get("/api/v1/ai/agents", authMiddleware, async (req: AuthRequest, res) => {
    try {
      const agents = await storage.getAiAgents(true);
      res.json(agents.map(a => ({
        id: a.id,
        name: a.name,
        slug: a.slug,
        description: a.description,
        scope: a.scope,
        targetAudience: a.targetAudience,
      })));
    } catch (error) {
      res.status(500).json({ message: "Failed to get AI agents" });
    }
  });

  // ============================================================================
  // ADMIN ROUTES (role = ADMIN)
  // ============================================================================

  // GET /api/v1/admin/users - List all users
  app.get("/api/v1/admin/users", authMiddleware, requireRole("ADMIN"), async (req: AuthRequest, res) => {
    try {
      const users = await storage.getAllUsers();
      res.json(users);
    } catch (error) {
      res.status(500).json({ message: "Failed to get users" });
    }
  });

  // ============================================================================
  // ADMIN AI ROUTES (role = ADMIN)
  // ============================================================================

  // GET /api/v1/admin/ai/agents - List all AI agents
  app.get("/api/v1/admin/ai/agents", authMiddleware, requireRole("ADMIN"), async (req: AuthRequest, res) => {
    try {
      const agents = await storage.getAiAgents(false);
      res.json(agents);
    } catch (error) {
      res.status(500).json({ message: "Failed to get AI agents" });
    }
  });

  // POST /api/v1/admin/ai/agents - Create new AI agent
  app.post("/api/v1/admin/ai/agents", authMiddleware, requireRole("ADMIN"), async (req: AuthRequest, res) => {
    try {
      const validatedData = insertAiAgentSchema.parse(req.body);
      const agent = await storage.createAiAgent(validatedData);
      res.status(201).json(agent);
    } catch (error: any) {
      if (error.name === "ZodError") {
        return res.status(400).json({ message: "Invalid input", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create AI agent" });
    }
  });

  // PATCH /api/v1/admin/ai/agents/:id - Update AI agent
  app.patch("/api/v1/admin/ai/agents/:id", authMiddleware, requireRole("ADMIN"), async (req: AuthRequest, res) => {
    try {
      const agentId = parseInt(req.params.id);
      if (isNaN(agentId)) {
        return res.status(400).json({ message: "Invalid agent ID" });
      }

      const existingAgent = await storage.getAiAgent(agentId);
      if (!existingAgent) {
        return res.status(404).json({ message: "AI agent not found" });
      }

      const updated = await storage.updateAiAgent(agentId, req.body);
      res.json(updated);
    } catch (error) {
      res.status(500).json({ message: "Failed to update AI agent" });
    }
  });

  // DELETE /api/v1/admin/ai/agents/:id - Delete AI agent
  app.delete("/api/v1/admin/ai/agents/:id", authMiddleware, requireRole("ADMIN"), async (req: AuthRequest, res) => {
    try {
      const agentId = parseInt(req.params.id);
      if (isNaN(agentId)) {
        return res.status(400).json({ message: "Invalid agent ID" });
      }

      await storage.deleteAiAgent(agentId);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete AI agent" });
    }
  });

  // GET /api/v1/admin/ai/tasks - List AI tasks
  app.get("/api/v1/admin/ai/tasks", authMiddleware, requireRole("ADMIN"), async (req: AuthRequest, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 50;
      const tasks = await storage.getAiTasks(limit);
      res.json(tasks);
    } catch (error) {
      res.status(500).json({ message: "Failed to get AI tasks" });
    }
  });

  // POST /api/v1/admin/ai/tasks - Create and run AI task
  app.post("/api/v1/admin/ai/tasks", authMiddleware, requireRole("ADMIN"), async (req: AuthRequest, res) => {
    try {
      const taskSchema = z.object({
        agentId: z.number(),
        type: z.string(),
        inputPayload: z.record(z.any()).optional(),
      });

      const { agentId, type, inputPayload } = taskSchema.parse(req.body);

      const agent = await storage.getAiAgent(agentId);
      if (!agent) {
        return res.status(404).json({ message: "AI agent not found" });
      }

      let task = await storage.createAiTask({
        agentId,
        type,
        inputPayload: inputPayload || {},
        status: "RUNNING",
        runByUserId: req.userId,
      });

      const aiApiKey = process.env.AI_API_KEY || process.env.OPENAI_API_KEY;
      let outputPayload: Record<string, any>;

      const taskPrompt = buildTaskPrompt(type, inputPayload || {});

      if (aiApiKey) {
        try {
          const messages = [
            { role: "system", content: agent.systemInstructions },
            { role: "system", content: `Persona: ${agent.personaPrompt}` },
            { role: "user", content: taskPrompt },
          ];

          const openaiResponse = await fetch("https://api.openai.com/v1/chat/completions", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              "Authorization": `Bearer ${aiApiKey}`,
            },
            body: JSON.stringify({
              model: "gpt-4o-mini",
              messages,
              max_tokens: 2000,
              temperature: 0.7,
            }),
          });

          if (openaiResponse.ok) {
            const data = await openaiResponse.json();
            outputPayload = {
              content: data.choices[0]?.message?.content || "Failed to generate content",
              model: "gpt-4o-mini",
              generatedAt: new Date().toISOString(),
            };
          } else {
            outputPayload = generateMockTaskOutput(type, inputPayload || {});
          }
        } catch (apiError) {
          outputPayload = generateMockTaskOutput(type, inputPayload || {});
        }
      } else {
        outputPayload = generateMockTaskOutput(type, inputPayload || {});
      }

      task = await storage.updateAiTask(task.id, {
        outputPayload,
        status: "COMPLETED",
      }) as any;

      res.json(task);
    } catch (error: any) {
      if (error.name === "ZodError") {
        return res.status(400).json({ message: "Invalid input", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to run AI task" });
    }
  });

  return httpServer;
}

// Helper functions for AI responses
function generateMockResponse(agentName: string, message: string): string {
  const responses: Record<string, string[]> = {
    nurse: [
      "Based on what you've shared, I'd recommend speaking with your healthcare provider about these symptoms. In the meantime, maintaining a balanced diet and regular exercise can support your overall health.",
      "That's a great question about your health. While I can provide general wellness information, I encourage you to discuss any specific concerns with your doctor.",
      "It's wonderful that you're taking an active interest in your health! Here are some general tips that might help...",
    ],
    doula: [
      "Every pregnancy journey is unique, and your feelings are completely valid. Let's explore some ways to support you during this special time.",
      "Birth planning can feel overwhelming, but remember that you have choices. Would you like to discuss your preferences?",
      "Congratulations on your pregnancy! It's normal to have many questions. I'm here to help you feel informed and empowered.",
    ],
    coach: [
      "Building healthy habits takes time and patience. Let's start with small, achievable goals that work for your lifestyle.",
      "Great progress on your wellness journey! Remember, consistency matters more than perfection.",
      "I understand the challenges you're facing. Let's work together to create a sustainable plan.",
    ],
  };

  const category = agentName.toLowerCase().includes('doula') || agentName.toLowerCase().includes('mom')
    ? 'doula'
    : agentName.toLowerCase().includes('nurse')
    ? 'nurse'
    : 'coach';

  const categoryResponses = responses[category] || responses.coach;
  return categoryResponses[Math.floor(Math.random() * categoryResponses.length)];
}

function buildTaskPrompt(type: string, input: Record<string, any>): string {
  switch (type) {
    case "CONTENT_GENERATION":
      return `Generate a health article about: ${input.topic || 'general wellness'}. Target audience: ${input.audience || 'women'}. Length: ${input.length || 'medium'} (about 500 words). Make it informative, empathetic, and actionable.`;
    case "PROGRAM_SUMMARY":
      return `Create a summary for a health program titled: ${input.programTitle || 'Health Program'}. Include key benefits, what participants will learn, and expected outcomes.`;
    case "WEEKLY_CAMPAIGN":
      return `Create a weekly health campaign message for: ${input.topic || 'wellness'}. Target audience: ${input.audience || 'Black women in North America'}. Include a catchy headline, key message, and call to action.`;
    default:
      return `Generate content based on: ${JSON.stringify(input)}`;
  }
}

function generateMockTaskOutput(type: string, input: Record<string, any>): Record<string, any> {
  return {
    content: `[Mock ${type} Output]\n\nThis is a simulated AI response for task type: ${type}.\n\nInput received:\n${JSON.stringify(input, null, 2)}\n\n---\n\nTo enable real AI responses, please configure the AI_API_KEY or OPENAI_API_KEY environment variable.`,
    model: "mock",
    generatedAt: new Date().toISOString(),
  };
}
