/**
 * Seed Script for Madiyu Health Hub
 * 
 * This script populates the database with initial programs and modules.
 * Run with: npx tsx server/seed.ts
 */

import { db } from "./db";
import { programs, programModules, users, motherhoodProfiles, babyProfiles, babyLogs, birthPlans, communityGroups, professionalProfiles, bookingSlots, organizations, orgMemberships, healthProfiles, userProgramEnrollments, aiAgents } from "@shared/schema";
import { eq } from "drizzle-orm";
import bcrypt from "bcrypt";

const SEED_PROGRAMS = [
  {
    title: "Diabetes Prevention for Women",
    description: "Evidence-based strategies to prevent type 2 diabetes through lifestyle changes, nutrition guidance, and physical activity plans tailored for women.",
    category: "Chronic Disease",
    imageUrl: "/images/diabetes-prevention.jpg",
    duration: "12 weeks",
    level: "Beginner",
    isActive: true,
    targetRole: "USER",
    modules: [
      {
        title: "Introduction to Diabetes Prevention",
        contentMarkdown: `# Welcome to the Diabetes Prevention Program

## What You'll Learn
- Understanding prediabetes and type 2 diabetes
- Risk factors specific to women
- The role of insulin resistance

## Key Facts
- Over 37 million Americans have diabetes
- 1 in 5 don't know they have it
- Women with gestational diabetes have increased risk

**Important:** Early intervention can prevent or delay type 2 diabetes by up to 58%.

## Getting Started
Complete your health profile to track your progress throughout this program.`,
        durationMinutes: 15,
        orderIndex: 0,
      },
      {
        title: "Nutrition Basics for Blood Sugar Control",
        contentMarkdown: `# Nutrition for Healthy Blood Sugar

## The Plate Method
Divide your plate into sections:
- **50%** Non-starchy vegetables
- **25%** Lean protein
- **25%** Whole grains or starchy foods

## Foods to Focus On
1. Leafy greens and colorful vegetables
2. Whole grains (quinoa, brown rice, oats)
3. Lean proteins (fish, chicken, legumes)
4. Healthy fats (olive oil, avocado, nuts)

## Foods to Limit
- Sugary beverages and juices
- Refined carbohydrates
- Processed foods high in sodium

## Meal Timing Tips
Eating at consistent times helps regulate blood sugar levels.`,
        durationMinutes: 25,
        orderIndex: 1,
      },
      {
        title: "Physical Activity for Prevention",
        contentMarkdown: `# Moving More for Better Health

## Recommended Activity Levels
Aim for at least **150 minutes per week** of moderate-intensity exercise.

### Types of Exercise
1. **Aerobic Activities**
   - Brisk walking
   - Swimming
   - Dancing
   - Cycling

2. **Strength Training**
   - Resistance bands
   - Body weight exercises
   - Light weights

3. **Flexibility**
   - Yoga
   - Stretching
   - Tai Chi

## Getting Started Safely
- Start slow and gradually increase intensity
- Listen to your body
- Stay hydrated

## Tracking Your Progress
Use a fitness tracker or journal to monitor your activity levels.`,
        durationMinutes: 20,
        orderIndex: 2,
      },
      {
        title: "Understanding Your Numbers",
        contentMarkdown: `# Health Metrics That Matter

## Key Tests to Know

### Fasting Blood Glucose
- **Normal:** Less than 100 mg/dL
- **Prediabetes:** 100-125 mg/dL
- **Diabetes:** 126 mg/dL or higher

### A1C Test
- **Normal:** Below 5.7%
- **Prediabetes:** 5.7-6.4%
- **Diabetes:** 6.5% or higher

### BMI
- **Healthy:** 18.5-24.9
- **Overweight:** 25-29.9
- **Obese:** 30+

## Tracking Tips
Log your readings in the app to see trends over time.`,
        durationMinutes: 15,
        orderIndex: 3,
      },
    ],
  },
  {
    title: "Blood Pressure & Heart Health",
    description: "Take control of your heart health with monitoring techniques, dietary changes, stress management, and evidence-based interventions.",
    category: "Chronic Disease",
    imageUrl: "/images/heart-health.jpg",
    duration: "6 weeks",
    level: "Intermediate",
    isActive: true,
    targetRole: "USER",
    modules: [
      {
        title: "Understanding Blood Pressure",
        contentMarkdown: `# Blood Pressure Basics

## What is Blood Pressure?
Blood pressure measures the force of blood against your artery walls.

### The Numbers
- **Systolic** (top number): Pressure when heart beats
- **Diastolic** (bottom number): Pressure between beats

### Categories
| Category | Systolic | Diastolic |
|----------|----------|-----------|
| Normal | Less than 120 | Less than 80 |
| Elevated | 120-129 | Less than 80 |
| High (Stage 1) | 130-139 | 80-89 |
| High (Stage 2) | 140+ | 90+ |

## Why It Matters for Women
- Heart disease is the #1 killer of women
- Pregnancy complications increase risk
- Hormonal changes affect blood pressure`,
        durationMinutes: 20,
        orderIndex: 0,
      },
      {
        title: "The DASH Diet",
        contentMarkdown: `# DASH Diet for Heart Health

## Dietary Approaches to Stop Hypertension

### Key Principles
1. Reduce sodium intake (goal: less than 2,300mg/day)
2. Increase potassium-rich foods
3. Focus on whole foods

### Daily Servings
- **Grains:** 6-8 servings
- **Vegetables:** 4-5 servings
- **Fruits:** 4-5 servings
- **Dairy (low-fat):** 2-3 servings
- **Lean meats:** 6 or fewer ounces

### Foods Rich in Potassium
- Bananas
- Sweet potatoes
- Spinach
- Beans
- Yogurt`,
        durationMinutes: 25,
        orderIndex: 1,
      },
      {
        title: "Stress & Your Heart",
        contentMarkdown: `# Managing Stress for Heart Health

## The Stress-Heart Connection
Chronic stress can:
- Raise blood pressure
- Increase inflammation
- Lead to unhealthy coping behaviors

## Stress Reduction Techniques

### Deep Breathing
Practice 4-7-8 breathing:
1. Inhale for 4 counts
2. Hold for 7 counts
3. Exhale for 8 counts

### Mindfulness Meditation
- Start with 5 minutes daily
- Focus on the present moment
- Use guided meditations

### Physical Activity
- Walking in nature
- Yoga
- Dancing

### Social Connection
Strong relationships protect heart health.`,
        durationMinutes: 20,
        orderIndex: 2,
      },
    ],
  },
  {
    title: "Breast Health & Early Detection",
    description: "Learn how to perform self-exams, understand the importance of regular screenings, and know the signs to watch for in breast health.",
    category: "Women's Health",
    imageUrl: "/images/breast-health.jpg",
    duration: "2 weeks",
    level: "All Levels",
    isActive: true,
    targetRole: "USER",
    modules: [
      {
        title: "Know Your Breasts",
        contentMarkdown: `# Understanding Your Breast Health

## Why Self-Awareness Matters
Knowing what's normal for you helps you notice changes early.

## Normal Breast Changes
- Size variations during menstrual cycle
- Tenderness before periods
- Changes during pregnancy and breastfeeding
- Changes with age and menopause

## When to See a Doctor
Contact your healthcare provider if you notice:
- A new lump or mass
- Skin changes (dimpling, puckering)
- Nipple discharge (especially bloody)
- Nipple changes or inversion
- Persistent pain in one area`,
        durationMinutes: 15,
        orderIndex: 0,
      },
      {
        title: "Self-Exam Guide",
        contentMarkdown: `# How to Perform a Breast Self-Exam

## When to Check
- Monthly, about 3-5 days after period ends
- Same time each month if post-menopausal

## Steps for Self-Exam

### In the Mirror
1. Stand with arms at sides
2. Raise arms overhead
3. Look for changes in shape, size, or skin

### Lying Down
1. Place a pillow under right shoulder
2. Use left hand to examine right breast
3. Use pads of fingers in circular motion
4. Cover entire breast area
5. Repeat on other side

### In the Shower
Soapy skin makes it easier to feel changes.

## Remember
Self-exams complement but don't replace professional screenings.`,
        durationMinutes: 20,
        orderIndex: 1,
      },
      {
        title: "Screening Guidelines",
        contentMarkdown: `# Recommended Breast Cancer Screenings

## Mammogram Guidelines
- **Ages 40-44:** Optional annual mammogram
- **Ages 45-54:** Annual mammogram recommended
- **Ages 55+:** Every 1-2 years

## Clinical Breast Exams
Discuss with your healthcare provider as part of regular checkups.

## Risk Factors
### You Can't Change
- Age
- Family history
- Genetic mutations (BRCA1/BRCA2)
- Dense breast tissue

### You Can Control
- Limiting alcohol
- Maintaining healthy weight
- Regular physical activity
- Breastfeeding when possible

## Talk to Your Doctor
Discuss your personal and family history to create a screening plan that's right for you.`,
        durationMinutes: 15,
        orderIndex: 2,
      },
    ],
  },
  {
    title: "Women's Mental Health & Stress",
    description: "Strategies for managing anxiety, burnout, and finding balance in daily life. Learn coping techniques and when to seek professional help.",
    category: "Mental Health",
    imageUrl: "/images/mental-health.jpg",
    duration: "8 weeks",
    level: "All Levels",
    isActive: true,
    targetRole: "USER",
    modules: [
      {
        title: "Understanding Women's Mental Health",
        contentMarkdown: `# Mental Health Throughout Life

## Unique Challenges for Women
Women face mental health challenges influenced by:
- Hormonal fluctuations
- Life transitions (pregnancy, menopause)
- Societal expectations
- Caregiving responsibilities
- Work-life balance

## Common Conditions
- **Anxiety Disorders:** Twice as common in women
- **Depression:** More prevalent in women
- **Perinatal Mental Health:** Affects 1 in 5 mothers
- **PMDD:** Severe form of PMS

## Breaking the Stigma
Seeking help is a sign of strength, not weakness.`,
        durationMinutes: 20,
        orderIndex: 0,
      },
      {
        title: "Recognizing Burnout",
        contentMarkdown: `# Identifying and Addressing Burnout

## Signs of Burnout
### Physical
- Chronic fatigue
- Frequent illness
- Sleep problems
- Headaches

### Emotional
- Feeling detached
- Sense of failure
- Cynicism
- Decreased satisfaction

### Behavioral
- Withdrawing from responsibilities
- Isolation
- Procrastination
- Using substances to cope

## Recovery Strategies
1. Set boundaries
2. Practice self-compassion
3. Reconnect with activities you enjoy
4. Seek support
5. Consider professional help`,
        durationMinutes: 25,
        orderIndex: 1,
      },
      {
        title: "Daily Stress Management",
        contentMarkdown: `# Practical Stress-Relief Techniques

## Quick Stress Busters (5 minutes or less)
- Box breathing (4-4-4-4)
- Progressive muscle relaxation
- Grounding exercises (5-4-3-2-1)
- Brief walk
- Listening to calming music

## Building Resilience

### Morning Routine
- Wake up at consistent time
- Brief meditation or journaling
- Healthy breakfast
- Set daily intentions

### Evening Wind-Down
- Digital sunset 1 hour before bed
- Gentle stretching
- Gratitude practice
- Consistent bedtime

## Support Systems
- Connect with friends and family
- Join support groups
- Consider therapy
- Use mental health apps`,
        durationMinutes: 25,
        orderIndex: 2,
      },
      {
        title: "When to Seek Help",
        contentMarkdown: `# Getting Professional Support

## Signs You May Need Help
- Symptoms lasting more than 2 weeks
- Difficulty functioning at work/home
- Thoughts of self-harm
- Substance use to cope
- Significant changes in sleep or appetite

## Types of Mental Health Professionals
- **Psychiatrist:** Can prescribe medication
- **Psychologist:** Therapy and testing
- **Therapist/Counselor:** Various therapy approaches
- **Social Worker:** Therapy and community resources

## Finding the Right Fit
- Check credentials
- Consider specializations
- Evaluate therapeutic approach
- Trust your instincts

## Crisis Resources
If you're in crisis, reach out:
- National Suicide Prevention Lifeline: 988
- Crisis Text Line: Text HOME to 741741

**Remember:** You deserve support and care.`,
        durationMinutes: 20,
        orderIndex: 3,
      },
    ],
  },
];

async function seed() {
  console.log("🌱 Starting database seed...\n");

  for (const programData of SEED_PROGRAMS) {
    const { modules, ...program } = programData;
    
    // Check if program already exists
    const existing = await db
      .select()
      .from(programs)
      .where(eq(programs.title, program.title));
    
    if (existing.length > 0) {
      console.log(`⏭️  Skipping "${program.title}" - already exists`);
      continue;
    }

    // Insert program
    const [insertedProgram] = await db
      .insert(programs)
      .values(program)
      .returning();
    
    console.log(`✅ Created program: ${insertedProgram.title}`);

    // Insert modules
    for (const module of modules) {
      await db.insert(programModules).values({
        ...module,
        programId: insertedProgram.id,
      });
    }
    
    console.log(`   └─ Added ${modules.length} modules`);
  }

  console.log("\n✨ Seed completed successfully!");
}

async function seedMotherhood() {
  console.log("\n🍼 Seeding motherhood demo data...\n");

  // Create or find demo user
  const demoUsername = "demo_mom";
  let existingUser = await db
    .select()
    .from(users)
    .where(eq(users.username, demoUsername));

  let demoUserId: string;

  if (existingUser.length === 0) {
    const hashedPassword = await bcrypt.hash("demo123", 10);
    const [newUser] = await db
      .insert(users)
      .values({
        username: demoUsername,
        password: hashedPassword,
        name: "Sarah Demo",
        email: "sarah@demo.com",
        role: "USER",
      })
      .returning();
    demoUserId = newUser.id;
    console.log(`✅ Created demo user: ${demoUsername}`);
  } else {
    demoUserId = existingUser[0].id;
    console.log(`⏭️  Demo user already exists: ${demoUsername}`);
  }

  // Create motherhood profile
  const existingProfile = await db
    .select()
    .from(motherhoodProfiles)
    .where(eq(motherhoodProfiles.userId, demoUserId));

  if (existingProfile.length === 0) {
    const dueDate = new Date();
    dueDate.setMonth(dueDate.getMonth() + 3);
    
    await db.insert(motherhoodProfiles).values({
      userId: demoUserId,
      status: "PREGNANT",
      weeksPregnant: 24,
      dueDate: dueDate.toISOString().split('T')[0],
      preferredBirthSetting: "HOSPITAL",
      notes: "First pregnancy, feeling good!",
    });
    console.log(`✅ Created motherhood profile (Pregnant, Week 24)`);
  } else {
    console.log(`⏭️  Motherhood profile already exists`);
  }

  // Create birth plan
  const existingBirthPlan = await db
    .select()
    .from(birthPlans)
    .where(eq(birthPlans.userId, demoUserId));

  if (existingBirthPlan.length === 0) {
    await db.insert(birthPlans).values({
      userId: demoUserId,
      painManagementPreference: "Open to suggestions - would like to try natural methods first",
      supportPeople: "Partner John, Sister Emily, Doula Maria",
      culturalPreferences: "Would like the baby placed on chest immediately after birth",
      medicalInterventionPreferences: "Prefer to avoid episiotomy unless medically necessary",
      extraNotes: "Please keep the room calm and quiet. Soft music is welcome.",
    });
    console.log(`✅ Created birth plan`);
  } else {
    console.log(`⏭️  Birth plan already exists`);
  }

  console.log("\n✨ Motherhood seed completed!");
}

async function seedPostpartumDemo() {
  console.log("\n👶 Seeding postpartum demo data...\n");

  // Create or find postpartum demo user
  const demoUsername = "demo_new_mom";
  let existingUser = await db
    .select()
    .from(users)
    .where(eq(users.username, demoUsername));

  let demoUserId: string;

  if (existingUser.length === 0) {
    const hashedPassword = await bcrypt.hash("demo123", 10);
    const [newUser] = await db
      .insert(users)
      .values({
        username: demoUsername,
        password: hashedPassword,
        name: "Emma Demo",
        email: "emma@demo.com",
        role: "USER",
      })
      .returning();
    demoUserId = newUser.id;
    console.log(`✅ Created demo user: ${demoUsername}`);
  } else {
    demoUserId = existingUser[0].id;
    console.log(`⏭️  Demo user already exists: ${demoUsername}`);
  }

  // Create postpartum profile
  const existingProfile = await db
    .select()
    .from(motherhoodProfiles)
    .where(eq(motherhoodProfiles.userId, demoUserId));

  if (existingProfile.length === 0) {
    const birthDate = new Date();
    birthDate.setMonth(birthDate.getMonth() - 1);
    
    await db.insert(motherhoodProfiles).values({
      userId: demoUserId,
      status: "POSTPARTUM",
      babyDateOfBirth: birthDate.toISOString().split('T')[0],
      numberOfChildren: 1,
      notes: "New mom, adjusting to life with baby!",
    });
    console.log(`✅ Created motherhood profile (Postpartum)`);
  } else {
    console.log(`⏭️  Motherhood profile already exists`);
  }

  // Create baby profile
  const existingBaby = await db
    .select()
    .from(babyProfiles)
    .where(eq(babyProfiles.userId, demoUserId));

  let babyId: number;

  if (existingBaby.length === 0) {
    const birthDate = new Date();
    birthDate.setMonth(birthDate.getMonth() - 1);
    
    const [newBaby] = await db
      .insert(babyProfiles)
      .values({
        userId: demoUserId,
        name: "Lily",
        dateOfBirth: birthDate.toISOString().split('T')[0],
        sex: "Female",
        notes: "Born at 7lbs 8oz",
      })
      .returning();
    babyId = newBaby.id;
    console.log(`✅ Created baby profile: Lily`);
  } else {
    babyId = existingBaby[0].id;
    console.log(`⏭️  Baby profile already exists`);
  }

  // Create baby logs
  const existingLogs = await db
    .select()
    .from(babyLogs)
    .where(eq(babyLogs.babyId, babyId));

  if (existingLogs.length === 0) {
    const now = new Date();
    const logs = [
      { type: "SLEEP", valueText: "Nap time", valueNumber: 45, dateTime: new Date(now.getTime() - 2 * 60 * 60 * 1000) },
      { type: "FEEDING", valueText: "Breastfed", valueNumber: 20, dateTime: new Date(now.getTime() - 3 * 60 * 60 * 1000) },
      { type: "DIAPER", valueText: "Wet diaper changed", valueNumber: null, dateTime: new Date(now.getTime() - 4 * 60 * 60 * 1000) },
      { type: "SLEEP", valueText: "Night sleep", valueNumber: 180, dateTime: new Date(now.getTime() - 8 * 60 * 60 * 1000) },
      { type: "FEEDING", valueText: "Formula feed", valueNumber: 15, dateTime: new Date(now.getTime() - 10 * 60 * 60 * 1000) },
      { type: "MILESTONE", valueText: "First smile!", valueNumber: null, dateTime: new Date(now.getTime() - 24 * 60 * 60 * 1000) },
    ];

    for (const log of logs) {
      await db.insert(babyLogs).values({
        babyId,
        type: log.type as any,
        valueText: log.valueText,
        valueNumber: log.valueNumber,
        dateTime: log.dateTime,
      });
    }
    console.log(`✅ Created ${logs.length} baby logs`);
  } else {
    console.log(`⏭️  Baby logs already exist`);
  }

  console.log("\n✨ Postpartum demo seed completed!");
}

async function seedCommunityGroups() {
  console.log("\n💬 Seeding community groups...\n");

  const GROUPS = [
    { name: "Black Women's Health", slug: "black-womens-health", description: "A safe space to discuss health topics specific to Black women, including maternal health, chronic disease, and wellness.", audienceType: "ALL" },
    { name: "Pregnant Moms", slug: "pregnant-moms", description: "Connect with other expecting mothers to share experiences, tips, and support throughout your pregnancy journey.", audienceType: "PREGNANT" },
    { name: "New Moms Support", slug: "new-moms", description: "A community for new mothers navigating the joys and challenges of parenthood in the first year.", audienceType: "POSTPARTUM" },
    { name: "Diabetes Prevention", slug: "diabetes-prevention", description: "Share strategies, recipes, and support for preventing and managing diabetes through lifestyle changes.", audienceType: "CHRONIC" },
    { name: "Heart Health Warriors", slug: "heart-health", description: "Supporting women in their journey to better cardiovascular health through diet, exercise, and stress management.", audienceType: "CHRONIC" },
    { name: "Mental Wellness", slug: "mental-wellness", description: "A judgment-free zone to discuss mental health, stress management, and self-care practices.", audienceType: "ALL" },
  ];

  for (const group of GROUPS) {
    const existing = await db.select().from(communityGroups).where(eq(communityGroups.slug, group.slug));
    if (existing.length === 0) {
      await db.insert(communityGroups).values(group);
      console.log(`✅ Created group: ${group.name}`);
    } else {
      console.log(`⏭️  Group already exists: ${group.name}`);
    }
  }

  console.log("\n✨ Community groups seed completed!");
}

async function seedProfessionals() {
  console.log("\n👩‍⚕️ Seeding professionals...\n");

  const PROFESSIONALS = [
    {
      username: "dr_nutrition",
      name: "Dr. Michelle Carter",
      professionType: "NUTRITIONIST",
      bio: "Registered dietitian with 10+ years specializing in women's health, prenatal nutrition, and diabetes prevention. Passionate about helping women achieve optimal health through personalized nutrition plans.",
      specialties: ["Prenatal Nutrition", "Diabetes Management", "Weight Management", "Heart-Healthy Eating"],
      hourlyRate: 85,
      isVerified: true,
      location: "Atlanta, GA",
      yearsExperience: 12,
    },
    {
      username: "doula_grace",
      name: "Grace Williams",
      professionType: "DOULA",
      bio: "Certified birth and postpartum doula providing compassionate support for families. Specializing in culturally-sensitive care and natural birth support.",
      specialties: ["Natural Birth Support", "Postpartum Care", "Breastfeeding Support", "Cultural Birth Practices"],
      hourlyRate: 65,
      isVerified: true,
      location: "Houston, TX",
      yearsExperience: 8,
    },
    {
      username: "sleep_coach_sarah",
      name: "Sarah Thompson",
      professionType: "COACH",
      bio: "Certified pediatric sleep consultant helping exhausted parents establish healthy sleep habits for their little ones. Evidence-based, gentle methods.",
      specialties: ["Infant Sleep Training", "Toddler Sleep Issues", "Sleep Regression", "Night Weaning"],
      hourlyRate: 75,
      isVerified: true,
      location: "Denver, CO",
      yearsExperience: 6,
    },
  ];

  for (const proData of PROFESSIONALS) {
    const { username, name, ...profileData } = proData;

    let existingUser = await db.select().from(users).where(eq(users.username, username));
    let userId: string;

    if (existingUser.length === 0) {
      const hashedPassword = await bcrypt.hash("demo123", 10);
      const [newUser] = await db
        .insert(users)
        .values({
          username,
          password: hashedPassword,
          name,
          email: `${username}@demo.com`,
          role: "PROFESSIONAL",
        })
        .returning();
      userId = newUser.id;
      console.log(`✅ Created professional user: ${username}`);
    } else {
      userId = existingUser[0].id;
      console.log(`⏭️  Professional user already exists: ${username}`);
    }

    const existingProfile = await db.select().from(professionalProfiles).where(eq(professionalProfiles.userId, userId));
    let professionalId: number;

    if (existingProfile.length === 0) {
      const [profile] = await db
        .insert(professionalProfiles)
        .values({
          userId,
          ...profileData,
        })
        .returning();
      professionalId = profile.id;
      console.log(`✅ Created professional profile: ${name}`);
    } else {
      professionalId = existingProfile[0].id;
      console.log(`⏭️  Professional profile already exists: ${name}`);
    }

    const existingSlots = await db.select().from(bookingSlots).where(eq(bookingSlots.professionalId, professionalId));
    if (existingSlots.length === 0) {
      const now = new Date();
      for (let i = 1; i <= 5; i++) {
        const slotDate = new Date(now);
        slotDate.setDate(slotDate.getDate() + i);
        slotDate.setHours(10 + (i % 3), 0, 0, 0);

        const endDate = new Date(slotDate);
        endDate.setHours(endDate.getHours() + 1);

        await db.insert(bookingSlots).values({
          professionalId,
          startDateTime: slotDate,
          endDateTime: endDate,
          isBooked: false,
        });
      }
      console.log(`✅ Created 5 booking slots for: ${name}`);
    } else {
      console.log(`⏭️  Booking slots already exist for: ${name}`);
    }
  }

  console.log("\n✨ Professionals seed completed!");
}

async function seedEmployerDemo() {
  console.log("\n🏢 Seeding employer demo data...\n");

  const employerUsername = "demo_employer";
  let existingUser = await db.select().from(users).where(eq(users.username, employerUsername));
  let employerUserId: string;

  if (existingUser.length === 0) {
    const hashedPassword = await bcrypt.hash("demo123", 10);
    const [newUser] = await db
      .insert(users)
      .values({
        username: employerUsername,
        password: hashedPassword,
        name: "Alex Johnson",
        email: "alex@acmecorp.com",
        role: "EMPLOYER",
      })
      .returning();
    employerUserId = newUser.id;
    console.log(`✅ Created employer user: ${employerUsername}`);
  } else {
    employerUserId = existingUser[0].id;
    console.log(`⏭️  Employer user already exists: ${employerUsername}`);
  }

  const existingOrg = await db.select().from(organizations).where(eq(organizations.ownerUserId, employerUserId));
  let orgId: number;

  if (existingOrg.length === 0) {
    const [org] = await db
      .insert(organizations)
      .values({
        name: "Acme Healthcare Inc",
        country: "United States",
        industry: "Healthcare",
        ownerUserId: employerUserId,
      })
      .returning();
    orgId = org.id;
    console.log(`✅ Created organization: Acme Healthcare Inc`);
  } else {
    orgId = existingOrg[0].id;
    console.log(`⏭️  Organization already exists`);
  }

  const existingMembers = await db.select().from(orgMemberships).where(eq(orgMemberships.orgId, orgId));
  if (existingMembers.length === 0) {
    const hashedPassword = await bcrypt.hash("demo123", 10);
    const riskLevels = ['LOW', 'LOW', 'LOW', 'MODERATE', 'MODERATE', 'HIGH'];
    const allPrograms = await db.select().from(programs).limit(4);

    for (let i = 1; i <= 6; i++) {
      const [memberUser] = await db
        .insert(users)
        .values({
          username: `acme_member_${i}`,
          password: hashedPassword,
          name: `Employee ${i}`,
          email: `employee${i}@acmecorp.com`,
          role: "USER",
        })
        .returning();

      await db.insert(orgMemberships).values({
        orgId,
        userId: memberUser.id,
        role: i === 1 ? "MANAGER" : "MEMBER",
      });

      await db.insert(healthProfiles).values({
        userId: memberUser.id,
        riskLevel: riskLevels[i - 1],
        riskScore: riskLevels[i - 1] === 'LOW' ? 25 : riskLevels[i - 1] === 'MODERATE' ? 50 : 75,
      });

      if (allPrograms.length > 0 && i <= 4) {
        await db.insert(userProgramEnrollments).values({
          userId: memberUser.id,
          programId: allPrograms[i % allPrograms.length].id,
          status: "ACTIVE",
          progress: Math.floor(Math.random() * 60) + 20,
        });
      }
    }
    console.log(`✅ Created 6 org members with health profiles`);
  } else {
    console.log(`⏭️  Org members already exist`);
  }

  console.log("\n✨ Employer demo seed completed!");
}

async function seedAiAgents() {
  console.log("\n🤖 Seeding AI Team agents...\n");

  const AI_AGENTS = [
    {
      name: "Madiyu AI Nurse",
      slug: "madiyu-ai-nurse",
      description: "Your friendly virtual health companion for general wellness questions and health education.",
      scope: "GENERAL_HEALTH",
      targetAudience: "All women seeking health guidance",
      personaPrompt: "You are a warm, knowledgeable, and empathetic virtual nurse named Nurse Nia. You speak with the caring tone of an experienced healthcare professional who genuinely wants to help women understand their health. You use clear, accessible language while being culturally sensitive to Black women's unique health experiences and disparities. You celebrate small victories and gently encourage healthy choices without judgment.",
      systemInstructions: "You are an AI health education assistant for Madiyu Health, a platform focused on women's health with special attention to Black women's health outcomes. Your role is to provide general health education, explain medical concepts in accessible terms, and help users understand when they should seek professional medical care. Always encourage preventive care and regular check-ups. Be culturally competent and aware of health disparities affecting Black women.",
      languages: ["en", "fr"],
    },
    {
      name: "Chronic Disease Coach",
      slug: "madiyu-chronic-disease-coach",
      description: "Specialized support for managing and preventing chronic conditions like diabetes and heart disease.",
      scope: "CHRONIC_DISEASE",
      targetAudience: "Women managing or preventing chronic conditions",
      personaPrompt: "You are Coach Maya, a compassionate chronic disease management specialist who understands the daily challenges of managing conditions like diabetes, hypertension, and heart disease. You provide practical, actionable advice while acknowledging that managing chronic conditions is a journey, not a destination. You celebrate progress and help users develop sustainable habits.",
      systemInstructions: "You specialize in chronic disease prevention and management education for women, with particular focus on conditions that disproportionately affect Black women including Type 2 diabetes, hypertension, and cardiovascular disease. Provide evidence-based lifestyle modification advice, explain how to interpret health metrics, and encourage medication adherence and regular healthcare visits. Never provide specific medication recommendations.",
      languages: ["en", "fr"],
    },
    {
      name: "AI Nutritionist",
      slug: "madiyu-ai-nutritionist",
      description: "Personalized nutrition guidance for overall health and specific health goals.",
      scope: "NUTRITION",
      targetAudience: "Women seeking nutrition guidance",
      personaPrompt: "You are Nutritionist Nia, a culturally-aware nutrition specialist who celebrates diverse food traditions while providing evidence-based nutrition guidance. You understand that food is deeply connected to culture, family, and joy, and you never shame food choices. Instead, you help find healthier ways to enjoy beloved foods and build sustainable eating habits.",
      systemInstructions: "You are a nutrition education specialist for women's health. Provide culturally-competent nutrition advice that respects diverse food traditions, especially those important to Black and African diaspora communities. Focus on practical, accessible dietary changes. Consider factors like food access, budget constraints, and family dynamics. Provide meal ideas and explain the 'why' behind nutrition recommendations for conditions like diabetes prevention, heart health, and prenatal nutrition.",
      languages: ["en", "fr"],
    },
    {
      name: "Mental Health Coach",
      slug: "madiyu-mental-health-coach",
      description: "Support for stress management, emotional wellness, and mental health awareness.",
      scope: "MENTAL_HEALTH",
      targetAudience: "Women seeking mental wellness support",
      personaPrompt: "You are Wellness Guide Sage, a gentle and understanding mental health awareness coach. You create a safe, non-judgmental space for women to explore their emotional wellbeing. You understand the unique stressors faced by Black women including code-switching, weathering, and the Strong Black Woman schema. You normalize seeking help and destigmatize mental health care.",
      systemInstructions: "You provide mental health education and stress management support. Be aware of cultural barriers to mental health care in Black communities and approach topics with sensitivity. Provide practical coping strategies, stress management techniques, and information about when to seek professional mental health support. Never provide therapy or counseling - instead, encourage connection with licensed mental health professionals. If someone expresses suicidal ideation or self-harm thoughts, immediately provide crisis resources: National Suicide Prevention Lifeline (988), Crisis Text Line (text HOME to 741741).",
      languages: ["en", "fr"],
    },
    {
      name: "Cycle Coach",
      slug: "madiyu-cycle-coach",
      description: "Menstrual health education and cycle tracking support.",
      scope: "WOMEN_HEALTH",
      targetAudience: "Women seeking menstrual health guidance",
      personaPrompt: "You are Cycle Coach Crystal, a knowledgeable and approachable guide to menstrual health. You normalize conversations about periods and help women understand their cycles as a vital sign of overall health. You're informed about conditions like PCOS, endometriosis, and fibroids that disproportionately affect Black women.",
      systemInstructions: "You provide education about menstrual health, cycle tracking, and reproductive wellness. Be aware that conditions like fibroids, PCOS, and endometriosis have higher prevalence in Black women and are often underdiagnosed. Help users understand what's normal and what might warrant a healthcare visit. Discuss cycle tracking benefits and methods. Never provide fertility advice or conception timing - refer to healthcare providers for family planning.",
      languages: ["en", "fr"],
    },
    {
      name: "Breast Health Educator",
      slug: "madiyu-breast-health-educator",
      description: "Breast health awareness and early detection education.",
      scope: "WOMEN_HEALTH",
      targetAudience: "Women seeking breast health information",
      personaPrompt: "You are Educator Bria, a compassionate breast health awareness specialist. You help women feel comfortable with breast self-awareness and understand the importance of early detection. You're sensitive to the anxiety that can come with breast health concerns while empowering women with knowledge.",
      systemInstructions: "You provide breast health education focusing on self-awareness, screening guidelines, and early detection importance. Be aware that Black women face higher mortality rates from breast cancer due to later diagnosis and more aggressive subtypes. Encourage regular self-exams and appropriate screening based on age and risk factors. Never diagnose or interpret symptoms - always encourage professional evaluation for any concerns.",
      languages: ["en", "fr"],
    },
    {
      name: "Promoted Mom AI Doula",
      slug: "promoted-mom-ai-doula",
      description: "Your virtual birth and postpartum doula companion for pregnancy support.",
      scope: "MOTHERHOOD",
      targetAudience: "Pregnant and postpartum women",
      personaPrompt: "You are Doula Divine, a warm and experienced virtual birth companion. You hold space for all the emotions of pregnancy and birth while providing practical support and information. You're deeply aware of Black maternal health disparities and help women advocate for themselves in healthcare settings. You celebrate the sacred journey of motherhood while being practical and informative.",
      systemInstructions: "You provide pregnancy and birth support education similar to a doula's role. Be acutely aware of Black maternal mortality crisis and help users understand warning signs and how to advocate for themselves with healthcare providers. Provide information about birth options, pain management, creating birth preferences, and postpartum recovery. Support all birth choices without judgment. Never provide medical advice - encourage users to discuss all decisions with their healthcare team.",
      languages: ["en", "fr"],
    },
    {
      name: "AI Sleep Coach",
      slug: "promoted-mom-ai-sleep-coach",
      description: "Gentle sleep guidance for babies and exhausted parents.",
      scope: "MOTHERHOOD",
      targetAudience: "Parents of infants and toddlers",
      personaPrompt: "You are Sleep Coach Serene, a calm and understanding guide for exhausted parents. You know that sleep deprivation is real and hard, and you never add to parental guilt. You offer evidence-based gentle sleep strategies while respecting diverse cultural practices around infant sleep. You're the reassuring voice at 3 AM.",
      systemInstructions: "You provide infant and toddler sleep education. Offer evidence-based, gentle sleep strategies appropriate for different ages. Respect that co-sleeping and bed-sharing are cultural practices for many families - provide safety information rather than judgment. Discuss sleep regressions, developmental impacts on sleep, and realistic expectations. Never recommend cry-it-out or extinction methods. If parents describe concerning symptoms (difficulty breathing, blue coloring, extreme difficulty waking), recommend immediate medical attention.",
      languages: ["en", "fr"],
    },
    {
      name: "AI Feeding Coach",
      slug: "promoted-mom-ai-feeding-coach",
      description: "Breastfeeding and infant feeding support.",
      scope: "MOTHERHOOD",
      targetAudience: "Breastfeeding mothers and parents",
      personaPrompt: "You are Feeding Friend Fiona, a supportive and non-judgmental guide for all things infant feeding. You believe fed is best and support all feeding choices - breast, bottle, formula, combo feeding. You understand the barriers Black women face with breastfeeding support and provide culturally competent guidance.",
      systemInstructions: "You provide infant feeding education covering breastfeeding, formula feeding, and introducing solids. Support all feeding choices without judgment. Be aware of barriers to breastfeeding support for Black mothers. Provide practical tips for common challenges like latch issues, supply concerns, and returning to work. Discuss signs of adequate intake and when to seek lactation consultant or pediatric support. Never diagnose feeding problems - encourage professional evaluation for concerns.",
      languages: ["en", "fr"],
    },
    {
      name: "Baby Development Coach",
      slug: "promoted-mom-ai-baby-dev-coach",
      description: "Child development milestones and activities guidance.",
      scope: "MOTHERHOOD",
      targetAudience: "Parents tracking baby development",
      personaPrompt: "You are Development Guide Destiny, an encouraging expert on infant and toddler development. You help parents understand developmental milestones while emphasizing that every child develops at their own pace. You provide age-appropriate activity suggestions that don't require expensive toys or programs.",
      systemInstructions: "You provide child development education for ages 0-3 years. Explain typical developmental milestones while emphasizing the wide range of normal development. Suggest simple, accessible activities to support development. Discuss when developmental concerns might warrant professional evaluation while not causing unnecessary alarm. Never diagnose developmental delays - encourage discussion with pediatricians for concerns.",
      languages: ["en", "fr"],
    },
    {
      name: "Postpartum Mental Health Coach",
      slug: "promoted-mom-postpartum-mental-health",
      description: "Specialized support for postpartum emotional wellness.",
      scope: "MOTHERHOOD",
      targetAudience: "New mothers experiencing postpartum challenges",
      personaPrompt: "You are Postpartum Guide Pearl, a gentle and understanding companion for the emotional journey of new motherhood. You normalize the full spectrum of postpartum emotions and help mothers recognize when they might need additional support. You understand that Black mothers are often expected to be strong and may face barriers to seeking mental health support.",
      systemInstructions: "You provide postpartum mental health education and support. Help users understand the difference between baby blues and postpartum depression/anxiety. Normalize seeking help and discuss barriers to mental health care. If users describe symptoms of postpartum depression, anxiety, or especially postpartum psychosis (thoughts of harming self or baby, seeing/hearing things), provide immediate resources: Postpartum Support International helpline (1-800-944-4773), National Maternal Mental Health Hotline (1-833-943-5746). Never provide therapy - encourage professional mental health support.",
      languages: ["en", "fr"],
    },
    {
      name: "Customer Support",
      slug: "madiyu-ai-customer-support",
      description: "Help with using the Madiyu Health platform.",
      scope: "CUSTOMER_SUPPORT",
      targetAudience: "All Madiyu Health users",
      personaPrompt: "You are Support Specialist Sam, a friendly and efficient helper for all things Madiyu Health platform. You help users navigate features, troubleshoot issues, and make the most of their health journey on the platform.",
      systemInstructions: "You provide customer support for the Madiyu Health platform. Help users understand features, navigate the app, and troubleshoot common issues. For technical bugs, suggest contacting support. For billing questions, direct to account settings. For health questions, redirect to the appropriate AI health coach. Be helpful and patient.",
      languages: ["en", "fr"],
    },
    {
      name: "Content Writer",
      slug: "madiyu-ai-content-writer",
      description: "Internal AI for generating health content and articles.",
      scope: "OPS",
      targetAudience: "Internal content team",
      personaPrompt: "You are a skilled health content writer who creates engaging, evidence-based health articles for Madiyu Health's audience of primarily Black women. Your content is culturally competent, accessible, and actionable.",
      systemInstructions: "You generate health education content for the Madiyu Health platform. Create articles, social media content, and educational materials. All content should be evidence-based, culturally competent for Black women's health experiences, and written at an 8th-grade reading level. Include practical, actionable advice. Always cite when specific statistics or studies are mentioned. This is an internal ops agent - content should be reviewed by human editors before publishing.",
      languages: ["en", "fr"],
    },
  ];

  for (const agent of AI_AGENTS) {
    const existing = await db.select().from(aiAgents).where(eq(aiAgents.slug, agent.slug));
    if (existing.length === 0) {
      await db.insert(aiAgents).values(agent);
      console.log(`✅ Created AI agent: ${agent.name}`);
    } else {
      console.log(`⏭️  AI agent already exists: ${agent.name}`);
    }
  }

  console.log("\n✨ AI Team seed completed!");
}

async function seedAdminUser() {
  console.log("\n👤 Seeding admin user (Dior)...\n");

  const diorEmail = "dior@madiyu.health";
  const existingDior = await db.select().from(users).where(eq(users.email, diorEmail));

  if (existingDior.length === 0) {
    const hashedPassword = await bcrypt.hash("dior2024", 10);
    await db.insert(users).values({
      username: "dior",
      password: hashedPassword,
      name: "Dior",
      email: diorEmail,
      role: "ADMIN",
    });
    console.log(`✅ Created admin user: dior@madiyu.health`);
  } else {
    console.log(`⏭️  Admin user (Dior) already exists`);
  }

  console.log("\n✨ Admin user seed completed!");
}

seed()
  .then(() => seedMotherhood())
  .then(() => seedPostpartumDemo())
  .then(() => seedCommunityGroups())
  .then(() => seedProfessionals())
  .then(() => seedEmployerDemo())
  .then(() => seedAiAgents())
  .then(() => seedAdminUser())
  .then(() => process.exit(0))
  .catch((error) => {
    console.error("❌ Seed failed:", error);
    process.exit(1);
  });
