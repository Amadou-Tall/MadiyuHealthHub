import { 
  users, type User, type InsertUser,
  healthProfiles, type HealthProfile, type InsertHealthProfile,
  programs, type Program, type InsertProgram,
  programModules, type ProgramModule, type InsertProgramModule,
  healthLogs, type HealthLog, type InsertHealthLog,
  motherhoodProfiles, type MotherhoodProfile, type InsertMotherhoodProfile,
  birthPlans, type BirthPlan, type InsertBirthPlan,
  babyProfiles, type BabyProfile, type InsertBabyProfile,
  babyLogs, type BabyLog, type InsertBabyLog,
  assessmentQuestions, type AssessmentQuestion, type InsertAssessmentQuestion,
  communityGroups, type CommunityGroup, type InsertCommunityGroup,
  communityPosts, type CommunityPost, type InsertCommunityPost,
  communityReplies, type CommunityReply, type InsertCommunityReply,
  professionalProfiles, type ProfessionalProfile, type InsertProfessionalProfile,
  bookingSlots, type BookingSlot, type InsertBookingSlot,
  bookings, type Booking, type InsertBooking,
  organizations, type Organization, type InsertOrganization,
  orgMemberships, type OrgMembership, type InsertOrgMembership,
  userProgramEnrollments, type UserProgramEnrollment, type InsertUserProgramEnrollment,
  aiAgents, type AiAgent, type InsertAiAgent,
  aiTasks, type AiTask, type InsertAiTask,
  aiMessages, type AiMessage, type InsertAiMessage,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, gte, sql, ilike, or } from "drizzle-orm";

export interface IStorage {
  // Users
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getAllUsers(): Promise<Omit<User, 'password'>[]>;

  // Health Profiles
  getHealthProfile(userId: string): Promise<HealthProfile | undefined>;
  upsertHealthProfile(profile: InsertHealthProfile): Promise<HealthProfile>;

  // Programs
  getPrograms(activeOnly?: boolean): Promise<Program[]>;
  getProgram(id: number): Promise<Program | undefined>;
  getProgramWithModules(id: number): Promise<{ program: Program; modules: ProgramModule[] } | undefined>;
  createProgram(program: InsertProgram): Promise<Program>;
  getProgramModules(programId: number): Promise<ProgramModule[]>;
  createProgramModule(module: InsertProgramModule): Promise<ProgramModule>;
  getRecommendedPrograms(riskScore: number): Promise<Program[]>;

  // Health Logs
  getHealthLogs(userId: string, limit?: number, offset?: number): Promise<HealthLog[]>;
  createHealthLog(log: InsertHealthLog): Promise<HealthLog>;

  // Motherhood Profiles
  getMotherhoodProfile(userId: string): Promise<MotherhoodProfile | undefined>;
  upsertMotherhoodProfile(profile: InsertMotherhoodProfile): Promise<MotherhoodProfile>;

  // Birth Plans
  getBirthPlan(userId: string): Promise<BirthPlan | undefined>;
  upsertBirthPlan(plan: InsertBirthPlan): Promise<BirthPlan>;

  // Baby Profiles
  getBabyProfiles(userId: string): Promise<BabyProfile[]>;
  getBabyProfile(babyId: number): Promise<BabyProfile | undefined>;
  createBabyProfile(profile: InsertBabyProfile): Promise<BabyProfile>;

  // Baby Logs
  getBabyLogs(babyId: number, limit?: number, offset?: number): Promise<BabyLog[]>;
  createBabyLog(log: InsertBabyLog): Promise<BabyLog>;

  // Assessment Questions
  getAssessmentQuestions(): Promise<AssessmentQuestion[]>;
  createAssessmentQuestion(question: InsertAssessmentQuestion): Promise<AssessmentQuestion>;

  // Community Groups
  getCommunityGroups(): Promise<CommunityGroup[]>;
  getCommunityGroupBySlug(slug: string): Promise<CommunityGroup | undefined>;
  createCommunityGroup(group: InsertCommunityGroup): Promise<CommunityGroup>;

  // Community Posts
  getCommunityPosts(groupId: number): Promise<(CommunityPost & { author: { name: string | null; username: string } })[]>;
  getCommunityPost(postId: number): Promise<CommunityPost | undefined>;
  createCommunityPost(post: InsertCommunityPost): Promise<CommunityPost>;

  // Community Replies
  getCommunityReplies(postId: number): Promise<(CommunityReply & { author: { name: string | null; username: string } })[]>;
  createCommunityReply(reply: InsertCommunityReply): Promise<CommunityReply>;

  // Professional Profiles
  getProfessionalProfiles(filters?: { professionType?: string; search?: string }): Promise<(ProfessionalProfile & { user: { name: string | null } })[]>;
  getProfessionalProfile(id: number): Promise<(ProfessionalProfile & { user: { name: string | null } }) | undefined>;
  getProfessionalProfileByUserId(userId: string): Promise<ProfessionalProfile | undefined>;
  upsertProfessionalProfile(profile: InsertProfessionalProfile): Promise<ProfessionalProfile>;

  // Booking Slots
  getBookingSlots(professionalId: number, availableOnly?: boolean): Promise<BookingSlot[]>;
  createBookingSlot(slot: InsertBookingSlot): Promise<BookingSlot>;
  updateBookingSlotBooked(slotId: number, isBooked: boolean): Promise<BookingSlot | undefined>;

  // Bookings
  createBooking(booking: InsertBooking): Promise<Booking>;
  getBookingsForUser(userId: string): Promise<(Booking & { professional: ProfessionalProfile; slot: BookingSlot })[]>;
  getBookingsForProfessional(professionalId: number): Promise<(Booking & { user: { name: string | null; username: string }; slot: BookingSlot })[]>;
  updateBookingStatus(bookingId: number, status: string): Promise<Booking | undefined>;

  // Organizations
  getOrganizationByOwner(userId: string): Promise<Organization | undefined>;
  upsertOrganization(org: InsertOrganization): Promise<Organization>;
  getOrgMemberCount(orgId: number): Promise<number>;
  getOrgRiskDistribution(orgId: number): Promise<{ riskLevel: string; count: number }[]>;
  getOrgProgramEnrollments(orgId: number): Promise<{ programId: number; title: string; count: number }[]>;
  addOrgMember(membership: InsertOrgMembership): Promise<OrgMembership>;
  getOrgMembers(orgId: number): Promise<OrgMembership[]>;

  // Program Enrollments
  enrollUserInProgram(enrollment: InsertUserProgramEnrollment): Promise<UserProgramEnrollment>;
  getUserEnrollments(userId: string): Promise<UserProgramEnrollment[]>;

  // AI Agents
  getAiAgents(activeOnly?: boolean): Promise<AiAgent[]>;
  getAiAgent(id: number): Promise<AiAgent | undefined>;
  getAiAgentBySlug(slug: string): Promise<AiAgent | undefined>;
  createAiAgent(agent: InsertAiAgent): Promise<AiAgent>;
  updateAiAgent(id: number, agent: Partial<InsertAiAgent>): Promise<AiAgent | undefined>;
  deleteAiAgent(id: number): Promise<boolean>;

  // AI Tasks
  getAiTasks(limit?: number): Promise<(AiTask & { agent: AiAgent })[]>;
  getAiTask(id: number): Promise<AiTask | undefined>;
  createAiTask(task: InsertAiTask): Promise<AiTask>;
  updateAiTask(id: number, update: Partial<InsertAiTask>): Promise<AiTask | undefined>;

  // AI Messages (Chat History)
  getAiMessages(userId: string, agentId: number, conversationId: string): Promise<AiMessage[]>;
  createAiMessage(message: InsertAiMessage): Promise<AiMessage>;
}

export class DatabaseStorage implements IStorage {
  // ========== USERS ==========
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async getAllUsers(): Promise<Omit<User, 'password'>[]> {
    const allUsers = await db.select({
      id: users.id,
      username: users.username,
      name: users.name,
      email: users.email,
      role: users.role,
      preferredLanguage: users.preferredLanguage,
      createdAt: users.createdAt,
    }).from(users).orderBy(desc(users.createdAt));
    return allUsers;
  }

  // ========== HEALTH PROFILES ==========
  async getHealthProfile(userId: string): Promise<HealthProfile | undefined> {
    const [profile] = await db.select().from(healthProfiles).where(eq(healthProfiles.userId, userId));
    return profile || undefined;
  }

  async upsertHealthProfile(profile: InsertHealthProfile): Promise<HealthProfile> {
    const existing = await this.getHealthProfile(profile.userId);
    
    const updateData = {
      dateOfBirth: profile.dateOfBirth,
      height: profile.height,
      weight: profile.weight,
      bmi: profile.bmi,
      bloodPressure: profile.bloodPressure,
      familyHistory: profile.familyHistory as string[] | undefined,
      lifestyle: profile.lifestyle as string[] | undefined,
      conditions: profile.conditions as string[] | undefined,
      riskScore: profile.riskScore,
      riskLevel: profile.riskLevel,
      updatedAt: new Date(),
    };
    
    if (existing) {
      const [updated] = await db
        .update(healthProfiles)
        .set(updateData)
        .where(eq(healthProfiles.userId, profile.userId))
        .returning();
      return updated;
    } else {
      const [created] = await db
        .insert(healthProfiles)
        .values({
          userId: profile.userId,
          ...updateData,
        })
        .returning();
      return created;
    }
  }

  // ========== PROGRAMS ==========
  async getPrograms(activeOnly = true): Promise<Program[]> {
    if (activeOnly) {
      return db.select().from(programs).where(eq(programs.isActive, true));
    }
    return db.select().from(programs);
  }

  async getProgram(id: number): Promise<Program | undefined> {
    const [program] = await db.select().from(programs).where(eq(programs.id, id));
    return program || undefined;
  }

  async getProgramWithModules(id: number): Promise<{ program: Program; modules: ProgramModule[] } | undefined> {
    const program = await this.getProgram(id);
    if (!program) return undefined;
    const modules = await this.getProgramModules(id);
    return { program, modules };
  }

  async createProgram(program: InsertProgram): Promise<Program> {
    const [created] = await db.insert(programs).values(program).returning();
    return created;
  }

  async getProgramModules(programId: number): Promise<ProgramModule[]> {
    return db
      .select()
      .from(programModules)
      .where(eq(programModules.programId, programId))
      .orderBy(programModules.orderIndex);
  }

  async createProgramModule(module: InsertProgramModule): Promise<ProgramModule> {
    const [created] = await db.insert(programModules).values(module).returning();
    return created;
  }

  async getRecommendedPrograms(riskScore: number): Promise<Program[]> {
    if (riskScore >= 50) {
      return db
        .select()
        .from(programs)
        .where(and(eq(programs.isActive, true), eq(programs.category, "Chronic Disease")));
    }
    return db.select().from(programs).where(eq(programs.isActive, true)).limit(4);
  }

  // ========== HEALTH LOGS ==========
  async getHealthLogs(userId: string, limit = 50, offset = 0): Promise<HealthLog[]> {
    return db
      .select()
      .from(healthLogs)
      .where(eq(healthLogs.userId, userId))
      .orderBy(desc(healthLogs.dateTime))
      .limit(limit)
      .offset(offset);
  }

  async createHealthLog(log: InsertHealthLog): Promise<HealthLog> {
    const [created] = await db.insert(healthLogs).values(log).returning();
    return created;
  }

  // ========== MOTHERHOOD PROFILES ==========
  async getMotherhoodProfile(userId: string): Promise<MotherhoodProfile | undefined> {
    const [profile] = await db.select().from(motherhoodProfiles).where(eq(motherhoodProfiles.userId, userId));
    return profile || undefined;
  }

  async upsertMotherhoodProfile(profile: InsertMotherhoodProfile): Promise<MotherhoodProfile> {
    const existing = await this.getMotherhoodProfile(profile.userId);
    if (existing) {
      const [updated] = await db
        .update(motherhoodProfiles)
        .set({
          status: profile.status,
          weeksPregnant: profile.weeksPregnant,
          dueDate: profile.dueDate,
          babyDateOfBirth: profile.babyDateOfBirth,
          numberOfChildren: profile.numberOfChildren,
          preferredBirthSetting: profile.preferredBirthSetting,
          notes: profile.notes,
          updatedAt: new Date(),
        })
        .where(eq(motherhoodProfiles.userId, profile.userId))
        .returning();
      return updated;
    } else {
      const [created] = await db
        .insert(motherhoodProfiles)
        .values(profile)
        .returning();
      return created;
    }
  }

  // ========== BIRTH PLANS ==========
  async getBirthPlan(userId: string): Promise<BirthPlan | undefined> {
    const [plan] = await db.select().from(birthPlans).where(eq(birthPlans.userId, userId));
    return plan || undefined;
  }

  async upsertBirthPlan(plan: InsertBirthPlan): Promise<BirthPlan> {
    const existing = await this.getBirthPlan(plan.userId);
    if (existing) {
      const [updated] = await db
        .update(birthPlans)
        .set({
          painManagementPreference: plan.painManagementPreference,
          supportPeople: plan.supportPeople,
          culturalPreferences: plan.culturalPreferences,
          medicalInterventionPreferences: plan.medicalInterventionPreferences,
          extraNotes: plan.extraNotes,
          updatedAt: new Date(),
        })
        .where(eq(birthPlans.userId, plan.userId))
        .returning();
      return updated;
    } else {
      const [created] = await db
        .insert(birthPlans)
        .values(plan)
        .returning();
      return created;
    }
  }

  // ========== BABY PROFILES ==========
  async getBabyProfiles(userId: string): Promise<BabyProfile[]> {
    return db.select().from(babyProfiles).where(eq(babyProfiles.userId, userId));
  }

  async getBabyProfile(babyId: number): Promise<BabyProfile | undefined> {
    const [profile] = await db.select().from(babyProfiles).where(eq(babyProfiles.id, babyId));
    return profile || undefined;
  }

  async createBabyProfile(profile: InsertBabyProfile): Promise<BabyProfile> {
    const [created] = await db.insert(babyProfiles).values(profile).returning();
    return created;
  }

  // ========== BABY LOGS ==========
  async getBabyLogs(babyId: number, limit = 50, offset = 0): Promise<BabyLog[]> {
    return db
      .select()
      .from(babyLogs)
      .where(eq(babyLogs.babyId, babyId))
      .orderBy(desc(babyLogs.dateTime))
      .limit(limit)
      .offset(offset);
  }

  async createBabyLog(log: InsertBabyLog): Promise<BabyLog> {
    const [created] = await db.insert(babyLogs).values(log).returning();
    return created;
  }

  // ========== ASSESSMENT QUESTIONS ==========
  async getAssessmentQuestions(): Promise<AssessmentQuestion[]> {
    return db
      .select()
      .from(assessmentQuestions)
      .where(eq(assessmentQuestions.isActive, true))
      .orderBy(assessmentQuestions.orderIndex);
  }

  async createAssessmentQuestion(question: InsertAssessmentQuestion): Promise<AssessmentQuestion> {
    const [created] = await db.insert(assessmentQuestions).values(question as any).returning();
    return created;
  }

  // ========== COMMUNITY GROUPS ==========
  async getCommunityGroups(): Promise<CommunityGroup[]> {
    return db.select().from(communityGroups).orderBy(communityGroups.name);
  }

  async getCommunityGroupBySlug(slug: string): Promise<CommunityGroup | undefined> {
    const [group] = await db.select().from(communityGroups).where(eq(communityGroups.slug, slug));
    return group || undefined;
  }

  async createCommunityGroup(group: InsertCommunityGroup): Promise<CommunityGroup> {
    const [created] = await db.insert(communityGroups).values(group).returning();
    return created;
  }

  // ========== COMMUNITY POSTS ==========
  async getCommunityPosts(groupId: number): Promise<(CommunityPost & { author: { name: string | null; username: string } })[]> {
    const results = await db
      .select({
        id: communityPosts.id,
        groupId: communityPosts.groupId,
        userId: communityPosts.userId,
        content: communityPosts.content,
        createdAt: communityPosts.createdAt,
        authorName: users.name,
        authorUsername: users.username,
      })
      .from(communityPosts)
      .innerJoin(users, eq(communityPosts.userId, users.id))
      .where(eq(communityPosts.groupId, groupId))
      .orderBy(desc(communityPosts.createdAt));

    return results.map(r => ({
      id: r.id,
      groupId: r.groupId,
      userId: r.userId,
      content: r.content,
      createdAt: r.createdAt,
      author: { name: r.authorName, username: r.authorUsername },
    }));
  }

  async getCommunityPost(postId: number): Promise<CommunityPost | undefined> {
    const [post] = await db.select().from(communityPosts).where(eq(communityPosts.id, postId));
    return post || undefined;
  }

  async createCommunityPost(post: InsertCommunityPost): Promise<CommunityPost> {
    const [created] = await db.insert(communityPosts).values(post).returning();
    return created;
  }

  // ========== COMMUNITY REPLIES ==========
  async getCommunityReplies(postId: number): Promise<(CommunityReply & { author: { name: string | null; username: string } })[]> {
    const results = await db
      .select({
        id: communityReplies.id,
        postId: communityReplies.postId,
        userId: communityReplies.userId,
        content: communityReplies.content,
        createdAt: communityReplies.createdAt,
        authorName: users.name,
        authorUsername: users.username,
      })
      .from(communityReplies)
      .innerJoin(users, eq(communityReplies.userId, users.id))
      .where(eq(communityReplies.postId, postId))
      .orderBy(communityReplies.createdAt);

    return results.map(r => ({
      id: r.id,
      postId: r.postId,
      userId: r.userId,
      content: r.content,
      createdAt: r.createdAt,
      author: { name: r.authorName, username: r.authorUsername },
    }));
  }

  async createCommunityReply(reply: InsertCommunityReply): Promise<CommunityReply> {
    const [created] = await db.insert(communityReplies).values(reply).returning();
    return created;
  }

  // ========== PROFESSIONAL PROFILES ==========
  async getProfessionalProfiles(filters?: { professionType?: string; search?: string }): Promise<(ProfessionalProfile & { user: { name: string | null } })[]> {
    let query = db
      .select({
        id: professionalProfiles.id,
        userId: professionalProfiles.userId,
        professionType: professionalProfiles.professionType,
        bio: professionalProfiles.bio,
        specialties: professionalProfiles.specialties,
        hourlyRate: professionalProfiles.hourlyRate,
        isVerified: professionalProfiles.isVerified,
        location: professionalProfiles.location,
        imageUrl: professionalProfiles.imageUrl,
        yearsExperience: professionalProfiles.yearsExperience,
        createdAt: professionalProfiles.createdAt,
        userName: users.name,
      })
      .from(professionalProfiles)
      .innerJoin(users, eq(professionalProfiles.userId, users.id));

    const results = await query;

    let filtered = results;
    if (filters?.professionType) {
      filtered = filtered.filter(p => p.professionType === filters.professionType);
    }
    if (filters?.search) {
      const searchLower = filters.search.toLowerCase();
      filtered = filtered.filter(p => 
        p.userName?.toLowerCase().includes(searchLower) ||
        p.bio?.toLowerCase().includes(searchLower) ||
        p.location?.toLowerCase().includes(searchLower)
      );
    }

    return filtered.map(r => ({
      id: r.id,
      userId: r.userId,
      professionType: r.professionType,
      bio: r.bio,
      specialties: r.specialties,
      hourlyRate: r.hourlyRate,
      isVerified: r.isVerified,
      location: r.location,
      imageUrl: r.imageUrl,
      yearsExperience: r.yearsExperience,
      createdAt: r.createdAt,
      user: { name: r.userName },
    }));
  }

  async getProfessionalProfile(id: number): Promise<(ProfessionalProfile & { user: { name: string | null } }) | undefined> {
    const [result] = await db
      .select({
        id: professionalProfiles.id,
        userId: professionalProfiles.userId,
        professionType: professionalProfiles.professionType,
        bio: professionalProfiles.bio,
        specialties: professionalProfiles.specialties,
        hourlyRate: professionalProfiles.hourlyRate,
        isVerified: professionalProfiles.isVerified,
        location: professionalProfiles.location,
        imageUrl: professionalProfiles.imageUrl,
        yearsExperience: professionalProfiles.yearsExperience,
        createdAt: professionalProfiles.createdAt,
        userName: users.name,
      })
      .from(professionalProfiles)
      .innerJoin(users, eq(professionalProfiles.userId, users.id))
      .where(eq(professionalProfiles.id, id));

    if (!result) return undefined;

    return {
      id: result.id,
      userId: result.userId,
      professionType: result.professionType,
      bio: result.bio,
      specialties: result.specialties,
      hourlyRate: result.hourlyRate,
      isVerified: result.isVerified,
      location: result.location,
      imageUrl: result.imageUrl,
      yearsExperience: result.yearsExperience,
      createdAt: result.createdAt,
      user: { name: result.userName },
    };
  }

  async getProfessionalProfileByUserId(userId: string): Promise<ProfessionalProfile | undefined> {
    const [profile] = await db.select().from(professionalProfiles).where(eq(professionalProfiles.userId, userId));
    return profile || undefined;
  }

  async upsertProfessionalProfile(profile: InsertProfessionalProfile): Promise<ProfessionalProfile> {
    const existing = await this.getProfessionalProfileByUserId(profile.userId);
    if (existing) {
      const [updated] = await db
        .update(professionalProfiles)
        .set({
          professionType: profile.professionType,
          bio: profile.bio,
          specialties: profile.specialties as string[] | undefined,
          hourlyRate: profile.hourlyRate,
          isVerified: profile.isVerified,
          location: profile.location,
          imageUrl: profile.imageUrl,
          yearsExperience: profile.yearsExperience,
        })
        .where(eq(professionalProfiles.userId, profile.userId))
        .returning();
      return updated;
    } else {
      const [created] = await db.insert(professionalProfiles).values(profile as any).returning();
      return created;
    }
  }

  // ========== BOOKING SLOTS ==========
  async getBookingSlots(professionalId: number, availableOnly = false): Promise<BookingSlot[]> {
    if (availableOnly) {
      return db
        .select()
        .from(bookingSlots)
        .where(and(
          eq(bookingSlots.professionalId, professionalId),
          eq(bookingSlots.isBooked, false),
          gte(bookingSlots.startDateTime, new Date())
        ))
        .orderBy(bookingSlots.startDateTime);
    }
    return db
      .select()
      .from(bookingSlots)
      .where(eq(bookingSlots.professionalId, professionalId))
      .orderBy(bookingSlots.startDateTime);
  }

  async createBookingSlot(slot: InsertBookingSlot): Promise<BookingSlot> {
    const [created] = await db.insert(bookingSlots).values(slot).returning();
    return created;
  }

  async updateBookingSlotBooked(slotId: number, isBooked: boolean): Promise<BookingSlot | undefined> {
    const [updated] = await db
      .update(bookingSlots)
      .set({ isBooked })
      .where(eq(bookingSlots.id, slotId))
      .returning();
    return updated || undefined;
  }

  // ========== BOOKINGS ==========
  async createBooking(booking: InsertBooking): Promise<Booking> {
    const [created] = await db.insert(bookings).values(booking).returning();
    await this.updateBookingSlotBooked(booking.slotId, true);
    return created;
  }

  async getBookingsForUser(userId: string): Promise<(Booking & { professional: ProfessionalProfile; slot: BookingSlot })[]> {
    const results = await db
      .select()
      .from(bookings)
      .innerJoin(professionalProfiles, eq(bookings.professionalId, professionalProfiles.id))
      .innerJoin(bookingSlots, eq(bookings.slotId, bookingSlots.id))
      .where(eq(bookings.userId, userId))
      .orderBy(desc(bookingSlots.startDateTime));

    return results.map(r => ({
      ...r.bookings,
      professional: r.professional_profiles,
      slot: r.booking_slots,
    }));
  }

  async getBookingsForProfessional(professionalId: number): Promise<(Booking & { user: { name: string | null; username: string }; slot: BookingSlot })[]> {
    const results = await db
      .select()
      .from(bookings)
      .innerJoin(users, eq(bookings.userId, users.id))
      .innerJoin(bookingSlots, eq(bookings.slotId, bookingSlots.id))
      .where(eq(bookings.professionalId, professionalId))
      .orderBy(desc(bookingSlots.startDateTime));

    return results.map(r => ({
      ...r.bookings,
      user: { name: r.users.name, username: r.users.username },
      slot: r.booking_slots,
    }));
  }

  async updateBookingStatus(bookingId: number, status: string): Promise<Booking | undefined> {
    const [updated] = await db
      .update(bookings)
      .set({ status })
      .where(eq(bookings.id, bookingId))
      .returning();
    
    if (updated && status === 'CANCELLED') {
      await this.updateBookingSlotBooked(updated.slotId, false);
    }
    
    return updated || undefined;
  }

  // ========== ORGANIZATIONS ==========
  async getOrganizationByOwner(userId: string): Promise<Organization | undefined> {
    const [org] = await db.select().from(organizations).where(eq(organizations.ownerUserId, userId));
    return org || undefined;
  }

  async upsertOrganization(org: InsertOrganization): Promise<Organization> {
    const existing = await this.getOrganizationByOwner(org.ownerUserId);
    if (existing) {
      const [updated] = await db
        .update(organizations)
        .set({
          name: org.name,
          country: org.country,
          industry: org.industry,
        })
        .where(eq(organizations.ownerUserId, org.ownerUserId))
        .returning();
      return updated;
    } else {
      const [created] = await db.insert(organizations).values(org).returning();
      return created;
    }
  }

  async getOrgMemberCount(orgId: number): Promise<number> {
    const result = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(orgMemberships)
      .where(eq(orgMemberships.orgId, orgId));
    return result[0]?.count || 0;
  }

  async getOrgRiskDistribution(orgId: number): Promise<{ riskLevel: string; count: number }[]> {
    const memberUserIds = await db
      .select({ userId: orgMemberships.userId })
      .from(orgMemberships)
      .where(eq(orgMemberships.orgId, orgId));

    if (memberUserIds.length === 0) return [];

    const results = await db
      .select({
        riskLevel: healthProfiles.riskLevel,
        count: sql<number>`count(*)::int`,
      })
      .from(healthProfiles)
      .where(sql`${healthProfiles.userId} IN (${sql.join(memberUserIds.map(m => sql`${m.userId}`), sql`,`)})`)
      .groupBy(healthProfiles.riskLevel);

    return results.map(r => ({
      riskLevel: r.riskLevel || 'UNKNOWN',
      count: r.count,
    }));
  }

  async getOrgProgramEnrollments(orgId: number): Promise<{ programId: number; title: string; count: number }[]> {
    const memberUserIds = await db
      .select({ userId: orgMemberships.userId })
      .from(orgMemberships)
      .where(eq(orgMemberships.orgId, orgId));

    if (memberUserIds.length === 0) return [];

    const results = await db
      .select({
        programId: userProgramEnrollments.programId,
        title: programs.title,
        count: sql<number>`count(*)::int`,
      })
      .from(userProgramEnrollments)
      .innerJoin(programs, eq(userProgramEnrollments.programId, programs.id))
      .where(sql`${userProgramEnrollments.userId} IN (${sql.join(memberUserIds.map(m => sql`${m.userId}`), sql`,`)})`)
      .groupBy(userProgramEnrollments.programId, programs.title);

    return results.map(r => ({
      programId: r.programId,
      title: r.title,
      count: r.count,
    }));
  }

  async addOrgMember(membership: InsertOrgMembership): Promise<OrgMembership> {
    const [created] = await db.insert(orgMemberships).values(membership).returning();
    return created;
  }

  async getOrgMembers(orgId: number): Promise<OrgMembership[]> {
    return db.select().from(orgMemberships).where(eq(orgMemberships.orgId, orgId));
  }

  // ========== PROGRAM ENROLLMENTS ==========
  async enrollUserInProgram(enrollment: InsertUserProgramEnrollment): Promise<UserProgramEnrollment> {
    const [created] = await db.insert(userProgramEnrollments).values(enrollment).returning();
    return created;
  }

  async getUserEnrollments(userId: string): Promise<UserProgramEnrollment[]> {
    return db.select().from(userProgramEnrollments).where(eq(userProgramEnrollments.userId, userId));
  }

  // ========== AI AGENTS ==========
  async getAiAgents(activeOnly: boolean = false): Promise<AiAgent[]> {
    if (activeOnly) {
      return db.select().from(aiAgents).where(eq(aiAgents.isActive, true)).orderBy(aiAgents.name);
    }
    return db.select().from(aiAgents).orderBy(aiAgents.name);
  }

  async getAiAgent(id: number): Promise<AiAgent | undefined> {
    const [agent] = await db.select().from(aiAgents).where(eq(aiAgents.id, id));
    return agent || undefined;
  }

  async getAiAgentBySlug(slug: string): Promise<AiAgent | undefined> {
    const [agent] = await db.select().from(aiAgents).where(eq(aiAgents.slug, slug));
    return agent || undefined;
  }

  async createAiAgent(agent: InsertAiAgent): Promise<AiAgent> {
    const [created] = await db.insert(aiAgents).values(agent).returning();
    return created;
  }

  async updateAiAgent(id: number, agent: Partial<InsertAiAgent>): Promise<AiAgent | undefined> {
    const [updated] = await db
      .update(aiAgents)
      .set({ ...agent, updatedAt: new Date() })
      .where(eq(aiAgents.id, id))
      .returning();
    return updated || undefined;
  }

  async deleteAiAgent(id: number): Promise<boolean> {
    const result = await db.delete(aiAgents).where(eq(aiAgents.id, id));
    return true;
  }

  // ========== AI TASKS ==========
  async getAiTasks(limit: number = 50): Promise<(AiTask & { agent: AiAgent })[]> {
    const tasks = await db
      .select()
      .from(aiTasks)
      .innerJoin(aiAgents, eq(aiTasks.agentId, aiAgents.id))
      .orderBy(desc(aiTasks.createdAt))
      .limit(limit);

    return tasks.map(row => ({
      ...row.ai_tasks,
      agent: row.ai_agents,
    }));
  }

  async getAiTask(id: number): Promise<AiTask | undefined> {
    const [task] = await db.select().from(aiTasks).where(eq(aiTasks.id, id));
    return task || undefined;
  }

  async createAiTask(task: InsertAiTask): Promise<AiTask> {
    const [created] = await db.insert(aiTasks).values(task).returning();
    return created;
  }

  async updateAiTask(id: number, update: Partial<InsertAiTask>): Promise<AiTask | undefined> {
    const [updated] = await db
      .update(aiTasks)
      .set({ ...update, updatedAt: new Date() })
      .where(eq(aiTasks.id, id))
      .returning();
    return updated || undefined;
  }

  // ========== AI MESSAGES ==========
  async getAiMessages(userId: string, agentId: number, conversationId: string): Promise<AiMessage[]> {
    return db
      .select()
      .from(aiMessages)
      .where(
        and(
          eq(aiMessages.userId, userId),
          eq(aiMessages.agentId, agentId),
          eq(aiMessages.conversationId, conversationId)
        )
      )
      .orderBy(aiMessages.createdAt);
  }

  async createAiMessage(message: InsertAiMessage): Promise<AiMessage> {
    const [created] = await db.insert(aiMessages).values(message).returning();
    return created;
  }
}

export const storage = new DatabaseStorage();
