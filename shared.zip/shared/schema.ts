import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, integer, real, json, date, boolean, serial } from "drizzle-orm/pg-core";
import { createInsertSchema, createSelectSchema } from "drizzle-zod";
import { z } from "zod";

// ============================================================================
// USERS TABLE
// ============================================================================
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  name: text("name"),
  email: text("email"),
  role: text("role").notNull().default("USER"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
}).extend({
  username: z.string().min(3).max(50),
  password: z.string().min(6),
  name: z.string().optional(),
  email: z.string().email().optional(),
});

export const selectUserSchema = createSelectSchema(users).omit({
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type UserProfile = z.infer<typeof selectUserSchema>;

// ============================================================================
// HEALTH PROFILES TABLE
// ============================================================================
export const healthProfiles = pgTable("health_profiles", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  dateOfBirth: date("date_of_birth"),
  height: real("height"), // cm
  weight: real("weight"), // kg
  bmi: real("bmi"),
  bloodPressure: text("blood_pressure"),
  familyHistory: json("family_history").$type<string[]>().default([]),
  lifestyle: json("lifestyle").$type<string[]>().default([]),
  conditions: json("conditions").$type<string[]>().default([]),
  riskScore: integer("risk_score").default(0),
  riskLevel: text("risk_level").default("LOW"), // LOW | MODERATE | HIGH
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertHealthProfileSchema = createInsertSchema(healthProfiles).omit({
  id: true,
  updatedAt: true,
});

export type InsertHealthProfile = z.infer<typeof insertHealthProfileSchema>;
export type HealthProfile = typeof healthProfiles.$inferSelect;

// ============================================================================
// PROGRAMS TABLE
// ============================================================================
export const programs = pgTable("programs", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  category: text("category").notNull(), // Prenatal | Postnatal | Fitness | Chronic Disease | Women's Health | Mental Health
  imageUrl: text("image_url"),
  duration: text("duration"), // e.g., "4 weeks"
  level: text("level").default("All Levels"), // Beginner | Intermediate | Advanced | All Levels
  isActive: boolean("is_active").default(true),
  targetRole: text("target_role").default("USER"), // Which role can access
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertProgramSchema = createInsertSchema(programs).omit({
  id: true,
  createdAt: true,
});

export type InsertProgram = z.infer<typeof insertProgramSchema>;
export type Program = typeof programs.$inferSelect;

// ============================================================================
// PROGRAM MODULES TABLE
// ============================================================================
export const programModules = pgTable("program_modules", {
  id: serial("id").primaryKey(),
  programId: integer("program_id").notNull().references(() => programs.id),
  title: text("title").notNull(),
  contentMarkdown: text("content_markdown").notNull(),
  durationMinutes: integer("duration_minutes").default(15),
  orderIndex: integer("order_index").default(0),
});

export const insertProgramModuleSchema = createInsertSchema(programModules).omit({
  id: true,
});

export type InsertProgramModule = z.infer<typeof insertProgramModuleSchema>;
export type ProgramModule = typeof programModules.$inferSelect;

// ============================================================================
// HEALTH LOGS TABLE
// ============================================================================
export const healthLogs = pgTable("health_logs", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  dateTime: timestamp("date_time").defaultNow().notNull(),
  type: text("type").notNull(), // BP | Glucose | Mood | Weight | Sleep
  valueNumber: real("value_number"),
  valueText: text("value_text"),
  unit: text("unit"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertHealthLogSchema = createInsertSchema(healthLogs).omit({
  id: true,
  createdAt: true,
});

export type InsertHealthLog = z.infer<typeof insertHealthLogSchema>;
export type HealthLog = typeof healthLogs.$inferSelect;

// ============================================================================
// MOTHERHOOD PROFILES TABLE
// ============================================================================
export const motherhoodProfiles = pgTable("motherhood_profiles", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id).unique(),
  status: text("status").notNull().default("NONE"), // PLANNING | PREGNANT | POSTPARTUM | NONE
  weeksPregnant: integer("weeks_pregnant"),
  dueDate: date("due_date"),
  babyDateOfBirth: date("baby_date_of_birth"),
  numberOfChildren: integer("number_of_children").default(0),
  preferredBirthSetting: text("preferred_birth_setting"), // HOSPITAL | BIRTH_CENTER | HOME
  notes: text("notes"),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertMotherhoodProfileSchema = createInsertSchema(motherhoodProfiles).omit({
  id: true,
  updatedAt: true,
});

export type InsertMotherhoodProfile = z.infer<typeof insertMotherhoodProfileSchema>;
export type MotherhoodProfile = typeof motherhoodProfiles.$inferSelect;

// ============================================================================
// BIRTH PLANS TABLE
// ============================================================================
export const birthPlans = pgTable("birth_plans", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id).unique(),
  painManagementPreference: text("pain_management_preference"),
  supportPeople: text("support_people"),
  culturalPreferences: text("cultural_preferences"),
  medicalInterventionPreferences: text("medical_intervention_preferences"),
  extraNotes: text("extra_notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertBirthPlanSchema = createInsertSchema(birthPlans).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertBirthPlan = z.infer<typeof insertBirthPlanSchema>;
export type BirthPlan = typeof birthPlans.$inferSelect;

// ============================================================================
// BABY PROFILES TABLE
// ============================================================================
export const babyProfiles = pgTable("baby_profiles", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  name: text("name").notNull(),
  dateOfBirth: date("date_of_birth").notNull(),
  sex: text("sex").notNull(), // Male | Female | Other
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertBabyProfileSchema = createInsertSchema(babyProfiles).omit({
  id: true,
  createdAt: true,
});

export type InsertBabyProfile = z.infer<typeof insertBabyProfileSchema>;
export type BabyProfile = typeof babyProfiles.$inferSelect;

// ============================================================================
// BABY LOGS TABLE
// ============================================================================
export const babyLogs = pgTable("baby_logs", {
  id: serial("id").primaryKey(),
  babyId: integer("baby_id").notNull().references(() => babyProfiles.id),
  dateTime: timestamp("date_time").defaultNow().notNull(),
  type: text("type").notNull(), // SLEEP | FEEDING | DIAPER | MILESTONE | HEALTH_NOTE
  valueNumber: real("value_number"),
  valueText: text("value_text"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertBabyLogSchema = createInsertSchema(babyLogs).omit({
  id: true,
  createdAt: true,
});

export type InsertBabyLog = z.infer<typeof insertBabyLogSchema>;
export type BabyLog = typeof babyLogs.$inferSelect;

// ============================================================================
// ASSESSMENT QUESTIONS TABLE
// ============================================================================
export const assessmentQuestions = pgTable("assessment_questions", {
  id: serial("id").primaryKey(),
  question: text("question").notNull(),
  category: text("category").notNull(), // Lifestyle | MedicalHistory | FamilyHistory | Demographics
  fieldKey: text("field_key").notNull(), // For mapping to health profile fields
  type: text("type").notNull().default("select"), // select | number | multiselect | text
  options: json("options").$type<{ value: string; label: string }[]>(),
  orderIndex: integer("order_index").default(0),
  isActive: boolean("is_active").default(true),
});

export const insertAssessmentQuestionSchema = createInsertSchema(assessmentQuestions).omit({
  id: true,
});

export type InsertAssessmentQuestion = z.infer<typeof insertAssessmentQuestionSchema>;
export type AssessmentQuestion = typeof assessmentQuestions.$inferSelect;

// ============================================================================
// COMMUNITY GROUPS TABLE
// ============================================================================
export const communityGroups = pgTable("community_groups", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  slug: text("slug").notNull().unique(),
  audienceType: text("audience_type").notNull().default("ALL"), // ALL | PREGNANT | POSTPARTUM | CHRONIC
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertCommunityGroupSchema = createInsertSchema(communityGroups).omit({
  id: true,
  createdAt: true,
});

export type InsertCommunityGroup = z.infer<typeof insertCommunityGroupSchema>;
export type CommunityGroup = typeof communityGroups.$inferSelect;

// ============================================================================
// COMMUNITY POSTS TABLE
// ============================================================================
export const communityPosts = pgTable("community_posts", {
  id: serial("id").primaryKey(),
  groupId: integer("group_id").notNull().references(() => communityGroups.id),
  userId: varchar("user_id").notNull().references(() => users.id),
  content: text("content").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertCommunityPostSchema = createInsertSchema(communityPosts).omit({
  id: true,
  createdAt: true,
});

export type InsertCommunityPost = z.infer<typeof insertCommunityPostSchema>;
export type CommunityPost = typeof communityPosts.$inferSelect;

// ============================================================================
// COMMUNITY REPLIES TABLE
// ============================================================================
export const communityReplies = pgTable("community_replies", {
  id: serial("id").primaryKey(),
  postId: integer("post_id").notNull().references(() => communityPosts.id),
  userId: varchar("user_id").notNull().references(() => users.id),
  content: text("content").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertCommunityReplySchema = createInsertSchema(communityReplies).omit({
  id: true,
  createdAt: true,
});

export type InsertCommunityReply = z.infer<typeof insertCommunityReplySchema>;
export type CommunityReply = typeof communityReplies.$inferSelect;

// ============================================================================
// PROFESSIONAL PROFILES TABLE
// ============================================================================
export const professionalProfiles = pgTable("professional_profiles", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id).unique(),
  professionType: text("profession_type").notNull(), // NUTRITIONIST | DOULA | COACH | THERAPIST | LACTATION_CONSULTANT
  bio: text("bio"),
  specialties: json("specialties").$type<string[]>().default([]),
  hourlyRate: real("hourly_rate"),
  isVerified: boolean("is_verified").default(false),
  location: text("location"),
  imageUrl: text("image_url"),
  yearsExperience: integer("years_experience"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertProfessionalProfileSchema = createInsertSchema(professionalProfiles).omit({
  id: true,
  createdAt: true,
});

export type InsertProfessionalProfile = z.infer<typeof insertProfessionalProfileSchema>;
export type ProfessionalProfile = typeof professionalProfiles.$inferSelect;

// ============================================================================
// BOOKING SLOTS TABLE
// ============================================================================
export const bookingSlots = pgTable("booking_slots", {
  id: serial("id").primaryKey(),
  professionalId: integer("professional_id").notNull().references(() => professionalProfiles.id),
  startDateTime: timestamp("start_date_time").notNull(),
  endDateTime: timestamp("end_date_time").notNull(),
  isBooked: boolean("is_booked").default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertBookingSlotSchema = createInsertSchema(bookingSlots).omit({
  id: true,
  createdAt: true,
});

export type InsertBookingSlot = z.infer<typeof insertBookingSlotSchema>;
export type BookingSlot = typeof bookingSlots.$inferSelect;

// ============================================================================
// BOOKINGS TABLE
// ============================================================================
export const bookings = pgTable("bookings", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  professionalId: integer("professional_id").notNull().references(() => professionalProfiles.id),
  slotId: integer("slot_id").notNull().references(() => bookingSlots.id),
  status: text("status").notNull().default("PENDING"), // PENDING | CONFIRMED | CANCELLED | COMPLETED
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertBookingSchema = createInsertSchema(bookings).omit({
  id: true,
  createdAt: true,
});

export type InsertBooking = z.infer<typeof insertBookingSchema>;
export type Booking = typeof bookings.$inferSelect;

// ============================================================================
// ORGANIZATIONS TABLE (for Employers)
// ============================================================================
export const organizations = pgTable("organizations", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  country: text("country"),
  industry: text("industry"),
  ownerUserId: varchar("owner_user_id").notNull().references(() => users.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertOrganizationSchema = createInsertSchema(organizations).omit({
  id: true,
  createdAt: true,
});

export type InsertOrganization = z.infer<typeof insertOrganizationSchema>;
export type Organization = typeof organizations.$inferSelect;

// ============================================================================
// ORG MEMBERSHIPS TABLE
// ============================================================================
export const orgMemberships = pgTable("org_memberships", {
  id: serial("id").primaryKey(),
  orgId: integer("org_id").notNull().references(() => organizations.id),
  userId: varchar("user_id").notNull().references(() => users.id),
  role: text("role").notNull().default("MEMBER"), // MEMBER | MANAGER
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertOrgMembershipSchema = createInsertSchema(orgMemberships).omit({
  id: true,
  createdAt: true,
});

export type InsertOrgMembership = z.infer<typeof insertOrgMembershipSchema>;
export type OrgMembership = typeof orgMemberships.$inferSelect;

// ============================================================================
// USER PROGRAM ENROLLMENTS TABLE
// ============================================================================
export const userProgramEnrollments = pgTable("user_program_enrollments", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  programId: integer("program_id").notNull().references(() => programs.id),
  status: text("status").notNull().default("ACTIVE"), // ACTIVE | COMPLETED | DROPPED
  progress: integer("progress").default(0), // Percentage
  enrolledAt: timestamp("enrolled_at").defaultNow().notNull(),
  completedAt: timestamp("completed_at"),
});

export const insertUserProgramEnrollmentSchema = createInsertSchema(userProgramEnrollments).omit({
  id: true,
  enrolledAt: true,
  completedAt: true,
});

export type InsertUserProgramEnrollment = z.infer<typeof insertUserProgramEnrollmentSchema>;
export type UserProgramEnrollment = typeof userProgramEnrollments.$inferSelect;

// ============================================================================
// AI AGENTS TABLE
// ============================================================================
export const aiAgents = pgTable("ai_agents", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  slug: text("slug").notNull().unique(),
  description: text("description"),
  scope: text("scope").notNull(), // CHRONIC_DISEASE, WOMEN_HEALTH, MOTHERHOOD, CUSTOMER_SUPPORT, OPS
  isActive: boolean("is_active").default(true).notNull(),
  targetAudience: text("target_audience"), // e.g. "Black women in North America", "Pregnant women", etc.
  personaPrompt: text("persona_prompt").notNull(),
  systemInstructions: text("system_instructions").notNull(),
  languages: json("languages").$type<string[]>().default(["en"]),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertAiAgentSchema = createInsertSchema(aiAgents).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertAiAgent = z.infer<typeof insertAiAgentSchema>;
export type AiAgent = typeof aiAgents.$inferSelect;

// ============================================================================
// AI TASKS TABLE
// ============================================================================
export const aiTasks = pgTable("ai_tasks", {
  id: serial("id").primaryKey(),
  agentId: integer("agent_id").notNull().references(() => aiAgents.id),
  type: text("type").notNull(), // CONTENT_GENERATION, PROGRAM_SUMMARY, WEEKLY_CAMPAIGN, etc.
  inputPayload: json("input_payload").$type<Record<string, any>>(),
  outputPayload: json("output_payload").$type<Record<string, any>>(),
  status: text("status").notNull().default("PENDING"), // PENDING, RUNNING, COMPLETED, FAILED
  runByUserId: varchar("run_by_user_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertAiTaskSchema = createInsertSchema(aiTasks).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertAiTask = z.infer<typeof insertAiTaskSchema>;
export type AiTask = typeof aiTasks.$inferSelect;

// ============================================================================
// AI MESSAGES TABLE (Chat History)
// ============================================================================
export const aiMessages = pgTable("ai_messages", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  agentId: integer("agent_id").notNull().references(() => aiAgents.id),
  conversationId: varchar("conversation_id").notNull(),
  role: text("role").notNull(), // user, assistant
  content: text("content").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertAiMessageSchema = createInsertSchema(aiMessages).omit({
  id: true,
  createdAt: true,
});

export type InsertAiMessage = z.infer<typeof insertAiMessageSchema>;
export type AiMessage = typeof aiMessages.$inferSelect;
